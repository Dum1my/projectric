package com.projectric

import android.os.Bundle
import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.ReactRootView
import com.facebook.react.modules.core.DefaultHardwareBackBtnHandler
import com.facebook.soloader.SoLoader
import org.devio.rn.splashscreen.SplashScreen

class MainActivity : ReactActivity(), DefaultHardwareBackBtnHandler {

    override fun onCreate(savedInstanceState: Bundle?) {
        SplashScreen.show(this, true)  // Add this line to show the splash screen
        super.onCreate(savedInstanceState)
        SoLoader.init(this, false)
    }

    override fun getMainComponentName(): String = "projectric"

    override fun createReactActivityDelegate(): ReactActivityDelegate =
        object : ReactActivityDelegate(this, mainComponentName), DefaultHardwareBackBtnHandler {
            override fun getLaunchOptions(): Bundle? {
                return intent.extras
            }

            override fun onBackPressed(): Boolean {
                if (reactInstanceManager != null) {
                    reactInstanceManager!!.onBackPressed()
                    return true
                }
                return super.onBackPressed()
            }

            override fun invokeDefaultOnBackPressed() {
                super.onBackPressed()
            }
        }
}
