# PROJECTIC App Documentation

This is the documentation of Mobile App Code Developed using React Native for both platforms.
 

## Table of Contents
 
- [Components](#components)
- [Constants](#constants)
- [Hooks](#hooks)
- [Navigation](#navigation)
- [Screens](#screens)
- [Store](#store) 

## Api

Here we have setup URL's for all the API's that is used in this app and Get and Post requests are also setup using Axios.

---

## Components

Here we have all the bits and pieces of our app which are used as the main building blocks in our app.

- [Home Page](#•-home-page) 
