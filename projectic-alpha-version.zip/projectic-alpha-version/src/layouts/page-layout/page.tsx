import React, { useRef, useState } from 'react';
import { ColorValue, FlatList, Keyboard, ListRenderItem, NativeScrollEvent, NativeSyntheticEvent, Pressable, StatusBarStyle, Text, View, ViewStyle } from 'react-native';
import { IStyles, handleGenerateStylesheet } from './page-layout.styles';
import { ReactJsxOnlyChildren } from '@global';
import BaseLayout from '../base-layout/base-layout';
import { PageNames } from '@/data/pages-data';
import useGenerateStyles from '@/hooks/use-generate-styles';
import { headerContainerHeight } from '@/containers/header/header-index/header-index-styles';
import AppAnimation from '@/components/app-animation/app-animation';
import HeaderIndex from '@/containers/header/header-index/header-index';
import FooterIndex from '@/containers/footer/footer-index/footer-index';
import AppIcon from '@/components/app-icon/app-icon';
import { IconNames } from '@/components/app-icon/app-icon.data';
import { useAppTheme } from '@/features/app-theming';
import useAppNavigation from '@/hooks/use-app-navigation';
import { useDispatch, useSelector } from 'react-redux';
import { StoreDispatch, StoreState } from '@/redux/redux-store';
import { GetUserFromLocalStorage } from '@/functions/local-storage-methods';
import { logoutUser, setUserDataAndSaveInLocalStorage } from '@/redux/user/actions';

interface IProps<T> {
    containerStyles?: ViewStyle;
    statusBar?: { backgroundColor: ColorValue; style: StatusBarStyle };
    homeIndicatorBar?: { backgroundColor: ColorValue };
    currentPage: PageNames;
    headerTitle?: string;
    flatList: {
        listHeaderComponent: ReactJsxOnlyChildren;
        listFooterComponent?: React.ReactElement<any, string | React.JSXElementConstructor<any>> | React.ComponentType<any> | null | undefined;
        listEmptyComponent?: React.ReactElement<any, string | React.JSXElementConstructor<any>> | React.ComponentType<any> | null | undefined;
        data?: T[];
        keyExtractor?: (item: T, index: number) => string;
        numColumns?: number;
        renderItem?: ListRenderItem<T>;
        renderedItemsContainerStyle?: ViewStyle;
        onEndReachedThreshold?: number;
        onEndReached?: (info: { distanceFromEnd: number }) => void;
    };
}

const PageLayout = <T extends unknown>({ currentPage, statusBar, homeIndicatorBar, containerStyles, headerTitle, flatList }: IProps<T>) => {
    const styles = useGenerateStyles<IStyles>(handleGenerateStylesheet);
    const { themeColors } = useAppTheme();
    const [showFloatingHeader, setShowFloatingHeader] = useState(false);
    const mainScrollViewRef = useRef<FlatList | null>(null);
    const { navigateTo } = useAppNavigation();
    const dispatch = useDispatch<StoreDispatch>();
    const userData = useSelector((state: StoreState) => state.user);

    const handleScrollToTop = () => mainScrollViewRef.current?.scrollToOffset({ offset: 0, animated: true });
    const handleOnScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
        if (!showFloatingHeader && event.nativeEvent.contentOffset.y >= headerContainerHeight * 2) setShowFloatingHeader(true);
        else if (showFloatingHeader && event.nativeEvent.contentOffset.y < 10) setShowFloatingHeader(false);
    };
    // console.log('data--->', flatList.numColumns)
    const logout = async () => {
        // const User = await GetUserFromLocalStorage();
        // console.log('GetUserFromLocalStorage---->', User.isToken);
        dispatch(logoutUser({}));
        navigateTo(PageNames.LOGIN, {})
    }
    return (
        <BaseLayout statusBar={statusBar} homeIndicatorBar={homeIndicatorBar}>
            <View style={styles.container}>
                <AppAnimation visible={showFloatingHeader} containerStyle={styles.headerAnimContainer} initialState={{ opacity: 0 }} targetState={{ opacity: 1 }} transition={{ duration: 250 }}>
                    <View style={styles.animatedHeaderBox}>
                        <View style={{ marginLeft: 20 }}><Text style={styles.logoutText}>Logo</Text></View>
                        <Pressable style={{ marginRight: 20, }} onPress={logout}><AppIcon icon={IconNames.Logout} containerStyle={{ paddingHorizontal: 10 }} color={themeColors.white} /></Pressable>
                    </View>
                </AppAnimation>
                <View style={[styles.content, containerStyles]}>
                    <Pressable onPress={() => Keyboard.dismiss()}>
                        <FlatList
                            ref={mainScrollViewRef}
                            bounces={false}
                            showsVerticalScrollIndicator={false}
                            showsHorizontalScrollIndicator={false}
                            onScroll={handleOnScroll}
                            scrollEventThrottle={16}
                            removeClippedSubviews={true}
                            ListFooterComponent={flatList.listFooterComponent}
                            ListEmptyComponent={flatList.listEmptyComponent}
                            ListHeaderComponent={
                                <React.Fragment>
                                    <View style={[styles.animatedHeaderBox, { height: 120, }]}>
                                        <View style={{ marginLeft: 20, bottom: 30 }}><Text style={styles.logoutText}>Logo</Text></View>
                                        <Pressable style={{ marginRight: 20, bottom: 30 }} onPress={logout}><AppIcon icon={IconNames.Logout} containerStyle={{ paddingHorizontal: 10 }} color={themeColors.white} /></Pressable>
                                    </View>
                                    {flatList.listHeaderComponent}
                                </React.Fragment>
                            }
                            // horizontal={true}
                            data={flatList.data || []}
                            numColumns={flatList.numColumns || 1}
                            // keyExtractor={flatList.keyExtractor}
                            renderItem={flatList.renderItem}
                            // columnWrapperStyle={flatList.renderedItemsContainerStyle}
                            onEndReachedThreshold={flatList.onEndReachedThreshold}
                            onEndReached={flatList.onEndReached}
                        />
                    </Pressable>
                </View>
                {/* <FooterIndex currentPage={currentPage} handleScrollToTop={handleScrollToTop} /> */}
            </View>
        </BaseLayout>
    );
};

export default PageLayout;