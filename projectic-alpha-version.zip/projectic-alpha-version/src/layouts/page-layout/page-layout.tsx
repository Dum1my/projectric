import React, { useState } from 'react';
import { ColorValue, GestureResponderEvent, Keyboard, KeyboardAvoidingView, NativeScrollEvent, NativeSyntheticEvent, Platform, Pressable, SafeAreaView, ScrollView, StatusBarStyle, StyleSheet, View, ViewStyle } from 'react-native';
import BaseLayout from '../base-layout/base-layout';  
import AppHeader from '../../components/app-header/app-header'; 
import { Text } from 'react-native-svg';
import FooterIndex from '../../components/footer-index/footer-index';
import { screen_height } from '../../utils/constants';

interface IProps {
  statusBar?: { backgroundColor: ColorValue; style: StatusBarStyle; };
  homeIndicatorBar?: { backgroundColor: ColorValue; };
  containerStyles?: ViewStyle;
  headerTitle?: string; 
  showBackIcon?: boolean;
  showRightIcon?: boolean;
  children: any;
  isFooter?: boolean;
  single?: boolean;
  duble?: boolean;
  title1?:string;
  title2?:string;
  isProcessing?: boolean;
  footerTitle?: string;
  onPress?: (() => void) | undefined;
  onPressRight?: (() => void) | undefined;
  containerStylesbtn?: ViewStyle;
  footerbtnSty?:ViewStyle;
  btnSty1?:ViewStyle;
  textsty1?:ViewStyle;
  btnSty2?:ViewStyle;
  onPressbtn1?: (() => void) | undefined;
  onPressbtn2?: (() => void) | undefined;
}

const PageLayout: React.FC<IProps> = ({ statusBar, homeIndicatorBar, containerStyles,isFooter,single,duble, headerTitle, children, showBackIcon,showRightIcon ,onPress,onPressRight,footerTitle,title1,title2,footerbtnSty,btnSty1,textsty1,btnSty2,onPressbtn1,onPressbtn2}) => { 

  return ( 
      <BaseLayout statusBar={statusBar} homeIndicatorBar={homeIndicatorBar}>
        <View style={styles.headerView}>
          <AppHeader  headerTitle={headerTitle} showBackIcon={showBackIcon} showRightIcon={showRightIcon} onPressRight={onPressRight}/>
        </View> 
        <View style={styles.container}> 
          <ScrollView style={[styles.content, containerStyles]} bounces={false} showsVerticalScrollIndicator={false}scrollEventThrottle={16} removeClippedSubviews={true}>
            <Pressable onPress={() => Keyboard.dismiss()} style={{ flex: 0 }}>
              {children}
            </Pressable>
          </ScrollView> 
          <View style={styles.footerBox}>
            {isFooter && <FooterIndex onPress={onPress} title={footerTitle} title1={title1}  title2={title2} footerbtnSty={footerbtnSty}single={single} duble={duble} btnSty1={btnSty1} textsty1={textsty1} btnSty2={btnSty2} onPressbtn1={onPressbtn1} onPressbtn2={onPressbtn2}/> }
          </View>
        </View>
      </BaseLayout> 
  );
};

const styles = StyleSheet.create({
    container: {
      flex: 1,
      width: '100%',
    }, 
    content:{
      // marginHorizontal:20,
      height: screen_height
    },
    headerView:{
      // position: 'absolute',
      // height:55,
      // top: 10,
      // width: '100%', 
      // borderBottomColor: _themeColors.shadow, 
      // backgroundColor: _themeColors.bg,
      // zIndex: 10,
    },
    footerBox:{
      alignItems: 'center',
    }
  });

export default PageLayout;