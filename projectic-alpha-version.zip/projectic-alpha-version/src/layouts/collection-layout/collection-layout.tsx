import React, { useState } from 'react';
import { ColorValue, FlatList, GestureResponderEvent, Keyboard, ListRenderItem, NativeScrollEvent, NativeSyntheticEvent, Pressable, StatusBarStyle, StyleSheet, View, ViewStyle } from 'react-native';
import AppHeader from '../../components/app-header/app-header';
import BaseLayout from '../base-layout/base-layout';
import { screen_height } from '../../utils/constants';
import FooterIndex from '../../components/footer-index/footer-index';

interface IProps {
    containerStyle?: ViewStyle;
    statusBar?: { backgroundColor: ColorValue; style: StatusBarStyle };
    homeIndicatorBar?: { backgroundColor: ColorValue }; 
    headerTitle: string;
    isFooter: boolean;
    footerTitle: string;
    onPress: (event: GestureResponderEvent) => void; 
    onPressRight: (event: void) => void; 
    flatList: {
        data: [];
        keyExtractor: (item: [], index: number) => string;
        listHeaderComponent: React.ReactElement;
        listFooterComponent: React.ReactElement<any, string | React.JSXElementConstructor<any>> | React.ComponentType<any> | null | undefined;
        listEmptyComponent: React.ReactElement<any, string | React.JSXElementConstructor<any>> | React.ComponentType<any> | null | undefined;
        renderItem: ListRenderItem<[]>;
        onEndReachedThreshold: number;
        // onEndReached: Function;
    }; 
    showBackIcon?: boolean;
    showRightIcon?: boolean;
}

const CollectionLayout: React.FC<IProps> = ({ containerStyle, statusBar, homeIndicatorBar, headerTitle, isFooter, footerTitle, onPress, flatList,showBackIcon,showRightIcon ,onPressRight }) => {
 

   

    return (
        <BaseLayout statusBar={statusBar} homeIndicatorBar={homeIndicatorBar}>
            <View style={styles.container}> 
            <AppHeader  headerTitle={headerTitle} showBackIcon={showBackIcon} showRightIcon={showRightIcon} onPressRight={onPressRight}/>
                <View style={[styles.content, containerStyle]}>
                    <Pressable onPress={() => Keyboard.dismiss()}>
                        <FlatList
                            data={flatList.data}
                            keyExtractor={flatList.keyExtractor}
                            renderItem={flatList.renderItem}
                            onEndReachedThreshold={flatList.onEndReachedThreshold}
                            ListHeaderComponent={
                                <React.Fragment>
                                    {/* <AppHeader  headerTitle={headerTitle} showBackIcon={showBackIcon} showRightIcon={showRightIcon} onPressRight={onPressRight}/> */}
                                    {flatList.listHeaderComponent}
                                </React.Fragment>
                            }
                            ListFooterComponent={flatList.listFooterComponent}
                            ListEmptyComponent={flatList.listEmptyComponent}
                            numColumns={1} 
                            scrollEventThrottle={16}
                            showsVerticalScrollIndicator={false}
                            removeClippedSubviews={true}
                            bounces={false}
                        />
                    </Pressable>
                </View>
                {/* <View style={styles.footerBox}>
                    {isFooter && <FooterIndex onPress={onPress} title={footerTitle} title1={title1} title2={title2} footerbtnSty={footerbtnSty} single={single} duble={duble} btnSty1={btnSty1} textsty1={textsty1} btnSty2={btnSty2} onPressbtn1={onPressbtn1} onPressbtn2={onPressbtn2} />}
                </View> */}
            </View> 
        </BaseLayout>
    );
};
const styles = StyleSheet.create({
    container: {
      flex: 1,
      width: '100%',
    }, 
    content:{
      // marginHorizontal:20,
      height: screen_height
    },
    headerView:{
      // position: 'absolute',
      // height:55,
      // top: 10,
      // width: '100%', 
      // borderBottomColor: _themeColors.shadow, 
      // backgroundColor: _themeColors.bg,
      // zIndex: 10,
    },
    footerBox:{
      alignItems: 'center',
    }
  });
export default CollectionLayout;