import React, { useState } from 'react';
import { ColorValue, Keyboard, Pressable, ScrollView, StatusBarStyle, StyleSheet, View, ViewStyle } from 'react-native';
import BaseLayout from '../base-layout/base-layout';  
import AppHeader from '../../components/app-header/app-header'; 
import { Text } from 'react-native-svg';
import FooterIndex from '../../components/footer-index/footer-index';

interface IProps {
  statusBar?: { backgroundColor: ColorValue; style: StatusBarStyle; };
  homeIndicatorBar?: { backgroundColor: ColorValue; };
  containerStyles?: ViewStyle;
  headerTitle?: string; 
  showBackIcon?: boolean;
  showRightIcon?: boolean;
  children: any;
  isFooter?: boolean; 
  isProcessing?: boolean;
  footerTitle?: string;
  onPress?: (() => void) | undefined;
  containerStylesbtn?: ViewStyle; 
  footerElement?: JSX.Element,
}

const HeaderLayout: React.FC<IProps> = ({ statusBar, homeIndicatorBar, containerStyles,isFooter, headerTitle, children, showBackIcon,showRightIcon ,onPress,footerTitle,footerElement}) => { 

  return (
    <>
      <BaseLayout statusBar={statusBar} homeIndicatorBar={homeIndicatorBar}>
        <View style={styles.headerView}>
          <AppHeader  headerTitle={headerTitle} showBackIcon={showBackIcon} showRightIcon={showRightIcon} onPressRight={onPress}/>
        </View> 
        <View style={styles.container}> 
          <ScrollView style={[styles.content, containerStyles]} bounces={false} showsVerticalScrollIndicator={false}scrollEventThrottle={16} removeClippedSubviews={true}>
            <Pressable onPress={() => Keyboard.dismiss()} style={{ flex: 0 }}>
              {children}
            </Pressable>
          </ScrollView> 
          <View style={styles.footerBox}> 
            {footerElement && <>{footerElement}</>}
          </View>
        </View>
      </BaseLayout>
    </>
  );
};

const styles = StyleSheet.create({
    container: {
      flex: 1,
      width: '100%',
    }, 
    content:{
      // marginHorizontal:20,
    },
    headerView:{ 
    },
    footerBox:{
      alignItems: 'center',
    }
  });

export default HeaderLayout;