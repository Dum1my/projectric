import { ColorValue, StatusBarStyle } from 'react-native';
import React from 'react'; 
import AppStatusBar from '../../components/app-status-bar/app-status-bar';  
import { MyColors } from '../../config/MyColors';
import AppHomeIndicatorBar from '../../components/app-home-indicator-bar/app-home-indicator-bar';

interface IProps {
    statusBar?: { backgroundColor: ColorValue; style: StatusBarStyle; };
    homeIndicatorBar?: { backgroundColor: ColorValue; };
    children: any;
}

const BaseLayout: React.FC<IProps> = ({ children, statusBar,homeIndicatorBar }) => { 

    return (
        <>
            <AppStatusBar backgroundColor={statusBar?.backgroundColor || MyColors.mainYellow} barStyle={statusBar?.style || 'dark-content'} />
            <AppHomeIndicatorBar backgroundColor={homeIndicatorBar?.backgroundColor || MyColors.mainYellow} children={children} />
        </>
    );
};

export default BaseLayout;