import {createSlice} from '@reduxjs/toolkit';

const usersSlice = createSlice({
  name: 'users',
  initialState: {
    token: null,
    otp: '',
    initalRoute:'Splash'
  },
  reducers: {
    saveToken: (state, {payload}) => {
      state.token = payload;
    },
    saveInitalRoute: (state, {payload}) => {

      state.initalRoute = payload;
    }
   
   
  },
});

export const {saveToken ,saveInitalRoute} =
  usersSlice.actions;

export default usersSlice.reducer;
