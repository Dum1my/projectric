import { Platform, StyleSheet } from "react-native";
import { MyColors } from "../config/MyColors";
import { StatusBarHeight,  hp,  useCustomSafeAreaInsets } from "../utils/constants";
import { useSafeAreaInsets } from "react-native-safe-area-context";
 


export const MyStylesMain =()=>{
   return StyleSheet.create({
        container:{
            flex: 1,
            paddingTop: useCustomSafeAreaInsets().top,
            paddingBottom: useCustomSafeAreaInsets().bottom,
            // paddingLeft: useCustomSafeAreaInsets().left,
            // paddingRight: useCustomSafeAreaInsets().right,
            backgroundColor:MyColors.white,
            paddingHorizontal: hp(3)
        },
        gButton:{
            width:'85%',
            borderRadius:30,
            borderColor:MyColors.white,
            borderWidth:1, 
        }
        })
}










