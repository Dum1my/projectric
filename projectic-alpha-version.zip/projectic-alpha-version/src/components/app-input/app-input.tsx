import React, { useState } from 'react';
import { Text, View, TextInput, StyleSheet, StyleProp, ViewStyle, TextStyle } from 'react-native';
import { RFValue } from 'react-native-responsive-fontsize';
import { MyColors } from '../../config/MyColors';
import { MyFonts } from '../../config/MyFonts';
import { responsiveSize } from '../../config/Metrix';
import { hp } from '../../utils/constants';
import GlobalIcon from '../../config/GlobalIcons';
import { TouchableOpacity } from 'react-native-gesture-handler';

interface AppInputProps {
  label: string;
  optional?: boolean;
  placeholder?: string;
  number?:number;
  multiline?: boolean;
  value: string;
  onChangeText: (text: string) => void;
  secureTextEntry?: boolean;
  keyboardType?: 'default' | 'numeric' | 'email-address' | 'phone-pad';
  style?: StyleProp<ViewStyle>;
  inputStyle?: StyleProp<TextStyle>;
  labelSty?: StyleProp<TextStyle>;
  inputLeftElement?: JSX.Element;
  inputRightElement?: JSX.Element;
  editable?: boolean;
  type?: string;
  showPasswordIcon?: boolean;
  inputContainer?: ViewStyle;
  error?: any
}

const AppInput: React.FC<AppInputProps> = ({
  label,
  optional = false,
  placeholder,
  value,
  onChangeText,
  secureTextEntry = false,
  keyboardType = 'default',
  style = {},
  inputStyle = {}, 
  labelSty = {}, 
  inputLeftElement, inputRightElement,
  number,
  multiline,
  editable,
  type,
  showPasswordIcon = false,
  inputContainer,
  error
}) => {
  const [isFocused, setIsFocused] = useState<boolean>(false); 
  const [secured, setIsSecured] = useState<boolean>(false)

  const togglePasswordVisibility = () => {
    setIsSecured(!secured)
  }
  return (
    <View style={[styles.container, style]}>

      <View style={styles.labelContainer}>
        <Text style={[styles.label,labelSty]}>
          {label}
          {optional && <Text style={{ color: 'red' }}>*</Text>}
        </Text>
      </View>
      <View style={[styles.inputBox,inputContainer]}>
      {inputLeftElement && <>{inputLeftElement}</>}
      <TextInput
        style={[styles.input, inputStyle, {width: showPasswordIcon ? '90%' : '100%'}]}
        placeholder={placeholder}
        placeholderTextColor={'#C2C2C2'}
        value={value}
        onChangeText={onChangeText}
        secureTextEntry={!secured && type == 'password'}
        keyboardType={keyboardType}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        numberOfLines={number}
        multiline={multiline}
        editable={editable}
        />
       {type === 'password' && showPasswordIcon && (
          <TouchableOpacity
            onPress={togglePasswordVisibility}>
            {!secured ? (
              <GlobalIcon
                library="Feather"
                name="eye-off"
                size={hp(2.5)}
              />
            ) : (
              <GlobalIcon
                library="Feather"
                name="eye"
                size={hp(2.5)}
              />
            )}
          </TouchableOpacity>
        )}
          {inputRightElement && <>{inputRightElement}</>}
        </View>
        {error ? <Text style={styles.errorText}>{error}</Text> : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    marginBottom: responsiveSize(35),
    // backgroundColor: MyColors.white
  },
  labelContainer: {
    position: 'absolute',
    top: responsiveSize(-15),
  },
  label: {
    fontSize: RFValue(12),
    color: MyColors.black,
    fontFamily: MyFonts.OpenSansSemiBold,
    bottom:hp(1)
    // bottom:2
  },
  labelFocused: {
    color: 'blue',
  },
  inputBox:{
    width: '100%',
    flexDirection:'row', 
    alignContent:'center', 
    height: responsiveSize(42),
    borderColor: '#ECECEC',
    borderWidth: 1,
    borderRadius: 5,
    // backgroundColor: '#F6F5F8',  
    backgroundColor: MyColors.white,
    alignItems: 'center'
  },
  input: {  
    width: '100%',
    fontSize: RFValue(10),
    fontFamily: MyFonts.OpenSansRegular,
    borderRadius: 7,
    paddingLeft: 12,   
    // marginTop: 8, // Adjust the top margin for better spacing
  },
  errorText: {
    color: MyColors.redPrimary,
    fontSize: 12,
    marginTop: 5,
  },
});

export default AppInput;
