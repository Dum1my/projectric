import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useState } from 'react'; 
import { ViewStyle } from 'react-native-size-matters';
import { MyColors } from '../../config/MyColors';
import { hp } from '../../utils/constants';



interface IProps {
  dot?:any,
} 
const Dots: React.FC<IProps> = ({dot}) => {  
  console.log('dot: ', dot);
  return (
    <View style={[styles.container,dot]}/>
  );
};

export default Dots;

const styles = StyleSheet.create({
  container: {
    width: hp(2),
    height:hp(2),
    borderRadius:50,
    color:MyColors.black,
    backgroundColor:MyColors.black
  }, 
});
