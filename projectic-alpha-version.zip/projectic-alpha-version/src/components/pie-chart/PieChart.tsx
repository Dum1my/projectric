import React from 'react';
import {View, StyleSheet} from 'react-native';
import Svg, {G, Line, Path, Text} from 'react-native-svg';
import {hp, screen_width} from '../../utils/constants';

const PieChartWithLabels = ({data}: any) => {
  const total = data.reduce((acc: any, curr: any) => acc + curr.value, 0);
  const angles = data.map((item: any) => 2 * Math.PI * (item.value / total));

  const labelRadius = 110;
  const radius = 80;
  const centerX = screen_width / 2.2;
  const centerY = screen_width / 2.2;

  let prevAngle = -Math.PI / 2;

  return (
    <View style={styles.container}>
      <Svg width={screen_width / 1.15} height={screen_width / 1.15}>
        <G x={centerX} y={centerY}>
          {data.map((item: any, index: number) => {
            const angle = angles[index];
            const endAngle = prevAngle + angle;
            const path = `M 0 0 L ${radius * Math.cos(prevAngle)} ${
              radius * Math.sin(prevAngle)
            } A ${radius} ${radius} 0 ${angle > Math.PI ? 1 : 0} 1 ${
              radius * Math.cos(endAngle)
            } ${radius * Math.sin(endAngle)} Z`;
            prevAngle = endAngle;

            const angle2 = prevAngle - angles[index] / 2;
            let labelX = labelRadius * Math.cos(angle2);
            let labelY = labelRadius * Math.sin(angle2);
            let lineEndX = labelX;
            let lineEndY = labelY;

            if (labelX < 0) {
              labelX = labelX - 20;
              lineEndX = labelX - 10;
            } else if (labelX > 50) {
              labelX = labelX + 20;
              lineEndX = labelX + 10;
            }

            return (
              <G key={index}>
                <Path d={path} fill={item.color} />
                <Line
                  x1={0}
                  y1={0}
                  x2={lineEndX}
                  y2={lineEndY}
                  stroke={item.color}
                />
                <Text
                  x={labelX}
                  y={labelY}
                  fill="black"
                  textAnchor="middle"
                  fontFamily="Arial"
                  fontSize="10"
                  fontWeight="bold"
                  fontStyle="italic"
                  textDecoration="underline">
                  {item.label}
                </Text>
              </G>
            );
          })}
        </G>
      </Svg>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    width: screen_width / 1.1,
    height: hp(30)
  },
});

export default PieChartWithLabels;
