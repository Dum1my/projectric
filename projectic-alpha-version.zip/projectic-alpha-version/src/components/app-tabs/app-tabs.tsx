import { Image, TouchableOpacity, View, Text, SafeAreaView, Animated, StyleSheet, Pressable, LayoutAnimation, Keyboard } from 'react-native';
import React, { useEffect, useState } from 'react'; 
import { useNavigation } from '@react-navigation/native';
import { Colors } from 'react-native/Libraries/NewAppScreen';
import { MyColors } from '../../config/MyColors';
import { hp, useCustomSafeAreaInsets } from '../../utils/constants';
import GlobalIcon from '../../config/GlobalIcons';
import ProfileIcon from '../../assets/svgs/profile-icon';
import NotificationsIcon from '../../assets/svgs/notification-icon';

interface IProps {
    state?: any,
    descriptors?:any,
    navigation?: any,
}

const AppTab: React.FC<IProps> = ({ state, descriptors, navigation }) => { 
    const [activeIndex, setActiveIndex] = useState(0); 
    const dotPositions = state?.routes.map(() => new Animated.Value(0));
    const [keyboardShown, setKeyboardShown] = useState(false);

    useEffect(() => {
        const keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', () => {
            setKeyboardShown(true);
        });
        const keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', () => {
            setKeyboardShown(false);
        }); 
        return () => {
            keyboardDidShowListener.remove();
            keyboardDidHideListener.remove();
        };
    }, []);

    useEffect(() => {  
        LayoutAnimation.easeInEaseOut();
        Animated.parallel(
            dotPositions.map((dotPosition:any, index:any) => {
                return Animated.spring(dotPosition, {
                    toValue: (activeIndex - index) * 104,
                    useNativeDriver: true,
                });
            })
        ).start(); 
    }, [activeIndex]);
    return (
        <View style={styles.mainBox}>
            {state?.routes.map((route: any, index: number) => {  
                const {icon_name,library} = route?.params;     
                const { options } = descriptors[route.key];
                const label = options.tabBarLabel !== undefined ? options.tabBarLabel : options.title !== undefined ? options.title : route.name; 
                const isFocused =  state.index === index;   
                const isActiveTab = activeIndex === state.index; 
  
                if(keyboardShown) return <View style={{borderTopColor:MyColors.mainYellow}}/> 
                const Icons=()=>{ 
                    if(index === 0 || index === 1){
                      return  isFocused ?   <GlobalIcon color={MyColors.mainYellow} size={hp(3)} name={icon_name} library={library} />
                        :
                        <GlobalIcon color={MyColors.grayText} size={hp(3)} name={icon_name} library={library} />
                    }
                     else if(index == 2){
                            return( <NotificationsIcon color={isFocused ? MyColors.mainYellow : MyColors.grey} circleColor={isFocused ? MyColors.redPrimary : MyColors.grey} />  )
                    }
                     else if(index == 3){
                            return( <ProfileIcon color={isFocused ? MyColors.mainYellow : MyColors.grey}/>  )
                    }
                }
                return (
                    <TouchableOpacity
                        key={route.key}
                        onPress={() => {
                            const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true }); 
                            if (!state.routes[index].state?.isDrawerOpen && !event.defaultPrevented) { 
                                setActiveIndex(index);
                                navigation.navigate(route.name); 
                            } 
                        }}
                        style={styles.container}>
                        <View style={styles.tabsBox}> 
                        {Icons()}
                            {/* {
                              isFocused ?   <GlobalIcon color={MyColors.mainYellow} size={hp(3)} name={icon_name} library={library} />
                              :
                              <GlobalIcon color={MyColors.grayText} size={hp(3)} name={icon_name} library={library} />
                            } */}
                            <Text style={{ color: isFocused ? MyColors.mainYellow : MyColors.grayText }}>{label}</Text>
                        </View>
                        {isFocused && (
                            <Animated.View  style={[  styles.dots,  {   transform: [{ translateX: dotPositions[index] }], }, ]}
                            />
                        )}
                    </TouchableOpacity>
                );
            })}
        </View>
    );
};

export default AppTab;

const styles = StyleSheet.create({
    mainBox:{ 
        flexDirection: 'row', 
        backgroundColor: 'white', 
        borderColor: 'white',
        borderTopWidth:0.4,
    },
    container: {
         flex: 1, 
         marginVertical: 10, 
         alignItems: 'center', 
        //  position: 'relative', 
    },
    tabsBox: {
        height: 35,
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical:hp(1)
    },
    dots: {
        width: hp(1),
        height: hp(1),
        borderRadius: hp(1),
        backgroundColor: MyColors.mainYellow,
        position: 'absolute',
        top: hp(-1.8),
    },
});



{/* <TouchableOpacity style={{ flex: 1, marginVertical: 30, alignItems: 'center', }}
onPress={() =>navigation.navigate(state.routes[0].name) } 
>
       <Text style={{ color: true ? 'blue' : 'black' }}>Dashboard</Text> 
   </TouchableOpacity>
<TouchableOpacity
onPress={() =>navigation.navigate(state.routes[1].name) } 
style={{ flex: 1, marginVertical: 30, alignItems: 'center', }} >
       <Text style={{ color: true ? 'blue' : 'black' }}>Reminder</Text> 
   </TouchableOpacity>
<TouchableOpacity onPress={() =>navigation.navigate(state.routes[2].name) }  style={{ flex: 1, marginVertical: 30, alignItems: 'center', }} >
       <Text style={{ color: true ? 'blue' : 'black' }}>Dashboard</Text> 
   </TouchableOpacity>
<TouchableOpacity onPress={() =>navigation.navigate(state.routes[3].name) }  style={{ flex: 1, marginVertical: 30, alignItems: 'center', }} >
       <Text style={{ color: true ? 'blue' : 'black' }}>Dashboard</Text> 
   </TouchableOpacity> */}