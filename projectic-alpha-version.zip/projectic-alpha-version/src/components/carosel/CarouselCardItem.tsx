import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Dimensions, Image, Platform } from 'react-native';
import { MyFonts } from '../../config/MyFonts';
import GlobalIcon from '../../config/GlobalIcons';
import { responsiveSize } from '../../config/Metrix';
import { RFValue } from 'react-native-responsive-fontsize';
import { hp, useCustomSafeAreaInsets } from '../../utils/constants';
import { MyColors } from '../../config/MyColors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const SLIDER_WIDTH_PERCENT = 100; // Percentage of screen width
const ITEM_WIDTH_PERCENT = 100; // Percentage of screen width

export const SLIDER_WIDTH = (Dimensions.get('window').width * SLIDER_WIDTH_PERCENT) / 100;
export const ITEM_WIDTH = (Dimensions.get('window').width * ITEM_WIDTH_PERCENT) / 100;


interface CarouselCardItemProps {
  item: {
    imgUrl: any;
    title: string;
    body: string;
  };
  index: number;
}

const CarouselCardItem: React.FC<CarouselCardItemProps> = ({ item, index }) => {

  const insets = useSafeAreaInsets();
  

  return (
    <View>
      <View style={[styles.container, {paddingTop:insets.top+20,paddingBottom:insets.bottom,paddingLeft:insets.left,paddingRight:insets.right}]} key={index}>
        <Image resizeMode="contain" source={item.imgUrl} style={styles.image} />
      </View>
      <View style={styles.bodyView}>
        <Text style={styles.header}>{item.title}</Text>
        <View style={styles.icon}>
          <GlobalIcon name="check" library="Entypo" size={hp(2)} color={'#2BC48A'} />
        </View>
        <Text style={styles.body}>{item.body}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: Dimensions.get('window').width + hp(30),
    backgroundColor: '#F8FAFF',
    borderBottomRightRadius:hp(1560),
    borderBottomLeftRadius: hp(1560),
    
    alignSelf: 'center',
    zIndex: -11,
  },
  image: {
    width: Dimensions.get('window').width + hp(30),
    height: hp(45),
    borderBottomRightRadius:hp(1560),
    borderBottomLeftRadius: hp(1560),
    alignSelf: 'center',
  },
  bodyView: {
    width: Dimensions.get('window').width - hp(3),
    alignSelf: 'center',
    backgroundColor:MyColors.white,
    marginTop: hp(2),
  
  },
  icon: {
    alignItems: 'center',
    marginTop: hp(1),
  },
  header: {
    color: '#34445A',
    fontSize: hp(2.7),
    textAlign: 'center',
    fontFamily: MyFonts.OpenSansBold,
    paddingTop: hp(2),
  },
  body: {
    color: '#979797',
    fontSize: hp(1.8),
    paddingHorizontal:hp(1.2),
    textAlign: 'center',
    fontFamily: MyFonts.OpenSansRegular,
    paddingTop: hp(1),
  },
});

export default CarouselCardItem;
