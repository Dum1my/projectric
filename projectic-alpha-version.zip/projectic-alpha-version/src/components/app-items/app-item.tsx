import React, { useState } from 'react';
import { View, StyleSheet, Text, Dimensions } from 'react-native';  
import { hp } from '../../utils/constants';  
import { MyColors } from '../../config/MyColors';
import { MyFonts } from '../../config/MyFonts';
import CategoryList from './catego-item';
import ItemList from './item-card';

interface Category {
    id: number;
    name: string;
}

interface Item {
    id: number;
    name: string;
    discount: string;
    image: any;
}

interface CategoryAndItemsProps {
    categories: Category[];
    itemsData: { [key: string]: Item[] };
}

const CategoryAndItems: React.FC<CategoryAndItemsProps> = ({ categories, itemsData }) => {
    const [selectedCategory, setSelectedCategory] = useState<number>(categories[0].id);

    const selectCategory = (categoryId: number) => {
        setSelectedCategory(categoryId);
    };

    return (
        <View>
            <View style={styles.container}>
                <CategoryList
                    data={categories}
                    selectedItem={selectedCategory}
                    onSelectCategory={selectCategory}
                />
            </View>

            {/* <ItemList items={itemsData[categories[selectedCategory - 1].name.toLowerCase()]} /> */}
        </View>

    );
};

const styles = StyleSheet.create({
    container: {
        paddingBottom: hp(2),
        // width:'100%',
        alignItems: 'center',
        // backgroundColor: 'red'
    },
    noList: {
        // backgroundColor: 'red',
        justifyContent: 'center',
        alignItems: 'center',
        height: hp(60)
    },
    orangeHeading:{
        color:MyColors.buttonSecondary,
        fontFamily:MyFonts.OpenSansRegular,
        textDecorationLine:'underline',
        fontSize:17,
        paddingTop:hp(2)
    }
});

export default CategoryAndItems;