import React from 'react';
import { View, FlatList, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { MyColors } from '../../config/MyColors';
import { wp } from '../../utils/constants';
import { MyFonts } from '../../config/MyFonts';

interface Category {
  id: number;
  name: string;
}

interface CategoryListProps {
  data: Category[];
  selectedItem: number;
  onSelectCategory: (categoryId: number) => void;
}

const CategoryItem: React.FC<{
  category: Category;
  isSelected: boolean;
  onPress: () => void;
}> = ({ category, isSelected, onPress }) => (
  <TouchableOpacity
    style={[styles.categoryItem, isSelected ? styles.selectedCategory : null]}
    onPress={onPress}>
    <Text style={[styles.categoryName, isSelected ? styles.selectedCategoryText : null]}>
      {category.name}
    </Text>
  </TouchableOpacity>
);

const CategoryList: React.FC<CategoryListProps> = ({ data, selectedItem, onSelectCategory }) => (
  <FlatList
    horizontal
    data={data}
    showsHorizontalScrollIndicator={false}
    keyExtractor={(item) => item.id.toString()}
    renderItem={({ item }) => (
      <CategoryItem
        category={item}
        isSelected={selectedItem === item.id}
        onPress={() => onSelectCategory(item.id)}
      />
    )}
  />
);

const styles = StyleSheet.create({
  categoryItem: {
    paddingHorizontal: wp(3.5),
    paddingVertical: wp(2),
    borderRadius: 20,
    marginHorizontal: wp(1.5),
    backgroundColor:MyColors.white,
    borderWidth:0.5,
    borderColor:MyColors.disable,
  
  },
  selectedCategory: {
    backgroundColor: MyColors.buttonSecondary,
  },
  selectedCategoryText: {
    color: 'white',
    fontSize:12,
    fontFamily:MyFonts.OpenSansRegular
    
  },
  categoryName: {
    fontSize:12,
    color:MyColors.disable,
    fontFamily:MyFonts.OpenSansRegular,
    textTransform:'capitalize'
  },
});

export default CategoryList;