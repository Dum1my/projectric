import {
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
} from 'react-native';
import React from 'react';
import {MyColors} from '../../config/MyColors';
import {BlurView} from '@react-native-community/blur';
import {hp, screen_height} from '../../utils/constants';
import GlobalIcon from '../../config/GlobalIcons';
import {responsiveSize} from '../../config/Metrix';
import {MyFonts} from '../../config/MyFonts';

interface AboutModalProps {
  isOpen?: boolean;
  setIsOpen?: any;
}

const AboutModal: React.FC<AboutModalProps> = ({isOpen, setIsOpen}) => {
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isOpen}
      onRequestClose={() => setIsOpen(false)}>
      <View style={styles.container}>
        <BlurView
          style={styles.absolute}
          blurType="dark"
          blurAmount={1}
          reducedTransparencyFallbackColor="white"
        />
        <View style={styles.subContainer}>
          <View style={styles.header}>
            <View>
              <Text style={styles.heading}>Terms and Condition</Text>
              <Text style={styles.subHeading}>
                Please read the terms and condition
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => setIsOpen(false)}
              style={styles.icon}>
              <GlobalIcon
                library="Entypo"
                name="cross"
                color={MyColors.headerTitle}
                size={hp(3)}
              />
            </TouchableOpacity>
          </View>
          <ScrollView
            showsVerticalScrollIndicator={false}
            style={styles.scrollView}>
            <Text style={styles.title}>
              The website located at www.projectric.com (the “Site”) is a
              copyrighted work belonging to Projectric, LLC (“Company”, “us”,
              “our”, and “we”). Certain features of the Site may be subject to
              additional guidelines, terms, or rules, which will be posted on
              the Site in connection with such features. All such additional
              terms, guidelines, and rules are incorporated by reference into
              these Terms. These Terms of Use (these “Terms”) set forth the
              legally binding terms and conditions that govern your use of the
              Site By accessing or using the Site, you are accepting these Terms
              (on behalf of yourself or the entity that you represent), and you
              represent and warrant that you have the right, authority, and
              capacity to enter into these Terms (on behalf of yourself or the
              entity that you represent). you may not access or use the Site or
              accept the Terms if you are not at least 18 years old. If you do
              not agree with all of the provisions of these Terms, do not access
              and/or use the Site. These terms require the use of arbitration
              and/or use the Site. These terms require the use of arbitration
              and/or use the Site. These terms require the use of arbitration
              (Section 8.2) on an individual basis to resolve disputes, rather
              (Section 8.2) on an individual basis to resolve disputes, rather
              (Section 8.2) on an individual basis to resolve disputes, rather
              than jury trials or class actions, and also limit the remedies
              than jury trials or class actions, and also limit the remedies
              than jury trials or class actions, and also limit the remedies
              available to you in the event of a dispute.
            </Text>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

export default AboutModal;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: hp(2),
  },
  absolute: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  subContainer: {
    backgroundColor: MyColors.white,
    padding: hp(2),
    width: '100%',
    borderRadius: hp(1),
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    position: 'relative',
  },
  heading: {
    color: MyColors.black,
    fontSize: responsiveSize(20),
    fontFamily: MyFonts.OpenSansBold,
  },
  subHeading: {
    color: MyColors.grayText,
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansRegular,
  },
  icon: {position: 'absolute', top: -2, right: 0, zIndex: 1},
  scrollView: {maxHeight: screen_height / 2, marginVertical: hp(2)},
  title: {
    color: '#486383',
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansRegular,
  },
});
