import {StyleSheet, Text, View} from 'react-native';
import React, {useState} from 'react';
import CheckBox from 'react-native-check-box';
import { MyColors } from '../../config/MyColors';

const AppCheckBox = () => {
  const [check, setCheck] = useState(false);
  return (
    <CheckBox
      style={{height: 20}}
      onClick={() => {
        setCheck(!check);
      }}
      isChecked={check}
      leftText={'CheckBox'}
      checkedCheckBoxColor={MyColors.greenPrimary}
      uncheckedCheckBoxColor={MyColors.headerTitle}
    />
  );
};

export default AppCheckBox;

const styles = StyleSheet.create({});
