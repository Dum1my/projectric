import React, { useState } from 'react';
// import { Modal } from 'native-base';
// import { ReactJsxOnlyChildren } from '@global';
// import { ThemeComponentSizeType } from 'native-base/lib/typescript/components/types';
// import { Modal, ViewStyle } from 'react-native';
import {Alert, Modal, StyleSheet, Text, Pressable, View, ViewStyle} from 'react-native';
import { hp } from '../../utils/constants';


interface IProps {
    isOpen: boolean;
    handleOnClose: () => void;
    size?:number;
    containerStyles?: ViewStyle,
    children: JSX.Element;
    modalViewStyle?: ViewStyle
}

const AppModal: React.FC<IProps> = ({ isOpen, handleOnClose, size, containerStyles, children,modalViewStyle }) => { 
    return ( 
        <View style={styles.centeredView}>
      <Modal 

    animationType="slide"
        transparent={true}
        visible={isOpen}
        onRequestClose={handleOnClose} 
        style={containerStyles}  
        >
        <View style={styles.centeredView}>
          <View style={[styles.modalView,modalViewStyle]}>
          {children} 
          </View>
        </View>
      </Modal> 
    </View>
    );
};

const styles = StyleSheet.create({
    centeredView: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center', 
      backgroundColor: '#000000db',
    },
    modalView: {
      margin: 20,
      backgroundColor: 'white',
      borderRadius: 10,
    //   padding: 35,
      alignItems: 'center',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      height: hp(40),
      shadowOpacity: 4.25,
      shadowRadius: 4,
      elevation:2,
    },  
  });

export default AppModal;