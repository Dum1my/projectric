import React, { useRef, useImperativeHandle, useState } from 'react';
import SelectDropdown, { SelectDropdownProps } from 'react-native-select-dropdown';
import { View, StyleSheet, Text, ViewStyle, ColorValue, TextStyle } from 'react-native';  
import { MyColors } from '../../config/MyColors';
import GlobalIcon from '../../config/GlobalIcons';
import { hp } from '../../utils/constants';
import { MyFonts } from '../../config/MyFonts';


export type AppDropdownData = {
    value: string;
    isValid: () => boolean;
    setValue: (val: string) => void;
};


interface IProps {
    dropdownName?: string;
    placeholder?: string;
    _backGroundColor?: string;
    options: string[];
    isRequired?: boolean;
    defaultIndex?: number;
    _color?: ColorValue;
    onSelect?: (index: number, option: string) => void;
    ref?: React.Ref<AppDropdownData>;
    style?: {  input: ViewStyle; inputContainer: ViewStyle };
    container?:ViewStyle;
    optional?: boolean;
    buttonStyle?: ViewStyle;
    labelText?: TextStyle
}

const AppSelectDropdown: React.FC<IProps> = React.forwardRef(({ options,container, placeholder,optional, defaultIndex = 0, onSelect, isRequired = false, style, dropdownName, _color, _backGroundColor, buttonStyle,labelText }, ref: React.Ref<AppDropdownData>) => {
    // const { themeColors, setTheme } = useAppTheme(); 
    const dropdownRef = useRef<SelectDropdownProps>(null);
    const [input, setInput] = useState('');
    const [error, setError] = useState('');

    const handleSetValue = (val: string) => {
        // console.log('Drop---val --->', val) 
    }
    const handleValidateInput = () => { 
        let targetError = '';
        if (input === '') targetError = isRequired ? 'Field is required' : ''; 
        setError(targetError);
        return Boolean(targetError === '');
    }; 
    useImperativeHandle(ref, () => ({
        value: input,
        error: error,
        setError: setError,
        setValue: handleSetValue,
        isValid: handleValidateInput
    }), [input, error]);

    return (
        <View style={[styles.container, container]}>
            <View style={styles.dropdownHeading}><Text style={[styles.dropdownText, labelText, { color: _color }]}>{dropdownName} {optional && <Text style={{ color: 'red' }}>*</Text>}</Text></View> 
                <SelectDropdown
                    ref={dropdownRef}
                    style={{ }}
                    data={options}
                    defaultIndex={defaultIndex}
                    onSelect={(index, option) => { setInput(index) }}
                    renderDropdownIcon={isOpened => 
                        <GlobalIcon color={MyColors.black} size={hp(1.3)} name={isOpened ? 'caretup':'caretdown'} library={'AntDesign'} /> 
                        } 
                    dropdownIconPosition={'right'}  defaultButtonText={placeholder} dropdownOverlayColor={'transparent'}
                    rowTextForSelection={(item, index) => item}
                    buttonStyle={{...styles.buttonStyle, ...buttonStyle}} 
                    buttonTextStyle={styles.buttonTextStyle}
                    rowStyle={{ width: '90%', }} 
                    rowTextStyle={styles.rowTextStyle} 
                    selectedRowTextStyle={styles.selectedRowTextStyle}
                /> 
            
            {error ? <Text style={styles.error}>{error}</Text> : null}
        </View>
    );
});

const styles = StyleSheet.create({
    container:{  
        // backgroundColor:MyColors.offwhite
    },
    dropdownHeading: {
        marginHorizontal: 0,
        paddingVertical: 10,
        // backgroundColor:MyColors.lightgrey,
        // backgroundColor:'transparent',
      },
      dropdownText: { 
        color: MyColors.black,  
        fontSize: 12,
      },
      inputContainer: { 
        borderRadius: 5,
        marginHorizontal: 10, 
        opacity: 0.8, 
      },
      input: {
        // flex: 1,
        // color: _themeColors.white,
        fontFamily: MyFonts.OpenSansRegular,
         color: MyColors.black,
      },
      error: {
        // ...fontStyles['font-md-light'],
        // color: _themeColors.error,
        paddingHorizontal: 10,
      },
  
  
      buttonStyle: {
          width: '100%',
          backgroundColor: MyColors.offwhite,
          borderRadius: 5, 
      },
      buttonTextStyle: {
          width: '100%',
          fontSize: 12,
          textAlign: 'left', 
          color:MyColors.grayText,
      },
      rowTextStyle: {
          width: '90%',
          fontSize: 15,
          textAlign: 'left',
          marginLeft: 20,
      },
      selectedRowTextStyle: {
          width: '100%',
          fontSize: 15,
          
      },
})

export default AppSelectDropdown; 