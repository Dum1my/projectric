import { Pressable, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { hp } from '../../utils/constants';
import { MyColors } from '../../config/MyColors';
import { MyFonts } from '../../config/MyFonts';
import { responsiveSize } from '../../config/Metrix';

interface NotificationCardProps {
    item: object |any;
}


const NotificationCard: React.FC<NotificationCardProps> = ({item}) => {
  return (
    <Pressable style={styles.container}>
        <View style={styles.dotContainer}><View style={styles.dot}></View></View>
        <View style={styles.innerContainer}>
            <View style={styles.titleContainer}>
                <Text style={[styles.title, {width: '80%'}]}>{item?.title}</Text>
                <Text style={styles.description}>2 Days Ago</Text>
            </View>
            <Text style={[styles.description, {marginTop: hp(.5)}]}>{item?.description}</Text>
        </View>
  </Pressable>
  )
}

export default NotificationCard

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        paddingHorizontal: 10,
        paddingVertical: hp(2.5),
        borderBottomWidth: hp(0.1),
        borderBottomColor: MyColors.lightgrey,
    },
    dotContainer:{width: '5%',marginTop: hp(1.2)},
    innerContainer:{
        width: '95%',
    },
    dot: {
        backgroundColor: MyColors.mainYellow,
        height: hp(1),
        width: hp(1),
        borderRadius: hp(1)
    },
    titleContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '100%'
    },
    title: {
        fontFamily: MyFonts.OpenSansBold,
        fontSize: responsiveSize(18),
        color: MyColors.headerTitle
    },
    description: {
        fontFamily: MyFonts.OpenSansRegular,
        fontSize: responsiveSize(12),
        color: MyColors.grayText
    }
})