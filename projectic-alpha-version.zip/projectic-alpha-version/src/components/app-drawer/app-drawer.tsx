import * as React from 'react';
import { View, StyleSheet, Image, Text, TouchableOpacity, SafeAreaView, ScrollView, Pressable } from 'react-native';
import { DrawerActions, NavigationProp, ParamListBase, useNavigation } from '@react-navigation/native';
import { MyColors } from '../../config/MyColors';
import { hp, useCustomSafeAreaInsets } from '../../utils/constants';
import MyImages from '../../config/MyImages';
import GlobalIcon from '../../config/GlobalIcons';
import CalenderIcon from '../../assets/svgs/calender-icon';
import ProjectIcon from '../../assets/svgs/project-icon';
import BudgetIcon from '../../assets/svgs/budget-icon';
import PeopleIcon from '../../assets/svgs/people-icon';
import DepartmentIcon from '../../assets/svgs/department-icon';
import ReportIcon from '../../assets/svgs/report-icon';
import { MyFonts } from '../../config/MyFonts';
import TimeIconSvg from '../../assets/svgs/TimeIconSvg';

interface  IProps  { 
}

type SectionItemProps  = {
  route: string;
  name: string; 
}

const AppDrawer: React.FC<IProps> = ({ }) => { 
    const navigation:any = useNavigation();    
    const [selectedPage, setSelectedPage] = React.useState('dash_board');

    const handleMenuItemPress = (page: string) => {
      setSelectedPage(page);
    };
    
    const isPageSelected = (page: string) => {
      return selectedPage === page ? styles.selectedMenuItem : null;
    };
    
    const SectionItem=({ route, name }: SectionItemProps)=><Pressable onPress={()=>{handleMenuItemPress(route); navigation.navigate(route)}}><Text style={[styles.text_title, isPageSelected(route)]}>{name}</Text></Pressable>
  
    return (
    <SafeAreaView style={{ flex: 1 }}>
      <View style={styles.header}>
        <View style={{flexDirection:'row', alignItems: 'center'}}>
          <Image source={MyImages.logo} style={styles.logo} />
          <Text style={styles.headerTitle}>Projectric</Text>
        </View>
        <Pressable  onPress={()=>navigation.dispatch(DrawerActions.toggleDrawer())}><GlobalIcon name="close" library="AntDesign" size={hp(2)} color={'#fff'} /></Pressable>
      </View>

        <ScrollView style={styles.drawerContents} showsVerticalScrollIndicator={false}>
            <Pressable onPress={() => navigation.navigate('Dashboard')}  style={[styles.contentBox, {alignItems: 'center'}]}><CalenderIcon/><Text style={styles.text}>Portfolios</Text></Pressable> 

            <View style={styles.underline}/>

            <Pressable  style={[styles.contentBox,{justifyContent:'space-between'}]}>
              <View style={{flexDirection:'row', alignItems: 'center',marginBottom: hp(1)}}><ProjectIcon/><Text style={styles.text}>Projects</Text></View><GlobalIcon name="caretup" library="AntDesign" size={hp(1.5)} color={MyColors.mainYellow} />
            </Pressable> 
            <View  style={[styles.contentBox,{flexDirection:'column'}]}>
              <SectionItem route={'project_intake'} name={'Project Intake'}/>
              <SectionItem route={'project_view'} name={'View All'}/>
              <SectionItem route={'project_workflow'} name={'Workflow'}/>
              <SectionItem route={'project_template'} name={'Project Template'}/> 
            </View> 
            <View style={styles.underline}/>
            <Pressable  style={[styles.contentBox,{justifyContent:'space-between'}]} onPress={()=>navigation.navigate('budget')}>
              <View style={{flexDirection:'row', alignItems: 'center',}}><BudgetIcon/><Text style={styles.text}>Budget</Text></View>
            </Pressable> 

            <View style={styles.underline}/>
            <Pressable  style={[styles.contentBox,{justifyContent:'space-between'}]}>
              <View style={{flexDirection:'row',alignItems: 'center',marginBottom: hp(1)}}><PeopleIcon/><Text style={styles.text}>People</Text></View><GlobalIcon name="caretup" library="AntDesign" size={hp(1.5)} color={MyColors.mainYellow} />
            </Pressable> 
            <View  style={[styles.contentBox,{flexDirection:'column'}]}>
            <SectionItem route={'people_view'} name={'View All'}/> 
            <SectionItem route={'people_utilization'} name={'Utilization'}/> 
            <SectionItem route={'people_task'} name={'My Tasks Portal'}/>  
            </View> 
            <View style={styles.underline}/>
            <Pressable  style={[styles.contentBox,{justifyContent:'space-between'}]}>
              <Pressable onPress={()=>navigation.navigate('department')} style={{flexDirection:'row',alignItems: 'center'}}><GlobalIcon name="building" library="FontAwesome5" size={hp(2.5)} color={MyColors.headerTitle} /><Text style={styles.text}>Departments</Text></Pressable>
            </Pressable> 
            <View style={styles.underline}/>
            <Pressable  style={[styles.contentBox,{justifyContent:'space-between'}]}> 
              <View style={{flexDirection:'row',alignItems: 'center',marginBottom: hp(1)}}><ReportIcon/><Text style={styles.text}>Reports</Text></View><GlobalIcon name="caretup" library="AntDesign" size={hp(1.5)} color={MyColors.mainYellow} />
            </Pressable>
            <Pressable  style={[styles.contentBox,{flexDirection:'column'}]}>
            <SectionItem route={'report_project'} name={'Project Report'}/>
            <SectionItem route={'report_custome'} name={'Custom Report'}/> 
            </Pressable> 
            <View style={styles.underline}/>
            
            <Pressable  style={[styles.contentBox,{justifyContent:'space-between'}]}>
              <View style={{flexDirection:'row',alignItems: 'center',marginBottom: hp(1)}}><TimeIconSvg height={hp(3)} width={hp(3)} color={MyColors.mainYellow} /><Text style={styles.text}>Time</Text></View><GlobalIcon name="caretup" library="AntDesign" size={hp(1.5)} color={MyColors.mainYellow} />
            </Pressable>

            <Pressable  style={[styles.contentBox,{flexDirection:'column'}]}>
            <SectionItem route={'time_entry'} name={'Project Report'}/> 
            <SectionItem route={'time_approve'} name={'Custom Report'}/>  
            </Pressable> 
            <View style={styles.underline}/>
            <Pressable  style={[styles.contentBox,{justifyContent:'space-between'}]}>
              <View style={{flexDirection:'row',alignItems: 'center', marginBottom: hp(1)}}><GlobalIcon name="admin-panel-settings" library="MaterialIcons" size={hp(3)} color={MyColors.mainYellow} /><Text style={styles.text}>Admin Settings</Text></View><GlobalIcon name="caretup" library="AntDesign" size={hp(1.5)} color={MyColors.mainYellow} />
            </Pressable>

            <Pressable  style={[styles.contentBox,{flexDirection:'column'}]}>
            <SectionItem route={'admin_users'} name={'Users'}/> 
            <SectionItem route={'admin_requests'} name={'Pending Request'}/>  
            <SectionItem route={'admin_users'} name={'Workflow'}/>  
            <SectionItem route={'admin_users'} name={'Project Template'}/>  
            <SectionItem route={'admin_archive'} name={'Archive'}/>  
            </Pressable> 

            <View style={styles.bottom}/>
        </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header:{
    height:hp(9.5),
    marginTop:hp(2.5),
    flexDirection:'row',
    justifyContent:'space-between',
    alignItems:'center',
    alignContent: 'center',
    backgroundColor:MyColors.mainYellow,
    paddingVertical:10,
    paddingHorizontal:20
  },
  logo:{
    height:hp(3),
    width:hp(3),
    resizeMode:'contain',
  },
  headerTitle:{
    fontSize:25,
    fontFamily:MyFonts.OpenSansBold, 
    color:MyColors.black,
    paddingLeft:10,
  },
  drawerContents: {
    marginHorizontal:hp(4),
    marginTop:hp(2)
  }, 
  contentBox:{
    flexDirection:'row',  
  },
  text:{
    paddingLeft:hp(2.5),
    textTransform:'capitalize',
    fontFamily:MyFonts.OpenSansRegular,
    color:MyColors.mainYellow
  },
  text_title:{
    textAlign:'left',
    paddingLeft:hp(5.8),
    paddingVertical:hp(0.7),
    textTransform:'capitalize',
    fontFamily:MyFonts.OpenSansRegular, 
    color:MyColors.black
  },
  underline:{
    marginVertical:hp(3),
    borderWidth:0.2,
    borderColor:MyColors.disable, 
  },
  bottom:{
    marginBottom:hp(5)
  },
  selectedMenuItem: {
    color: MyColors.mainYellow
  }
});

export default AppDrawer;