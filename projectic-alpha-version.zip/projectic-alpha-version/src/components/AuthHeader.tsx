import React from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  Platform,
  StyleSheet,
} from 'react-native';
import GlobalIcon from '../config/GlobalIcons';
import {MyColors} from '../config/MyColors';
import {StatusBarHeight, hp, screen_width} from '../utils/constants';
import EmailIconSvg from '../assets/svgs/EmailIconSvg';
import {MyFonts} from '../config/MyFonts';
import {responsiveSize} from '../config/Metrix';

interface AuthHeaderProps {
  onBackPress: () => void;
  heading: string;
  subHeading: string;
  imagePath?: string;
  topIcon?: any;
}

const AuthHeader: React.FC<AuthHeaderProps> = ({
  onBackPress,
  heading,
  subHeading,
  imagePath,
  topIcon,
}) => {
  return (
    <View style={styles.main}>
      <TouchableOpacity style={[styles.back, {
        marginTop: topIcon ? 0 : 30
      }]} onPress={onBackPress}>
        <GlobalIcon
          library="Ionicons"
          name="chevron-back-outline"
          color={MyColors.black}
          size={hp(3)}
        />
      </TouchableOpacity>
      {topIcon ? (
        <>
          <View style={styles.svg}>{topIcon}</View>
          <View>
            <Text style={styles.heading}>{heading}</Text>
            <Text style={styles.sub}>{subHeading}</Text>
          </View>
        </>
      ) : (
        <View
          style={styles.container}>
          <Text style={styles.title}>{heading}</Text>
          <Text style={styles.subTitle}>{subHeading}</Text>
        </View>
      )}
    </View>
  );
};

export default AuthHeader;

const styles = StyleSheet.create({
  main: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    // paddingLeft: hp(3),
  },
  back: {
    paddingTop: hp(3),
    paddingBottom: hp(4)
  },
  svg: {
    paddingBottom: hp(1.5),
  },
  heading: {
    color: MyColors.black,
    fontFamily: MyFonts.OpenSansBold,
    fontSize: hp(4),
    fontWeight: 'bold',
  },
  sub: {
    fontSize: hp(1.8),
    color: 'gray',
    fontFamily: MyFonts.OpenSansRegular,
  },
  container:{
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    marginTop: hp(3)
  },
  title: {
    color: MyColors.lightBlack,
    fontFamily: MyFonts.OpenSansBold,
    fontSize: responsiveSize(30),
    textAlign: 'center',
  },
  subTitle: {
    color: MyColors.grayText,
    fontFamily: MyFonts.OpenSansRegular,
    fontSize: responsiveSize(15),
    textAlign: 'center',
    width: screen_width / 1.2,
    marginTop: 11
  },
});
