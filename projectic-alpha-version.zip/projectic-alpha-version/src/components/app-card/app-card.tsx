import { ColorValue, Pressable, StyleSheet, Text, View ,TouchableOpacity} from 'react-native'
import React, { CSSProperties } from 'react'
import { hp } from '../../utils/constants';
import GlobalIcon from '../../config/GlobalIcons';
import { MyColors } from '../../config/MyColors';
import { MyFonts } from '../../config/MyFonts'; 


interface IProps { 
    title?: string;  
    label?: string;  
    number?: number;  
    iconName?:string; 
    library?:string; 
    iconBgColor?:ColorValue, 
    amount?:string,
    amountTitle?:string,
    numberStyle?: any,
    navigation?:string,
    onpress?:()=>void,
    onpress1?:()=>void,
    actualAmount?: string
  }
  const AppCard: React.FC<IProps> = ({ title,label,number,iconName,library,numberStyle,iconBgColor,amount,amountTitle,onpress,onpress1, actualAmount}) => { 
  return (
    <View style={styles.cotainer}>
        <View style={styles.leftBox}>
            <View><Text style={styles.title}>{title}</Text></View>
            <View>
                { number !== undefined ? 
                <Text style={[styles.number, {...numberStyle}]}>{number}</Text>
                :
                <View style={{}}>
                <Text style={styles.budgetTitle}>{amountTitle}</Text>
                <Text style={[styles.number, {color: MyColors.headerTitle}]}>${amount}</Text>
                </View>}
            </View>
            <TouchableOpacity onPress={onpress} style={styles.bottomBox}><Text style={styles.viewText}>View All</Text><GlobalIcon color={MyColors.black} size={hp(2)} name={'chevron-small-right'} library={'Entypo'} /></TouchableOpacity>
        </View>

        <View style={styles.rightBox}>
        <View style={[styles.iconBox,{backgroundColor:iconName && iconBgColor}]}>{iconName &&<GlobalIcon color={MyColors.white} size={hp(5)} name={iconName} library={library} />}</View>
            {  actualAmount &&
            <View style={{top: hp(-2)}}>
                <Text style={styles.amounttitle}>Actual</Text>
                <Text style={[styles.number, {color: MyColors.greenPrimary}]}>${actualAmount}</Text>
            </View>
            }
        <TouchableOpacity onPress={onpress1} style={[styles.bottomBox, {marginTop: 20}]}>{label && <><GlobalIcon color={MyColors.black} size={hp(1.5)} name={'plus'} library={'AntDesign'} /><Text style={styles.viewText}> {label}</Text></>}</TouchableOpacity>
        </View>
    </View>
  )
}

export default AppCard

const styles = StyleSheet.create({
    cotainer:{ 
        flex:1, 
        minHeight:hp(18),
        // maxHeight: hp(25),
        flexDirection:'row',
        backgroundColor: MyColors.white,  
        marginTop:hp(2), 
        borderWidth:0.4,
        borderColor:MyColors.white,
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 0.1,
        elevation: 1,
    },
    leftBox:{
        width:'50%', 
        paddingLeft:20,
        justifyContent:'space-around',
        paddingVertical: hp(2)
    },
    budgetTitle:{
        fontSize:hp(1.8), 
        textTransform:'capitalize',
        fontFamily:MyFonts.OpenSansSemiBold,
        color: MyColors.headerTitle
    },
    rightBox:{
        width:'50%',
        alignItems:'flex-end',
        justifyContent:'space-around',
        paddingRight: 20,
        paddingVertical: hp(2)
    },
    title:{
        fontSize:hp(2),
        fontFamily: MyFonts.OpenSansBold,
        color: MyColors.headerTitle
    },
    number:{
        fontSize:hp(3),
        color:MyColors.textTitle,
        fontFamily: MyFonts.OpenSansBold
    },
    amounttitle:{
        fontSize:hp(1.8),
        textAlign:'right',
        textTransform:'capitalize',
        fontFamily:MyFonts.OpenSansSemiBold,
        color: MyColors.headerTitle
    },
    viewText:{
        fontSize:hp(1.6),
        fontFamily: MyFonts.OpenSansSemiBold,
        color: MyColors.headerTitle
    },
    iconBox:{
        borderRadius:4,
        height: 55,
        width: 55,
        justifyContent: 'center',
        alignItems: 'center'
    },
    bottomBox:{
        flexDirection:'row',
        alignItems:'center',  
    }
})