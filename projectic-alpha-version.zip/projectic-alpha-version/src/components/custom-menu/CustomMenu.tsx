import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {MyColors} from '../../config/MyColors';
import {hp} from '../../utils/constants';
import GlobalIcon from '../../config/GlobalIcons';
import {responsiveSize} from '../../config/Metrix';
import {MyFonts} from '../../config/MyFonts';

interface CustomMenuProps {
  onPress?: () => void;
  onPress1?: () => void;
  onPress2?: () => void;
}

const CustomMenu: React.FC<CustomMenuProps> = ({
  onPress,
  onPress1,
  onPress2,
}) => {
  return (
    <View style={styles.container}>
      <View style={styles.icon}>
        <GlobalIcon
          library="Entypo"
          name="arrow-up"
          color={MyColors.white}
          size={hp(3)}
        />
      </View>
      <TouchableOpacity
        onPress={onPress}
        style={[styles.item, {paddingTop: 0}]}>
        <GlobalIcon
          library="MaterialIcons"
          name="view-column"
          size={hp(2)}
          color={MyColors.black}
        />
        <Text style={styles.title}>Columns</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={onPress1} style={styles.item}>
        <GlobalIcon
          library="MaterialCommunityIcons"
          name="filter"
          size={hp(2)}
          color={MyColors.black}
        />
        <Text style={styles.title}>Filters</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={onPress2} style={styles.item}>
        <GlobalIcon
          library="Entypo"
          name="save"
          size={hp(2)}
          color={MyColors.black}
        />
        <Text style={styles.title}>Saved Filters</Text>
      </TouchableOpacity>
    </View>
  );
};

export default CustomMenu;

const styles = StyleSheet.create({
  container: {
    backgroundColor: MyColors.white,
    borderRadius: hp(1),
    zIndex: 1,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  icon: {
    alignSelf: 'flex-end',
    marginRight: hp(1),
    marginTop: hp(-1.3),
  },
  item: {
    paddingHorizontal: hp(2),
    paddingVertical: hp(2),
    borderBottomWidth: 1,
    borderBottomColor: '#DAE2F9',
    flexDirection: 'row',
    alignItems: 'center',
  },
  title: {
    marginLeft: hp(1),
    color: MyColors.black,
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansSemiBold,
  },
});
