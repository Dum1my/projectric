import { GestureResponderEvent, StyleSheet, View, ViewStyle } from 'react-native';
import React from 'react'; 
import AppButton from '../app-button/app-button';
import CustomButton from '../Buttons/CustomButton';
import { MyColors } from '../../config/MyColors';
import { MyStylesMain } from '../../styles/GlobalStyles';

interface IProps { 
    onPress?: (() => void) | undefined;
    onPressbtn1?: (() => void) | undefined;
    onPressbtn2?: (() => void) | undefined;
    title?: string;
    title1?: string;
    title2?: string;
    footerbtnSty?:ViewStyle;
    btnSty1?:ViewStyle;
    textsty1?:ViewStyle;
    btnSty2?:ViewStyle;
    single?: boolean;
    duble?: boolean;
}

const FooterIndex: React.FC<IProps> = ({title,title1,title2,onPress,footerbtnSty ,single,duble,btnSty1,textsty1,btnSty2,onPressbtn1,onPressbtn2}) => { 
  const globalStyle = MyStylesMain()
  return (
    <View style={styles.container}>  

            { single &&
               <View style={[styles.btnContainer]}>
               <CustomButton  title={title}  size='large'   onPress={onPress}  loading={false}   textStyle={styles.btnText} 
               style={[    globalStyle.gButton, {  backgroundColor: MyColors.mainYellow,  },  ]}/>
               </View>
            }

            
        {duble &&
             <View style={styles.footerBox}>
             <AppButton title={title1} style={[styles.btn1,btnSty1]} textStyle={[styles.text1,textsty1]} onPress={onPressbtn1}/>
             <AppButton title={title2}style={[styles.btn2,btnSty2]} textStyle={styles.text2} onPress={onPressbtn2}/>
            </View>
        }
       
    </View>
  );
};

export default FooterIndex;

const styles = StyleSheet.create({
    container:{

    },
    btnContainer:{
      flexDirection:'row',
      width:'100%'
    },
    btn:{ 
    },
    btnText:{ 
      color: MyColors.black,
      fontSize:13,
    },
    footerBox:{
      width:'50%', 
      flexDirection:'row', 
    },
    btn1:{
      borderRadius:25,
      backgroundColor:MyColors.white,
      borderColor:MyColors.mainYellow,
      borderWidth:1,
      color:MyColors.black,
      // width:'70%',
    },
    text1:{
      color:MyColors.mainYellow
    },
    btn2:{
      borderRadius:25,
      backgroundColor:MyColors.mainYellow,  
    },
    text2:{
      color:MyColors.black
    }
})