import * as React from 'react';
import { View, StyleSheet, Image, Text, TouchableOpacity, SafeAreaView, ScrollView, Pressable } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { MyColors } from '../../config/MyColors';
import { hp, useCustomSafeAreaInsets } from '../../utils/constants';
import GlobalIcon from '../../config/GlobalIcons';
import { MyFonts } from '../../config/MyFonts';
 

interface IProps {
    headerTitle?:string;
    showBackIcon?:boolean;
    showRightIcon?:boolean;
    onPressRight?: (() => void) | undefined;
  }
const AppHeader: React.FC<IProps> = ({headerTitle,showBackIcon ,showRightIcon,onPressRight}) => {  
    const navigation:any = useNavigation(); 

  return (
    <SafeAreaView style={styles.container}>
      {
        showBackIcon == true? 
        <Pressable  onPress={()=>navigation.goBack()} style={styles.leftIcon}><GlobalIcon color={MyColors.white} size={hp(2.5)} name={'chevron-back'} library={'Ionicons'} /></Pressable>
        :
        <Pressable  onPress={()=>navigation.openDrawer()}  style={styles.leftIcon}><GlobalIcon color={MyColors.white} size={hp(3)} name={'menu'} library={'Entypo'} /></Pressable>
      }
        <TouchableOpacity style={styles.heading}><Text style={styles.headerText}>{headerTitle}</Text></TouchableOpacity>
        {<Pressable onPress={onPressRight} style={styles.rightIcon}>{showRightIcon &&  <GlobalIcon color={MyColors.white} size={hp(2)} name={'equalizer'} library={'Fontisto'} />}</Pressable>}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { 
    flexDirection:'row',
    backgroundColor:MyColors.mainYellow,
    height:hp(12), 
    width:'100%',
    justifyContent:'space-between',
    alignItems:'center',  
    alignContent: 'center',
    paddingHorizontal:hp(2), 
    paddingTop:hp(3)
  },
  leftIcon:{
    width: '15%'
  },
  heading:{
    // marginRight:hp(1.5), 
    alignItems: 'center',
    width: '70%'
  },
  rightIcon:{
    transform: [ 
      { rotate: "90deg" },
    ],
    width: '15%', 
    top: hp(2)
  },
  headerText:{
    fontSize:hp(1.6),
    color:MyColors.black,
    fontFamily:MyFonts.OpenSansBold
  }
});

export default AppHeader;