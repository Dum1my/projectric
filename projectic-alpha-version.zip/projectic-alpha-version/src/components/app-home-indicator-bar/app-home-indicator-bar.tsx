import React from 'react';
import { ColorValue, Platform, SafeAreaView } from 'react-native';

interface IProps {
    backgroundColor: ColorValue;
    children: any
}

const AppHomeIndicatorBar: React.FC<IProps> = ({  children }) => (
    <>
        {(Platform.OS === 'android') && (
            <SafeAreaView style={{ flex: 1, }}>
                {children}
            </SafeAreaView> 
        )}
        {(Platform.OS === 'ios') && (
            <SafeAreaView style={{ flex: 1,  }}>
                {children}
            </SafeAreaView>
        )}
    </>
);

export default AppHomeIndicatorBar;