// KeyboardAvoidingWrapper.tsx
import React, { ReactNode } from 'react';
import { View, KeyboardAvoidingView, Platform } from 'react-native';

interface KeyboardAvoidingWrapperProps {
    children: ReactNode;
}

const KeyboardAvoidingWrapper: React.FC<KeyboardAvoidingWrapperProps> = ({ children }) => {
    return (
        <View style={{ flex: 1, backgroundColor: '#fff' }}>
            {Platform.OS === 'ios' ? (
                <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding" keyboardVerticalOffset={0}>
                    {children}
                </KeyboardAvoidingView>
            ) : (
                <View style={{ flex: 1 }}>{children}</View>
            )}
        </View>
    );
};

export default KeyboardAvoidingWrapper;
