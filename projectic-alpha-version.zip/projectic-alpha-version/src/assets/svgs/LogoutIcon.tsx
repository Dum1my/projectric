import React from 'react';
import {Path, Svg} from 'react-native-svg';
import {hp} from '../../utils/constants';

const LogoutIcon = ({height, width}: any) => {
  return (
    <Svg width={hp(width)} height={hp(height)} viewBox="0 0 18 20">
      <Path
        id="turn-off"
        d="M12,2a1,1,0,0,1,1,1V13a1,1,0,0,1-2,0V3A1,1,0,0,1,12,2ZM8.866,5.57A1,1,0,0,1,8.5,6.936a7,7,0,1,0,7,0,1,1,0,1,1,1-1.731,9,9,0,1,1-9,0A1,1,0,0,1,8.866,5.57Z"
        transform="translate(-3 -2)"
        fill="#fff"
        fill-rule="evenodd"
      />
    </Svg>
  );
};

export default LogoutIcon;
