import * as React from "react";
import Svg, { G, Path } from "react-native-svg";

const ProjectIcon = () => (
<Svg width="25.897" height="23" viewBox="0 0 25.897 23">
  <G id="breifcase" transform="translate(-100 -144.79)">
    <Path id="Path_75143" data-name="Path 75143" d="M115.211,509.353h-4.525v-1.521H100v9.679a1.568,1.568,0,0,0,1.568,1.568h22.761a1.568,1.568,0,0,0,1.568-1.571V507.83H115.211Z" transform="translate(0 -351.288)" fill="#f7b31e"/>
    <Path id="Path_75144" data-name="Path 75144" d="M274.248,149.785v-2.277a.291.291,0,0,1,.291-.291h9.335a.291.291,0,0,1,.291.291v2.277h2.428v-2.458a2.54,2.54,0,0,0-2.537-2.537h-9.7a2.54,2.54,0,0,0-2.537,2.537v2.458Z" transform="translate(-166.258 0)" fill="#f7b31e"/>
    <Path id="Path_75145" data-name="Path 75145" d="M124.329,319.1H101.568A1.568,1.568,0,0,0,100,320.668v3.894h10.686v-1.521h4.525v1.521H125.9v-3.894A1.568,1.568,0,0,0,124.329,319.1Z" transform="translate(0 -168.667)" fill="#f7b31e"/>
  </G>
</Svg>

);
export default ProjectIcon;
