import React from 'react';
import Svg, {G, Circle, Path} from 'react-native-svg';

const LockIcon = () => {
  return (
    <Svg width="54.019" height="50" viewBox="0 0 54.019 50">
      <G
        id="Group_29717"
        data-name="Group 29717"
        transform="translate(-58 -149)">
        <Circle
          id="Ellipse_391"
          data-name="Ellipse 391"
          cx="23"
          cy="23"
          r="23"
          transform="translate(58 153)"
          fill="#fdb52d"
        />
        <G
          id="lock-padlock-symbol-for-security-interface"
          transform="translate(-5.138 149)">
          <G
            id="Group_29208"
            data-name="Group 29208"
            transform="translate(80.994)">
            <Path
              id="Path_75039"
              data-name="Path 75039"
              d="M99.076,0A14.639,14.639,0,0,0,84.454,14.622v8.351a.393.393,0,0,1-.209.285c-.791.264-1.433.492-2.021.719a2.023,2.023,0,0,0-1.23,1.807V44.973a2.037,2.037,0,0,0,1.222,1.808,45.769,45.769,0,0,0,33.72,0,2.037,2.037,0,0,0,1.221-1.808V25.785a2.023,2.023,0,0,0-1.23-1.807c-.588-.227-1.23-.455-2.02-.719a.393.393,0,0,1-.209-.285V14.622A14.639,14.639,0,0,0,99.076,0ZM95.093,31.629a3.982,3.982,0,1,1,7.965,0A3.923,3.923,0,0,1,101.067,35v6.584a1.991,1.991,0,1,1-3.982,0V35A3.923,3.923,0,0,1,95.093,31.629ZM108.67,14.622v7.205a45.644,45.644,0,0,0-19.189,0v-7.2a9.594,9.594,0,0,1,19.189,0Z"
              transform="translate(-80.994)"
              fill="#34445a"
            />
          </G>
        </G>
      </G>
    </Svg>
  );
};

export default LockIcon;
