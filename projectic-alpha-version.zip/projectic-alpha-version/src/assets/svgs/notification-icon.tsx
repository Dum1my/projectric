import * as React from "react";
import Svg, { G, Path } from "react-native-svg";
const NotificationsIcon = (props) => { 
    return(
  <Svg
    xmlns="http://www.w3.org/2000/svg"
    width={19.25}
    height={21}
    viewBox="0 0 19.25 21"
    {...props}
  >
    <G id="notification" transform="translate(0.001)">
      <Path
        id="Path_74939"
        data-name="Path 74939"
        d="M138.18,450.625A3.286,3.286,0,0,0,141.394,448h-6.429A3.287,3.287,0,0,0,138.18,450.625Zm0,0"
        transform="translate(-129.43 -429.625)"
        fill={props.color}
      />
      <Path
        id="Path_74940"
        data-name="Path 74940"
        d="M14.885,51.417h-.011a6.132,6.132,0,0,1-6.125-6.125,6.07,6.07,0,0,1,.585-2.6c-.193-.018-.388-.03-.585-.03a6.125,6.125,0,0,0-6.125,6.125v2.439a5.867,5.867,0,0,1-2.09,4.491,1.531,1.531,0,0,0-.481,1.572,1.605,1.605,0,0,0,1.573,1.123h14.24a1.6,1.6,0,0,0,1.6-1.214,1.534,1.534,0,0,0-.522-1.5,5.822,5.822,0,0,1-2.06-4.289Zm0,0"
        transform="translate(0 -40.918)"
        fill={props.color}
      />
      <Path
        id="Path_74941"
        data-name="Path 74941"
        d="M264.762,4.375A4.375,4.375,0,1,1,260.387,0,4.375,4.375,0,0,1,264.762,4.375Zm0,0"
        transform="translate(-245.513)"
        fill={props.circleColor}
      />
    </G>
  </Svg>
)
    }
export default NotificationsIcon;