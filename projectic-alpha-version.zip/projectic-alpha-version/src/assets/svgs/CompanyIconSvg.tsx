import * as React from "react";
import Svg, { G, Circle, Path } from "react-native-svg";
const CompanyIconSvg = () => (
  <Svg
    width={60.937}
    height={50}
    viewBox="0 0 60.937 50"
  >
    <G id="Group_29717" data-name="Group 29717" transform="translate(-58 -149)">
      <Circle
        id="Ellipse_391"
        data-name="Ellipse 391"
        cx={23}
        cy={23}
        r={23}
        transform="translate(58 153)"
        fill="#fdb52d"
      />
      <Path
        id="Path_75113"
        data-name="Path 75113"
        d="M42.5,45V0H7.5V45H0v5H50V45ZM22.5,5h5v5h-5Zm0,10h5v5h-5Zm0,10h5v5h-5Zm-5,5h-5V25h5Zm0-10h-5V15h5Zm0-10h-5V5h5ZM30,45H20V35H30Zm7.5-15h-5V25h5Zm0-10h-5V15h5Zm0-10h-5V5h5Z"
        transform="translate(68.938 149)"
        fill="#34445a"
      />
    </G>
  </Svg>
);
export default CompanyIconSvg;
