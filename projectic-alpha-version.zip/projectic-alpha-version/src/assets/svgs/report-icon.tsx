import * as React from "react";
import Svg, { G, Path } from "react-native-svg";

const ReportIcon = () => (
<Svg  width="25.692" height="26.026" viewBox="0 0 25.692 26.026">
  <G id="analytics" transform="translate(-3 0)">
    <G id="Group_29785" data-name="Group 29785" transform="translate(3 7.73)">
      <G id="Group_29784" data-name="Group 29784" transform="translate(0)">
        <Path id="Path_75150" data-name="Path 75150" d="M132,185h4.171v15.738H132Z" transform="translate(-124.826 -182.442)" fill="#f7b31e"/>
        <Path id="Path_75151" data-name="Path 75151" d="M261,245h4.171v12.4H261Z" transform="translate(-246.652 -239.105)" fill="#f7b31e"/>
        <Path id="Path_75152" data-name="Path 75152" d="M390,139h4.171v18.3H390Z" transform="translate(-368.479 -139)" fill="#f7b31e"/>
        <Path id="Path_75153" data-name="Path 75153" d="M3,292H7.171v9.788H3Z" transform="translate(-3 -283.492)" fill="#f7b31e"/>
      </G>
    </G>
    <Path id="Path_75154" data-name="Path 75154" d="M28.457,0a2.11,2.11,0,0,0-1.965,2.883L22.422,6.35a2.113,2.113,0,0,0-2.537.406L16.372,5.316c0-.014,0-.027,0-.041a2.112,2.112,0,1,0-4.195.346L8.529,7.78a2.11,2.11,0,1,0,.777,1.311l3.65-2.158a2.111,2.111,0,0,0,2.838-.206l3.513,1.439c0,.014,0,.027,0,.041a2.112,2.112,0,1,0,4.105-.7L27.526,4a2.111,2.111,0,1,0,.931-4Z" transform="translate(-1.994)" fill="#f7b31e"/>
  </G>
</Svg>

);
export default ReportIcon;
