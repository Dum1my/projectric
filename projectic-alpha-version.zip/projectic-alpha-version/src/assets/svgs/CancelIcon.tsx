import React from 'react'
import { Circle, Path, Svg } from 'react-native-svg'
import { hp } from '../../utils/constants'

const CancelIcon = ({height, width}: any) => {
  return (
    <Svg id="cancel_1_" data-name="cancel (1)" width={hp(width)} height={hp(height)} viewBox="0 0 78.883 78.883">
  <Circle id="Ellipse_449" data-name="Ellipse 449" cx="39.441" cy="39.441" r="39.441" transform="translate(0 0)" fill="#e24c4b"/>
  <Path id="Path_75231" data-name="Path 75231" d="M120.032,80.592a39.557,39.557,0,0,1-39.441,39.441,38.811,38.811,0,0,1-30.814-14.79,38.914,38.914,0,0,0,24.651,8.628A39.557,39.557,0,0,0,113.869,74.43a38.914,38.914,0,0,0-8.628-24.651A38.81,38.81,0,0,1,120.032,80.592Z" transform="translate(-41.149 -41.151)" fill="#d1403f"/>
  <Path id="Path_75232" data-name="Path 75232" d="M154.434,154.434a3.869,3.869,0,0,1-5.423,0l-12.572-12.572-12.572,12.572a3.835,3.835,0,1,1-5.423-5.423l12.572-12.572-12.572-12.572a3.835,3.835,0,0,1,5.423-5.423l12.572,12.572,12.572-12.572a3.835,3.835,0,1,1,5.423,5.423l-12.572,12.572,12.572,12.572A3.869,3.869,0,0,1,154.434,154.434Z" transform="translate(-96.997 -96.997)" fill="#fff"/>
</Svg>

  )
}

export default CancelIcon
