import * as React from "react";
import Svg, { G, Circle, Path } from "react-native-svg";
const EmailIconSvg = () => (
  <Svg
    width={60.874}
    height={50}
    viewBox="0 0 60.874 50"
  >
    <G id="Group_29209" data-name="Group 29209" transform="translate(-58 -149)">
      <Circle
        id="Ellipse_391"
        data-name="Ellipse 391"
        cx={23}
        cy={23}
        r={23}
        transform="translate(58 153)"
        fill="#fdb52d"
      />
      <Path
        id="arroba"
        d="M50.105,21.942a24.927,24.927,0,1,0-27.991,28.24,25.815,25.815,0,0,0,3.344.219,24.679,24.679,0,0,0,12.816-3.564,2.412,2.412,0,0,0-2.489-4.132,20.1,20.1,0,1,1,8.638-10.644,3.482,3.482,0,0,1-3.342,2.26,3.6,3.6,0,0,1-3.593-3.593v-14.9a2.412,2.412,0,1,0-4.823,0v.023a12.058,12.058,0,1,0,.87,18.525,8.4,8.4,0,0,0,7.546,4.764,8.307,8.307,0,0,0,7.9-5.5,24.975,24.975,0,0,0,1.124-11.7ZM25.43,32.714a7.235,7.235,0,1,1,7.235-7.235A7.235,7.235,0,0,1,25.43,32.714Z"
        transform="translate(68.519 148.599)"
        fill="#34445a"
      />
    </G>
  </Svg>
);
export default EmailIconSvg;
