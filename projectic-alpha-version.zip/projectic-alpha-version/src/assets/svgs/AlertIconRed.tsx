import * as React from "react";
import Svg, { Circle, G, Path } from "react-native-svg";
const AlertIconRed = () => (
  <Svg
    width={78.883}
    height={78.883}
    viewBox="0 0 78.883 78.883"
  >
    <Circle
      id="Ellipse_421"
      data-name="Ellipse 421"
      cx={39.441}
      cy={39.441}
      r={39.441}
      fill="#ff1f1f"
    />
    <G
      id="Group_29923"
      data-name="Group 29923"
      transform="translate(32.6 9.266)"
    >
      <Path
        id="Path_75224"
        data-name="Path 75224"
        d="M2.633,40.117,1.056,6.022c-.354-7.655,14.022-7.608,13.67,0L13.15,40.117v2.77a5.259,5.259,0,1,1-10.518,0Z"
        transform="translate(-1.05 -0.298)"
        fill="#fff"
        fillRule="evenodd"
      />
      <Circle
        id="Ellipse_422"
        data-name="Ellipse 422"
        cx={5.249}
        cy={5.249}
        r={5.249}
        transform="translate(1.593 49.928)"
        fill="#fff"
      />
    </G>
  </Svg>
);
export default AlertIconRed;
