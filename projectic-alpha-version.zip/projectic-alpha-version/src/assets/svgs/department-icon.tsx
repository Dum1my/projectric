import * as React from "react";
import Svg, { G, Path, Rect } from "react-native-svg";

const DepartmentIcon = () => (
<Svg  width="35" height="35" viewBox="0 0 35 35">
  <Rect id="Rectangle_143" data-name="Rectangle 143" width="35" height="35" fill="#fff" opacity="0"/>
</Svg>

);
export default DepartmentIcon;
