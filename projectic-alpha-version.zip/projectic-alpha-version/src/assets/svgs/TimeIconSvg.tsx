import * as React from "react";
import Svg, { G, Path } from "react-native-svg";
const TimeIconSvg = ({color,height,width}) => (
  <Svg
    width={height}
    height={width}
    viewBox="0 0 78.883 78.883"
  >
    <G id="Layer_2" data-name="Layer 2" transform="translate(-1 -1)">
      <Path
        id="Path_75155"
        data-name="Path 75155"
        d="M33.109,5.5A27.609,27.609,0,1,0,60.718,33.109,27.609,27.609,0,0,0,33.109,5.5ZM45.678,42.628a2.626,2.626,0,0,1-2.051,1A2.531,2.531,0,0,1,42,43.048L31.478,35.16a2.631,2.631,0,0,1-1-2.051V14.7a2.629,2.629,0,1,1,5.259,0V31.847l9.519,7.1a2.581,2.581,0,0,1,.42,3.681Z"
        transform="translate(7.332 7.332)"
        fill={color}
      />
      <Path
        id="Path_75156"
        data-name="Path 75156"
        d="M40.441,1A39.441,39.441,0,1,0,79.883,40.441,39.441,39.441,0,0,0,40.441,1Zm0,72.485A33.043,33.043,0,1,1,73.485,40.441,33.043,33.043,0,0,1,40.441,73.485Z"
        fill={color}
      />
    </G>
  </Svg>
);
export default TimeIconSvg;
