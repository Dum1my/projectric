import * as React from "react";
import Svg, { G, Rect, Circle, Path } from "react-native-svg";
const ProfileIcon = (props) => { 
    return(
  <Svg
    xmlns="http://www.w3.org/2000/svg"
    width={21}
    height={21}
    viewBox="0 0 21 21"
    {...props}
  >
    <G
      id="setting_icon"
      data-name="setting icon"
      transform="translate(-76 -173)"
    >
      <Rect
        id="Rectangle_143"
        data-name="Rectangle 143"
        width={21}
        height={21}
        transform="translate(76 173)"
        fill="#fff"
        opacity={0}
      />
      <Circle
        id="Ellipse_44"
        data-name="Ellipse 44"
        cx={8.677}
        cy={8.677}
        r={8.677}
        transform="translate(77.822 174.823)"
        fill={props.color}
      />
      <G
        id="Ellipse_44-2"
        data-name="Ellipse 44"
        transform="translate(76 173)"
        fill="none"
        stroke={props.color}
        strokeWidth={1}
      >
        <Circle cx={10.5} cy={10.5} r={10.5} stroke="none" />
        <Circle cx={10.5} cy={10.5} r={10} fill="none" />
      </G>
      <Path
        id="user_2_"
        data-name="user (2)"
        d="M70.929.821a2.814,2.814,0,1,0,.824,1.99,2.814,2.814,0,0,0-.824-1.99Zm3.018,11.05q.02-.147.031-.294.015-.19.015-.391a5.053,5.053,0,1,0-10.107,0q0,.2.015.39.011.147.031.294a8.65,8.65,0,0,0,10.015,0Z"
        transform="translate(17.559 176.672)"
        fill="#fff"
        fillRule="evenodd"
      />
    </G>
  </Svg>
    )
}
export default ProfileIcon;