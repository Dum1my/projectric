// utils.js

import { Dimensions, StatusBar } from "react-native";
import { widthPercentageToDP, heightPercentageToDP } from 'react-native-responsive-screen';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {useEffect, useState} from 'react';

export const StatusBarHeight = () => {
    return StatusBar.currentHeight;
}

export const wp = (widthPercent :any) => widthPercentageToDP(widthPercent);
export const hp = (heightPercent : any) => heightPercentageToDP(heightPercent);

export const useCustomSafeAreaInsets = () => {
    const insets = useSafeAreaInsets(); 
return useSafeAreaInsets()
} 

export const screen_height = Dimensions.get('window').height;
export const screen_width = Dimensions.get('window').width;




const isPortrait = () => {
  const dim = Dimensions.get('screen');
  return dim.height >= dim.width;
};

export function useOrientation(): 'PORTRAIT' | 'LANDSCAPE' {
  const [orientation, setOrientation] = useState<'PORTRAIT' | 'LANDSCAPE'>(
    isPortrait() ? 'PORTRAIT' : 'LANDSCAPE',
  );

  useEffect(() => {
    const callback = () => setOrientation(isPortrait() ? 'PORTRAIT' : 'LANDSCAPE');

    Dimensions.addEventListener('change', callback);

    return () => {
      Dimensions.removeEventListener('change', callback);
    };
  }, []);

  return orientation;
}