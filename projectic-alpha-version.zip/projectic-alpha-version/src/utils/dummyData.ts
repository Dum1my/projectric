export const notificationsData = [
  {
    id: 1,
    title: 'Design Changes',
    description:
      'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam Lorem ipsum dolor sit amet,',
  },
  {
    id: 2,
    title: 'Development Updates',
    description:
      'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam Lorem ipsum dolor sit amet,',
  },
  {
    id: 3,
    title: 'Logo Approval',
    description:
      'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam Lorem ipsum dolor sit amet,',
  },
  {
    id: 4,
    title: 'Content Changes In Website',
    description:
      'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam Lorem ipsum dolor sit amet,',
  },
  {
    id: 4,
    title: 'Content Changes In Website',
    description:
      'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam Lorem ipsum dolor sit amet,',
  },
  {
    id: 4,
    title: 'Content Changes In Website',
    description:
      'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam Lorem ipsum dolor sit amet,',
  },
  {
    id: 4,
    title: 'Content Changes In Website',
    description:
      'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam Lorem ipsum dolor sit amet,',
  },
];
