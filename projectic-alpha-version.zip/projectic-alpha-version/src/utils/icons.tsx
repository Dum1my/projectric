// import { createIconSetFromIcoMoon } from 'react-native-vector-icons';
// import icoMoonConfig from '../assets/icomoon/selection.json';
// import React from 'react';
// const IconConfig = createIconSetFromIcoMoon(
//   icoMoonConfig,
//   'icomoon',
//   'icomoon.ttf'
// );

// const Icon = ({...props })=>{
// return <IconConfig    { ...props}/>
// }

// export default Icon;