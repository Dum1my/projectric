import React from "react"

export type User = {
    nameName?: String
}
export type colorsType = {
    color?: any
}
export type svgProps = {
    color?: any
}
export type isModalProps = {
    isModal?: boolean;
    onSwipeComplete?: () => void;
    onBackdropPress?: () => void;
    onPressEdit?: () => void;
    onPressProfile?: () => void;
    onPressFaqs?:any;
    onPressContact?:any;
    navigation?: any;
    onPressAbout?: any;
}
export type isModalDeleteProps = {
    isModal?: boolean;
    onSwipeComplete?: () => void;
    onBackdropPress?: () => void;
    onPressDelete?: () => void;
    onPressEditComment?: () => void;
    navigation?: any;
}
export type homeHeaderProps = {
    onPress?: () => void;
    isModal?: any;
    logo?: string
}


export interface btnProps {
    buttonText?: string;
    textStyle?: any;
    btnStyle?: any;
    onPress?: () => void;
    shadow?: boolean;
    disabled?: boolean;
    preIcon?: any;
    postIcon?: any;
    BackColor?: any;
    color?: any;
}
export interface myInputProps {
    preIcon?: any;
    postIcon?: any;
    placeholder?: string;
    width?:string;
    type?:string

}
export interface HeaderProps {
    onPress?: () => void;
    Heading?: any;
}

export interface inputProps {
    label: string,
    keyPad?: string,
    width: string,
    mt?: number,
    mb?: number,
    height?: number
    password?: boolean,
    onPress?: () => void,
    secureEntry?: boolean,
    onChangeText?: () => void,
    value?: string,
    errorText?: string,
    multiLine?: boolean,
    inputRef?: any
}
export interface optionProps {
    title?: string,
    text?: string,
    onPress?: () => void,
    isEnd: boolean,
    img?: string,
    imgComp?: any,
    active?: boolean,
}

export interface screenWrapper {
    children?: React.ReactNode,
    active?: boolean
}
export interface features {
    title: string,
    name?: string,
    onPress?: () => void,
    width: string,
    img?: string,
    backgroundColor?: string,
}

export interface selectionField {
    title: string,
    width?: string,
    border?: boolean,
    iconName?: string,
    borderColor?: string,
    onPress?: () => void,
    iconColor?: string,
    titleColor?: string,
    toggle?: boolean,
    mt?: number,
    mb?: number,
    data?: Array<object>,
    type?: string,
    errorText?: any,
    onChange?: (data: any) => void
}

export interface input {
    phText: string,
    keyPad?: any,
    width: string,
    height?: number,
    mt?: number,
    mb?: number,
    icon?: string,
    iconName?: string,
    mlinput?: boolean,
    img?: string,
    text?: string,
    onChangeText?: () => void,
    value?: string,
    errorText?: string

}

export interface notifications {
    img: any,
    title: string,
    time: string,
    userName: string,
    lastItem: boolean,
    onPress: () => void
}

export interface chat {
    img: any,
    title: string,
    time: string,
    userName: string,
    count: number,
}

export type TodoId = string;

export type Todo = {
    id: TodoId;
    title: string;
    completed: boolean;
};

export interface post {
    isComment: boolean,
    postType: string,
    onPressShare: () => void,
    onPressSeeShare: () => void,
    onPressLikeModal: () => void,
    onPressEdit: () => void,
    onPressAddComment: () => void,
    onPressVideo?: () => void,
}