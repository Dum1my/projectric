import type {
    CompositeScreenProps,
    NavigatorScreenParams,
} from '@react-navigation/native';



export type RootStackParamList = {
    welcome: undefined,
    LogInScreen: any,
    RegisterEmail: any,
    RegisterName: any,
    RegisterCompany: any,
    RegisterPassword: any,
    SettingScreen: any,
    PasswordRecovery: any,
    RecoveryCode: any,
    ResetPassword: any,
    RegistrationInProcess: any,



    BottomTabs: any,
    home: undefined,
    bookigs: undefined,
    bookingdetails: undefined,
    network: undefined,
    profile: any,
    notification: undefined
    aboutUs: undefined,
    contact: any,
    faqs: any,
    EditProfile: any,
    ChangePass: any,
    BookingsInner: any,
    BookConcert: any,
    BookingCalender: any,
    SlotSelection: any,
    GalleryAll: any,
    OurSongsAll: any,
    PaymentDetails: any,
    UserProfileStack: any,
    VideoScreen: any,

};




declare global {
  namespace ReactNavigation {
    interface RootParamList extends RootStackParamList {}
  }
}
  