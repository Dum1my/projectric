import {createNativeStackNavigator} from '@react-navigation/native-stack';
import React, {useState, useEffect} from 'react';
// import WelcomeScreen from '../screens/Auth/Welcome'
// import { ChangePassword, EditProfile, ForgotPassword, Home, Login, MusicRoom, Notifications, PrivacyPolicy, Profile, RoleScreen, Room, RoomPlayer, Search, SignUp, SignupScreenTwo, SocialVerification, Songs, TermsAndCondition, Verification, VerifyOTP } from '../screens'
// import BottomTabs from './BottomTabs'

import {Text, Platform} from 'react-native';
import SplashScreen from 'react-native-splash-screen';
import {useNavigation} from '@react-navigation/native';
import WelcomeScreen from '../screens/Auth/WelcomeScreen';
import LogInScreen from '../screens/Auth/LogInScreen';
import RegisterEmail from '../screens/Auth/RegisterEmail';
import RegisterName from '../screens/Auth/RegisterName';
import RegisterCompany from '../screens/Auth/RegisterCompany';
import RegisterPassword from '../screens/Auth/RegisterPassword';
import BottomTabs from './BottomTabs';
// import DrawerNavigator from './DrawerNavigator';
import PortFolios from '../screens/App/port-folious/PortFolios';
import {MyColors} from '../config/MyColors';
import AppDrawer from '../components/app-drawer/app-drawer';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import DashBoard from '../screens/App/DashBoard';
import AppTab from '../components/app-tabs/app-tabs';
import Profile from '../screens/App/Profile';
import Notifications from '../screens/App/Notifications';
import Reminders from '../screens/App/Reminders';
import ProjectIntake from '../screens/App/projects/project-index';
import ProjectTemplate from '../screens/App/projects/project-template';
import SelectTemplate from '../screens/App/projects/select-tamplate';
import ProjectAdd from '../screens/App/projects/project-add';
import BudgetIndex from '../screens/App/budget/budget-index/budget-index';
import ProjectWorkFlow from '../screens/App/projects/project-workFlow';
import PeopleView from '../screens/App/prople/people-view';
import PeopleUtilization from '../screens/App/prople/people-utilization';
import PeopleTaskPortal from '../screens/App/prople/people-task-portal';
import DepartmentIndex from '../screens/App/departments/departments-index/departments-index';
import ReportProject from '../screens/App/reports/report-project';
import ReportCustome from '../screens/App/reports/report-custome';
import TimeEntry from '../screens/App/time/time-entry';
import TimeAdd from '../screens/App/time/time-add';
import TimeApprove from '../screens/App/time/time-approve';
import AdminUsers from '../screens/App/admin/admin-users';
import AdminRequests from '../screens/App/admin/admin-requests';
import AdminArchive from '../screens/App/admin/admin-archive';
import PasswordRecovery from '../screens/Auth/PasswordRecovery';
import RecoveryCode from '../screens/Auth/RecoveryCode';
import ResetPassword from '../screens/Auth/ResetPassword';
import ProjectScore from '../screens/App/projects/project-add-score'; 
import ProjectView from '../screens/App/projects/project-view';
import ProjectPortfolio from '../screens/App/projects/project-portfolio';
import PortFoiloAdd from '../screens/App/port-folious/port-folio-add';
import PortFolioIndex from '../screens/App/port-folious/port-folio-views';
import RegistrationInProcess from '../screens/Auth/RegistrationInProcess';
import { hp } from '../utils/constants';
import { useSelector } from 'react-redux';
import { useAppSelector } from '../store/hooks';
import ProjectName from '../screens/App/projects/project-name';

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();
const Tab = createBottomTabNavigator();

const HomeStack = () => {
  return (
    <Stack.Navigator
      screenOptions={{headerShown: false}}
      initialRouteName="Dashboard"
      >
      <Stack.Screen name="Dashboard" component={DashBoard} />
      {/* <Stack.Screen name="port_folios" component={PortFolios} /> */}
      <Stack.Screen name="port_folios" component={PortFolioIndex} />
      <Stack.Screen name="project_intake" component={ProjectIntake} />
      <Stack.Screen name="project_view" component={ProjectView} />
      <Stack.Screen name="project_template" component={ProjectTemplate} />
      <Stack.Screen name="project_workflow" component={ProjectWorkFlow} />
      <Stack.Screen name="project_portfolio" component={ProjectPortfolio} />
      <Stack.Screen name="budget" component={BudgetIndex} />
      <Stack.Screen name="people_view" component={PeopleView} />
      <Stack.Screen name="people_utilization" component={PeopleUtilization} />
      <Stack.Screen name="people_task" component={PeopleTaskPortal} />

      <Stack.Screen name="department" component={DepartmentIndex} />

      <Stack.Screen name="report_project" component={ReportProject} />
      <Stack.Screen name="report_custome" component={ReportCustome} />

      <Stack.Screen name="time_entry" component={TimeEntry} />
      <Stack.Screen name="time_approve" component={TimeApprove} />

      <Stack.Screen name="admin_users" component={AdminUsers} />
      <Stack.Screen name="admin_requests" component={AdminRequests} />
      <Stack.Screen name="admin_archive" component={AdminArchive} />
    </Stack.Navigator>
  );
};

const BottomTabNavigator = () => (
  <Tab.Navigator
    initialRouteName="Home" 
    screenOptions={({route}) => ({  
      tabBarLabelPosition: 'below-icon',
      tabBarHideOnKeyboard: true,
      headerShown: false,
      keyboardHidesTabBar: true,
    })}
    tabBar={(props: any) => <AppTab {...props} />}>
    <Tab.Screen
      name="Dashboard"
      component={HomeStack}
      initialParams={{
        icon_name: 'dots-grid',
        library: 'MaterialCommunityIcons',
      }}
    />
    <Tab.Screen
      name="Reminders"
      component={Reminders}
      initialParams={{
        icon_name: 'calendar-month',
        library: 'MaterialCommunityIcons',
      }}
    />
    <Tab.Screen
      name="Notifications"
      component={Notifications}
      initialParams={{
        icon_name: 'bell-badge',
        library: 'MaterialCommunityIcons',
      }}
    />
    <Tab.Screen
      name="Profile"
      component={Profile}
      initialParams={{icon_name: 'user-circle', library: 'FontAwesome'}}
    />
  </Tab.Navigator>
);

const DrawerNavigator = () => {
  return (
    <Drawer.Navigator
      screenOptions={{headerShown: false, drawerStyle: {width: '90%'}}}
      drawerContent={props => <AppDrawer {...props} />}>
      <Drawer.Screen name="home" component={BottomTabNavigator} />
    </Drawer.Navigator>
  );
};

const AuthStack = () => {
  const [showSplash, setShowSplash] = useState(true);
  const navigation = useNavigation();
  const userData = useAppSelector(state => state.userSlice); 

  useEffect(() => {
    if (Platform.OS === 'android') {
      setTimeout(() => {
        SplashScreen.hide();
        setShowSplash(false);
      }, 3000);
    }
  }, []);

  return (
    <Stack.Navigator
      screenOptions={{headerShown: false}}
      initialRouteName={userData.initalRoute}>
      <Stack.Screen name="WelcomeScreen" component={WelcomeScreen} />
      <Stack.Screen name="LogInScreen" component={LogInScreen} />
      <Stack.Screen name="RegisterEmail" component={RegisterEmail} />
      <Stack.Screen name="RegisterName" component={RegisterName} />
      <Stack.Screen name="RegisterCompany" component={RegisterCompany} />
      <Stack.Screen name="RegisterPassword" component={RegisterPassword} />
      <Stack.Screen name="PasswordRecovery" component={PasswordRecovery} />
      <Stack.Screen name="RecoveryCode" component={RecoveryCode} />
      <Stack.Screen name="ResetPassword" component={ResetPassword} />
      <Stack.Screen name="RegistrationInProcess" component={RegistrationInProcess} />
    </Stack.Navigator>
  );
};

const UserStack = () => {
  return (
    <Stack.Navigator
      screenOptions={{headerShown: false}}
      initialRouteName="BottomTabs">
      <Stack.Screen name="MainDrawer" component={DrawerNavigator} />
      <Stack.Screen name="SelectTemplate" component={SelectTemplate} />
      {/* time entry */}
      <Stack.Screen name="time_add" component={TimeAdd} />
      {/* Project */}
      <Stack.Screen name="project_score" component={ProjectScore} />
      <Stack.Screen name="project_add" component={ProjectAdd} />
      <Stack.Screen name="portfolio_add" component={PortFoiloAdd} />
      <Stack.Screen name="project_name" component={ProjectName} />
    </Stack.Navigator>
  );
};

export {UserStack, AuthStack};
