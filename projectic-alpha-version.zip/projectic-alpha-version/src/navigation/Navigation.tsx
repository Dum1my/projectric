import { NavigationContainer } from '@react-navigation/native'
import React, { useEffect, useState } from 'react'
import { AuthStack, UserStack } from './Stack'
import SplashScreen from 'react-native-splash-screen'
import { StatusBar } from 'react-native'
import { useAppSelector } from '../store/hooks'

const Navigation = () => {
    const [splashVisible, setSplashVisible] = useState(true);
    const token = useAppSelector(state => state.userSlice.token);
    useEffect(() => {
        setTimeout(() => {
            SplashScreen.hide()
        }, 2000);
    }, []);

    return (
        <NavigationContainer> 
            <>
                {
                    token ?
                        <React.Fragment>
                            <StatusBar translucent barStyle={'dark-content'} backgroundColor={'transparent'} />
                            <UserStack />
                        </React.Fragment>
                        :
                        <React.Fragment>
                            <StatusBar translucent  barStyle={'dark-content'} backgroundColor={'transparent'} />
                            <AuthStack />
                        </React.Fragment>
                }
            </>
        </NavigationContainer>
    )
}
export default Navigation
