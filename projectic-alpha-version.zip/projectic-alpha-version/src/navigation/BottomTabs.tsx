import React, { useEffect, useState } from "react";
import { StyleSheet, View, TouchableOpacity, Text, Image, Platform, Animated, Keyboard } from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import DashBoard from "../screens/App/DashBoard";
import Reminders from "../screens/App/Reminders";
import Notifications from "../screens/App/Notifications";
import Profile from "../screens/App/Profile";
import GlobalIcon from "../config/GlobalIcons";
import { hp } from "../utils/constants";
import { MyColors } from "../config/MyColors";
import { MyFonts } from "../config/MyFonts";
import PortFolios from "../screens/App/port-folious/PortFolios";
import AppTab from "../components/app-tabs/app-tabs";
import DrawerNavigator from "./DrawerNavigator";

const setting = createNativeStackNavigator();


const BottomTabs: React.FC = () => { 
    
    const Tab = createBottomTabNavigator();
    const Stack = createNativeStackNavigator()

    const DashBoard = () => {
        return (
            <Stack.Navigator screenOptions={{ headerShown: false }}>
                <Stack.Screen name="portfolious" component={PortFolios} /> 
            </Stack.Navigator>
        );
    }

    return ( 
            <Tab.Navigator
                initialRouteName="dashboard" 
                screenOptions={{ 
                    headerShown: false, 
                    tabBarHideOnKeyboard: true
                 }}   
                tabBar={(props) => <AppTab {...props} />} 
                // tabBar={(props) => (!keyboardShown && <AppTab {...props} />)} 
            >
                   <Tab.Screen name="dashboard" component={DashBoard} />  

            </Tab.Navigator> 
    );
};
 
const styles = StyleSheet.create({ 
});

export default BottomTabs;
