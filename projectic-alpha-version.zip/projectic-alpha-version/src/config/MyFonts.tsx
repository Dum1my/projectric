export const MyFonts = {
  OpenSansBold: 'OpenSans-Bold',
  OpenSansExtraBold: 'OpenSans-ExtraBold',
  OpenSansLight: 'OpenSans-Light',
  OpenSansRegular: 'OpenSans-Regular',
  OpenSansSemiBold: 'OpenSans-SemiBold',
};
