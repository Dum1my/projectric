const MyImages = {
    getStarted: require("../assets/Images/authImages/mobile.png"),
    authLogo: require("../assets/Images/authImages/logo.png"),    
    logo: require("../assets/Images/authImages/logo_1.png"),    
  };
  
export default MyImages
  