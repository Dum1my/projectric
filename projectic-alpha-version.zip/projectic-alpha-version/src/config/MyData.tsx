import MyImages from "./MyImages";

export const SnapData = [
    {
        id: 1,
        title: "One Stop Solution For Your Project Portfolio Management",
        body: "A Complete PPM Solution Available Via The Cloud To Unlimited Users Within Your Organization.",
        imgUrl: MyImages.getStarted,
    },
    {
        id: 2,
        title: "One Stop Solution For Your Project Portfolio Management",
        body: "A Complete PPM Solution Available Via The Cloud To Unlimited Users Within Your Organization.",
        imgUrl: MyImages.getStarted,
    },
    {
        id: 3,
        title: "One Stop Solution For Your Project Portfolio Management",
        body: "A Complete PPM Solution Available Via The Cloud To Unlimited Users Within Your Organization.",
        imgUrl: MyImages.getStarted,
    },
    {
        id: 4,
        title: "One Stop Solution For Your Project Portfolio Management",
        body: "A Complete PPM Solution Available Via The Cloud To Unlimited Users Within Your Organization.",
        imgUrl: MyImages.getStarted,
    },
];