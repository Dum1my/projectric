import { Dimensions, GestureResponderEvent, Pressable, StyleSheet, Text, View ,FlatList, ScrollView, Alert} from 'react-native';
import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';    
import GlobalIcon from '../../../../config/GlobalIcons';
import { hp, wp } from '../../../../utils/constants';
import { MyColors } from '../../../../config/MyColors';
import { MyFonts } from '../../../../config/MyFonts';
import ReusableBottomSheet from '../../../../components/app-bottom-sheet/app-bottom-sheet';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import AppSelectDropdown, { AppDropdownData } from '../../../../components/app-drop-down/app-drop-down';
import CustomButton from '../../../../components/Buttons/CustomButton';
import { MyStylesMain } from '../../../../styles/GlobalStyles';
import { responsiveSize } from '../../../../config/Metrix';

interface IProps { 
    columns?:object,
    values?:object, 
}

const PeopleTable: React.FC<IProps> = ({columns,values }) => {  
    const screenWidth = Dimensions.get('window').width; 
    const bottomSheetModalRef = useRef<BottomSheetModal>(null);
    const appSelectDropdownRef = useRef<AppDropdownData>(null);
    const globalStyle = MyStylesMain();
    const [index, setIndex] = useState<number>();
    const [activeRows, setActiveRows] = useState<boolean[]>(new Array(values.length).fill(false));

    const toggleActive = (index: number) => {
      setActiveRows((prevActiveRows) => {
        const newActiveRows = [...prevActiveRows];
        newActiveRows[index] = !newActiveRows[index];
        return newActiveRows;
      });
    };

    const openSheet = useCallback(() => { 
      bottomSheetModalRef.current?.present();
    }, []);
    
  const closeSheet = useCallback(() => { 
    bottomSheetModalRef.current?.close();
  }, []);

  const handleSheetChanges = useCallback((index: number) => { 
    setIndex(index)
  }, []);

  const snapPoints = useMemo(() => ['45%'], []);
  
  const DataRow =({ index ,data}: { index: number,data:any })=>{  
      return( 
        <>
          <Pressable style={styles.dataCell}>
        <Pressable onPress={() => toggleActive(index)} style={{width:hp(10),alignItems:'center'}}><GlobalIcon name="caretdown" library="AntDesign" size={hp(1.3)} color={MyColors.grayText} /></Pressable>
        <Pressable onPress={()=>{openSheet()}} style={{width:hp(13),alignItems:'center'}}><GlobalIcon name="note-add" library="MaterialIcons" size={hp(2)} color={MyColors.buttonSecondary} /></Pressable>
        <View style={{width:hp(14),alignItems:'center'}}><Text style={[styles.datacelltext,{color:MyColors.black}]}  numberOfLines={2}>usama</Text></View> 
        <View style={{width:hp(10),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
        <View style={{width:hp(10),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
        <View style={{width:hp(10),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
        <View style={{width:hp(10),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
        <View style={{width:hp(10),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
          </Pressable> 
          {activeRows[index]  && (
        <View>
              <View>
                <Text style={styles.activetext}>Active Projects</Text>
              </View>
              { 
              data?.data.map((item:object,index:number)=>{
                return( 
                <Pressable style={styles.dataCell} key={index}>
                <View style={{ width: hp(10), alignItems: 'center' }}></View>
                <View style={{ width: hp(13), alignItems: 'center' }}></View>
                <View style={{ width: hp(14), alignItems: 'center' }}><Text style={[styles.datacelltext,{color:MyColors.black}]} numberOfLines={2}>usama</Text></View>
                <View style={{ width: hp(10), alignItems: 'center' }}><Text style={styles.datacelltext}>155</Text></View>
                <View style={{ width: hp(10), alignItems: 'center' }}><Text style={styles.datacelltext}>155</Text></View>
                <View style={{ width: hp(10), alignItems: 'center' }}><Text style={styles.datacelltext}>155</Text></View>
                <View style={{ width: hp(10), alignItems: 'center' }}><Text style={styles.datacelltext}>155</Text></View>
                <View style={{ width: hp(10), alignItems: 'center' }}><Text style={styles.datacelltext}>155</Text></View>
              </Pressable>
                )
              })
              }
        </View>
      )}
        </>
      )
    }



  return (
    <ScrollView style={[styles.container, { width: '100%' }]}>

      <View style={styles.headerRow}>
        <Text style={[styles.headerCell, { width: hp(10), }]}>View</Text>
        <Text style={[styles.headerCell, { width: hp(13), }]}>Assign task</Text>
        <Text style={[styles.headerCell, { width: hp(14), }]}>Name</Text>
        <Text style={[styles.headerCell, { width: hp(10), }]}>20-03-23</Text>
        <Text style={[styles.headerCell, { width: hp(10), }]}>20-03-23</Text>
        <Text style={[styles.headerCell, { width: hp(10), }]}>20-03-23</Text>
        <Text style={[styles.headerCell, { width: hp(10), }]}>20-03-23</Text>
        <Text style={[styles.headerCell, { width: hp(10), }]}>20-03-23</Text>
      </View>

      <ScrollView horizontal={true} >
        <View style={styles.dataRow}>
        {values.map((value, index) => (
            <DataRow key={index} index={index} data={value}/>
          ))}
        </View>
      </ScrollView>
      <ReusableBottomSheet bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
        backdropComponent={({ style }) => (<Pressable onPress={()=>closeSheet()} style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >
          <ScrollView style={styles.modalContainer}>
          <Text style={styles.modalTitle}>ASSIGN TASK</Text>
          <View>
          <AppSelectDropdown dropdownName='Select Project' optional={true} placeholder='Select' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} buttonStyle={styles.buttonStyle} />
          <AppSelectDropdown dropdownName='Task' optional={true} placeholder='Select' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} buttonStyle={styles.buttonStyle} /> 
          </View>
          <CustomButton
             size="large"
             title="Assign"
             onPress={() => closeSheet()}
             loading={false}
             textStyle={{color: MyColors.black}}
             style={[
                globalStyle.gButton,
               {
                 backgroundColor: MyColors.mainYellow,
                 marginTop: hp(4),
                 width: '100%',
                 marginLeft: 0,
               },
             ]}
        />
          </ScrollView>
      </ReusableBottomSheet>
    </ScrollView>
  );
};

export default PeopleTable;

const styles = StyleSheet.create({
    container: {
      flex: 1,
      borderWidth: 0.2,
      borderColor: MyColors.grayText,
      backgroundColor:MyColors.white,
      borderRadius: 5,
      padding: 10, 
      marginTop: hp(2),
    },
    header: {
      // flex: 1,
      fontWeight: 'bold',
      textAlign: 'left', 
    },
    headerRow: {
      flexDirection: 'row',
      borderBottomWidth: 0.1,
      borderBottomColor:  MyColors.grayText,
      backgroundColor:MyColors.offwhite,
      paddingBottom: 5,
      marginBottom: 5,
      // flex: 1,
      // flexGrow:1,
    },
    headerCell: {  
    fontFamily:MyFonts.OpenSansSemiBold,
    color: MyColors.black, 
    fontSize: 13,
    textAlign: 'center',  
    paddingHorizontal:hp(1.5), 
    marginHorizontal:1,
    alignItems:'center',
    textTransform:'uppercase',
    },
    dataRow: {
      // flexDirection: 'row',
      marginBottom: 5,  
    },
    dataCell: {
      // flex: 1,
      //  flexGrow:1,
      flexDirection:'row', 
      borderBottomWidth: 0.3, 
      borderBottomColor: '#ccc',
      marginVertical:hp(0.8),
      paddingVertical:hp(1),
      marginHorizontal:1, 
    },
    datacelltext:{
      textAlign: 'center',
      color:MyColors.redPrimary
    },
    activetext:{
        fontFamily:MyFonts.OpenSansRegular,
        color: MyColors.mainYellow,
        paddingLeft:hp(2),
        textTransform:'uppercase',
    },
    modalContainer:{
      width: '100%',
      paddingHorizontal: wp(5)
    },
    modalTitle:{
      fontSize: responsiveSize(20),
      fontFamily: MyFonts.OpenSansBold,
      color: MyColors.black
    }
  });