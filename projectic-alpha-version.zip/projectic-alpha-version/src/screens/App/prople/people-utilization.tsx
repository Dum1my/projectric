
import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { hp, wp } from '../../../utils/constants'; 
import AppInput from '../../../components/app-input/app-input'; 
import { MyColors } from '../../../config/MyColors';
import { useNavigation } from '@react-navigation/native';
import GlobalIcon from '../../../config/GlobalIcons';
import PeopleTable from './people-table/people-table';
import { MyFonts } from '../../../config/MyFonts';
import HeaderLayout from '../../../layouts/header-layout/header-layout';
import ReusableBottomSheet from '../../../components/app-bottom-sheet/app-bottom-sheet';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { responsiveSize } from '../../../config/Metrix';
import AppSelectDropdown, { AppDropdownData } from '../../../components/app-drop-down/app-drop-down';
import CustomButton from '../../../components/Buttons/CustomButton';
import { MyStylesMain } from '../../../styles/GlobalStyles';

const PeopleUtilization = () => {
  const navigation:any = useNavigation();
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const appSelectDropdownRef = useRef<AppDropdownData>(null);
  const [search, setSearch] = useState<string>('');
  const [index, setIndex] = useState<number>();
  const globalStyle = MyStylesMain();
  const columns =[
    { id: 1, name: 'View',  }, 
    { id: 2, name: 'Assign task',   }, 
    { id: 3, name: 'Name',},
    { id: 3, name: '20-03-23'},
    { id: 3, name: '20-03-23'},
    { id: 3, name: '20-03-23'},
]
  const values = [
    { id: 1,assign_task:true, name: 'John', val1: '155',val2: '155',val3: '155' ,data:[
      {id: 1,assign_task:true, name: 'John', val1: '155',val2: '155',val3: '155',},
      {id: 1,assign_task:true, name: 'John', val1: '155',val2: '155',val3: '155',},
    ]}, 
    { id: 1,assign_task:true, name: 'John', val1: '155',val2: '155',val3: '155' ,data:[]}, 
    { id: 1,assign_task:true, name: 'John', val1: '155',val2: '155',val3: '155' ,data:[
      {id: 1,assign_task:true, name: 'John', val1: '155',val2: '155',val3: '155',},
      {id: 1,assign_task:true, name: 'John', val1: '155',val2: '155',val3: '155',},
      {id: 1,assign_task:true, name: 'John', val1: '155',val2: '155',val3: '155',},
      {id: 1,assign_task:true, name: 'John', val1: '155',val2: '155',val3: '155',},
    ]}, 
    { id: 1,assign_task:true, name: 'John', val1: '155',val2: '155',val3: '155' ,data:[]}, 
    { id: 1,assign_task:true, name: 'John', val1: '155',val2: '155',val3: '155' ,data:[]}, 
  ];
  const screenWidth = Dimensions.get('window').width;  
  const cellWidth = screenWidth / 2;
 
  const openSheet = useCallback(() => { 
    bottomSheetModalRef.current?.present();
  }, []);

  const closeSheet = useCallback(() => { 
    bottomSheetModalRef.current?.close();
  }, []);

  const handleSheetChanges = useCallback((index: number) => { 
    setIndex(index)
  }, []);

  const snapPoints = useMemo(() => ['55%','90%'], []);

  const inputLeftElement = <Pressable style={styles.icon}><GlobalIcon name="search" library="EvilIcons" size={hp(2.5)} color={MyColors.grayText} /></Pressable>;
  return (
    <HeaderLayout headerTitle='RESOURCE UTILIZATION'  containerStyles={{width:'100%'}} showRightIcon={true} onPress={()=>{openSheet()}}
    footerElement={
      <View style={styles.footerBox}>
        <Pressable style={styles.btnBox}><Text style={styles.footerText}>Prev</Text></Pressable> 
        <Pressable style={[styles.btnBox,{backgroundColor:MyColors.mainYellow}]}><Text style={[styles.footerText,{color:MyColors.black}]}>Today</Text></Pressable> 
        <Pressable style={styles.btnBox}><Text style={styles.footerText}>Next</Text></Pressable> 
      </View>
    }
    >
        <View style={styles.container}>
         <AppInput   label="Member Name"  placeholder="Enter User Name" inputLeftElement={inputLeftElement} value={search} onChangeText={(text) => setSearch(text)} style={styles.searchBox}/>

          <View style={styles.weeklySty}>
            <View><Text style={styles.weeklyText}>WEEKLY LOAD BY %</Text></View>
            <View style={styles.dmBox}>
              <View style={[styles.dmBox,{marginRight:hp(2)}]}>
              <Text style={styles.text}>Hours</Text>
              <View style={{ flexDirection: 'column', marginHorizontal: 2 }}>
                <GlobalIcon name="caretup" library="AntDesign" size={hp(1)} color={MyColors.mainYellow} />
                <GlobalIcon name="caretdown" library="AntDesign" size={hp(1)} color={MyColors.grayText} />
              </View>
              </View>
              <View style={styles.dmBox}>
              <Text style={styles.text}>Monthly</Text>
              <View style={{ flexDirection: 'column', marginHorizontal: 2 }}>
                <GlobalIcon name="caretup" library="AntDesign" size={hp(1)} color={MyColors.grayText} />
                <GlobalIcon name="caretdown" library="AntDesign" size={hp(1)} color={MyColors.mainYellow} />
              </View>
              </View>
            </View>
          </View>
          
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{maxHeight: hp(50)}} >
            <PeopleTable columns={columns} values={values}/> 
          </ScrollView> 
 
        </View>

        <ReusableBottomSheet bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
        backdropComponent={({ style }) => (<Pressable onPress={()=>closeSheet()} style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >
          <ScrollView style={styles.modalContainer}>
          <Text style={styles.modalTitle}>FILTERS</Text>
          <View>
          <AppSelectDropdown dropdownName='Department' placeholder='Select' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} buttonStyle={styles.buttonStyle} />
          <AppSelectDropdown dropdownName='Designation' placeholder='Select' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} buttonStyle={styles.buttonStyle} />
          <AppSelectDropdown dropdownName='Member Name' placeholder='Select' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} buttonStyle={styles.buttonStyle} />
          </View>
          <CustomButton
             size="large"
             title="Assign"
             onPress={() => closeSheet()}
             loading={false}
             textStyle={{color: MyColors.black}}
             style={[
                globalStyle.gButton,
               {
                 backgroundColor: MyColors.mainYellow,
                 marginTop: hp(4),
                 width: '100%',
                 marginLeft: 0,
               },
             ]}
        />
          </ScrollView>
      </ReusableBottomSheet>
    </HeaderLayout>
  );
};

export default PeopleUtilization;

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    // height: hp(78),
    marginTop: hp(5),
    marginHorizontal: hp(2),
    // backgroundColor:'gray'
  },
  searchBox:{
    width:'100%', 
  },
  icon:{
    // top:hp(1.3),
    left: hp(1),
    bottom: hp(.4)
},
  header: {
    // flex: 1,
    fontWeight: 'bold',
    textAlign: 'left', 
  },
  weeklySty:{
    flexDirection:'row',
    justifyContent:'space-between',
  },
  weeklyText:{
    fontFamily:MyFonts.OpenSansBold,
    color: MyColors.black, 
  },
  dmBox:{
    flexDirection:'row',
  },
  text:{
    fontFamily:MyFonts.OpenSansSemiBold,
    color: MyColors.black, 
  }, 
  footerBox:{
    bottom:10,
    flexDirection:'row',
  },
  btnBox:{
    paddingHorizontal:hp(2),
    paddingVertical:hp(1),
    borderWidth:0.5,
    borderColor:MyColors.disable,
    borderRadius:hp(0.1), 
  },
  footerText:{
    color: MyColors.grayText
  },
  dropdown:{
    backgroundColor:MyColors.white,
    marginHorizontal:wp(1), 
    // height:hp(10)
  },
  buttonStyle: {
    backgroundColor: '#F8FAFF'
  },
  modalContainer:{
    width: '100%',
    paddingHorizontal: wp(5)
  },
  modalTitle:{
    fontSize: responsiveSize(20),
    fontFamily: MyFonts.OpenSansBold,
    color: MyColors.black
  }
});
