import { Alert, Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { hp, wp } from '../../../utils/constants';
import PorjectTable from '../projects/project-tables/data-table';
import AppInput from '../../../components/app-input/app-input';
import AppButton from '../../../components/app-button/app-button';
import { MyColors } from '../../../config/MyColors';
import { useNavigation } from '@react-navigation/native';
import GlobalIcon from '../../../config/GlobalIcons';
import { MyFonts } from '../../../config/MyFonts';
import AppModal from '../../../components/app-modal/app-modal';
import AppSelectDropdown, { AppDropdownData } from '../../../components/app-drop-down/app-drop-down';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import ReusableBottomSheet from '../../../components/app-bottom-sheet/app-bottom-sheet';
import { responsiveSize } from '../../../config/Metrix';

const PeopleView = () => {
  const navigation:any = useNavigation();
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const appSelectDropdownRef = useRef<AppDropdownData>(null);
  const [index, setIndex] = useState<number>();
  const [search, setSearch] = useState<string>(''); 
  const [isOpen, setOpen] = useState(false);
  const data1 =[ 'MEMBER NAME','EMAIL','DESIGNATION','DEPARTMENT','ACTION']
  const data = [
    { id: 1, name: 'Cathy James', email: 'cathyjames@gmail.com', designation: 'project manager', department: 'PMO' },
    { id: 2, name: 'Cathy James', email: 'cathyjames@gmail.com', designation: 'project manager', department: 'PMO' },
    { id: 3, name: 'Cathy James', email: 'cathyjames@gmail.com', designation: 'project manager', department: 'PMO' },
    { id: 4, name: 'Cathy James', email: 'cathyjames@gmail.com', designation: 'project manager', department: 'PMO' },
    { id: 5, name: 'Cathy James', email: 'cathyjames@gmail.com', designation: 'project manager', department: 'PMO' },
    { id: 6, name: 'Cathy James', email: 'cathyjames@gmail.com', designation: 'project manager', department: 'PMO' },
    { id: 7, name: 'Cathy James', email: 'cathyjames@gmail.com', designation: 'project manager', department: 'PMO' },
  ];
  const screenWidth = Dimensions.get('window').width;  
  const cellWidth = screenWidth / 2;

  const inputLeftElement = <Pressable style={styles.icon}><GlobalIcon name="search" library="FontAwesome" size={hp(2)} color={MyColors.grayText} /></Pressable>;

  const openSheet = useCallback(() => { 
    bottomSheetModalRef.current?.present();
  }, []);

  const closeSheet = useCallback(() => { 
    bottomSheetModalRef.current?.close();
  }, []);

  const handleSheetChanges = useCallback((index: number) => { 
    setIndex(index)
  }, []);

  const snapPoints = useMemo(() => ['30%','90%'], []);
  
  return (
    <PageLayout headerTitle='ALL PEOPLE'  containerStyles={{width:'100%'}} isFooter={true} single={true} 
    footerTitle='+ Add New People'  onPress={()=> {setOpen(true)}} showRightIcon={true} onPressRight={()=>{openSheet()}}
    >
        <View style={styles.container}>
        <AppInput   label="Search User"  placeholder="Enter User Name"  inputLeftElement={inputLeftElement}  value={search} onChangeText={(text) => setSearch(text)} style={styles.input}/>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginHorizontal:10}}>
           <PorjectTable data={data} data1={data1} cellWidth={wp(40)}/> 
        </ScrollView> 

        <AppModal isOpen={isOpen} handleOnClose={()=>{setOpen(false)}} >
            <View>
                <View style={styles.heading}><Text style={styles.text_heading}>Create New People</Text></View>
            <ScrollView style={{marginHorizontal:10,marginTop:hp(0.5),backgroundColor:MyColors.white}} showsVerticalScrollIndicator={false}>

                     <AppInput   label="First Name" optional={true} placeholder="Enter User Name" labelSty={styles.lable}    value={search} onChangeText={(text) => setSearch(text)} style={[styles.input_m,{marginTop:hp(5)}]}/> 
                     <AppInput   label="Last Name" optional={true} placeholder=""     labelSty={styles.lable}   value={search} onChangeText={(text) => setSearch(text)} style={styles.input_m}/> 
                     <AppInput   label="Email"  placeholder=""      labelSty={styles.lable}  value={search} onChangeText={(text) => setSearch(text)} style={styles.input_m}/> 
                     <AppInput   label="Phone Number" optional={false}  placeholder="(XXX) XXX-XXXX"   labelSty={styles.lable}  value={search} onChangeText={(text) => setSearch(text)} style={styles.input_m}/> 
                     <AppSelectDropdown dropdownName='Deparment' ref={appSelectDropdownRef} options={[]} _color={MyColors.black} container={styles.dropdown}  buttonStyle={styles.buttonStyle} />
                     <AppInput   label="Job Title" optional={true} placeholder="" labelSty={styles.lable}    value={search} onChangeText={(text) => setSearch(text)} style={styles.input_m}/> 
                     <AppInput   label="Hourly Rate" optional={true} placeholder="$" labelSty={styles.lable}    value={search} onChangeText={(text) => setSearch(text)} style={styles.input_m}/> 
                     <AppInput   label="Hours Per Day*" optional={true} placeholder="" labelSty={styles.lable}    value={search} onChangeText={(text) => setSearch(text)} style={styles.input_m}/> 
                     <AppSelectDropdown dropdownName='Skills' ref={appSelectDropdownRef} options={[]} _color={MyColors.black} container={styles.dropdown}/>
                     <AppSelectDropdown dropdownName='Experience' ref={appSelectDropdownRef} options={[]} _color={MyColors.black} container={styles.dropdown}/> 
            </ScrollView>
            <View style={styles.modalBottom}>
                <Pressable onPress={()=>{setOpen(false)}} style={[styles.btnBox,{borderRightWidth:0.2,borderColor:MyColors.disable}]}><Text style={[styles.textbtn,{color:MyColors.redPrimary}]}>Cancel</Text></Pressable>
                <Pressable onPress={()=>{setOpen(false)}}  style={styles.btnBox}><Text style={[styles.textbtn,{color:MyColors.greenPrimary}]}>Save</Text></Pressable>
            </View>
            </View>
        </AppModal>
        </View>

        <ReusableBottomSheet bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
        backdropComponent={({ style }) => (<Pressable onPress={()=>closeSheet()} style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >
          <ScrollView style={styles.modalContainer}>
          <Text style={styles.modalTitle}>PEOPLE</Text>
          <AppSelectDropdown dropdownName='Sort By' placeholder='None' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} buttonStyle={styles.buttonStyle} />
          <AppButton title={'Search'}  style={[styles.btn]} textStyle={styles.text2}  onPress={() => closeSheet() } />
          </ScrollView>
      </ReusableBottomSheet>
    </PageLayout>
  );
};

export default PeopleView;

const styles = StyleSheet.create({
  container: {
    flex: 1,  
    marginTop: hp(3),
    marginHorizontal:hp(1)
  },  
  input:{ 
      marginHorizontal:hp(1),
      marginBottom:0,
      backgroundColor:MyColors.white,
      marginTop:12
  },
  input_m:{ 
      marginHorizontal:hp(1),
      marginBottom:hp(2),
      backgroundColor:MyColors.white,
      marginTop:12, 
  },
  icon:{
        // top:hp(1.3),
        left: hp(1),
        marginRight: wp(2)
  },
  dropdown:{
    // backgroundColor:MyColors.white,
    marginHorizontal:hp(1), 
    marginBottom:hp(.7)
  },
  heading:{ 
    marginLeft:hp(2),
    marginVertical:hp(1)
  },
  text_heading:{
    fontFamily:MyFonts.OpenSansBold,
    color:MyColors.black
  },
  modalBottom:{
    flexDirection:'row',
    width:'100%',
    height:hp(7)
  },
  btnBox:{
    alignItems:'center',
    justifyContent:'center', 
    width:'50%',
  },
  textbtn:{
    fontFamily:MyFonts.OpenSansSemiBold,
  },
  modalContainer:{
    width: '100%',
    paddingHorizontal: wp(5)
  },
  modalTitle:{
    fontSize: responsiveSize(20),
    fontFamily: MyFonts.OpenSansBold,
    color: MyColors.black
  },
  buttonStyle: {
    backgroundColor: MyColors.white
  },
  btn:{
    borderRadius:25,
    backgroundColor:MyColors.mainYellow,  
    marginTop:hp(5)
  },
  text2:{
    color:MyColors.black
  },
  lable:{
    fontSize:12, 
  },
});
