import {
  Alert,
  Dimensions,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout';
import {hp, wp} from '../../../utils/constants';
import PorjectTable from '../projects/project-tables/data-table';
import AppInput from '../../../components/app-input/app-input';
import {MyColors} from '../../../config/MyColors';
import {useNavigation} from '@react-navigation/native';
import GlobalIcon from '../../../config/GlobalIcons';
import {MyFonts} from '../../../config/MyFonts';
import ReusableBottomSheet from '../../../components/app-bottom-sheet/app-bottom-sheet';
import AppSelectDropdown, {
  AppDropdownData,
} from '../../../components/app-drop-down/app-drop-down';
import {BottomSheetModal} from '@gorhom/bottom-sheet';
import AppButton from '../../../components/app-button/app-button';
import AlertIconRed from '../../../assets/svgs/AlertIconRed';

const PeopleTaskPortal = () => {
  const navigation: any = useNavigation();
  const appSelectDropdownRef = useRef<AppDropdownData>(null);
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const [index, setIndex] = useState<number>();
  const [val, setValue] = useState<string>('');

  const data1 = [
    {id: 1, name: 'PROJECT NAME'},
    {id: 2, name: 'REWARD'},
    {id: 3, name: 'RISK'},
    {id: 3, name: 'SCORE'},
  ];
  const data = [
    {id: 1, name: 'John', age: 30, location: 'New York'},
    {id: 2, name: 'Alice', age: 25, location: 'Los Angeles'},
    {id: 3, name: 'Bob', age: 35, location: 'Chicago'},
    {id: 4, name: 'Doe', age: 40, location: 'Houston'},
    {id: 4, name: 'Doe', age: 40, location: 'Houston'},
    {id: 4, name: 'Doe', age: 40, location: 'Houston'},
    {id: 4, name: 'Doe', age: 40, location: 'Houston'},
    {id: 4, name: 'Doe', age: 40, location: 'Houston'},
    {id: 4, name: 'Doe', age: 40, location: 'Houston'},
    {id: 4, name: 'Doe', age: 40, location: 'Houston'},
  ];
  const screenWidth = Dimensions.get('window').width;
  const cellWidth = screenWidth / 2;
  // variables
  const snapPoints = useMemo(() => ['55%', '90%'], []);

  // callbacks
  const openSheet = useCallback(() => {
    bottomSheetModalRef.current?.present();
  }, []);
  const closeSheet = useCallback(() => {
    bottomSheetModalRef.current?.close();
  }, []);

  const handleSheetChanges = useCallback((index: number) => {
    setIndex(index);
  }, []);

  const inputRightElement = (
    <Pressable style={styles.icon}>
      <GlobalIcon
        name="calendar"
        library="EvilIcons"
        size={hp(3.5)}
        color={MyColors.disable}
      />
    </Pressable>
  );

  useEffect(() => {
    openSheet();
  }, []);

  return (
    <PageLayout
      headerTitle="MY TASKS PORTAL"
      containerStyles={{width: '100%'}}
      showRightIcon={true}
      onPressRight={() => {
        openSheet();
      }}>
      <View style={styles.container}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={{marginHorizontal: 10}}>
          {/* <PorjectTable data={data} data1={data1}/>  */}
        </ScrollView>
        <View
          style={{
            alignSelf: 'center',
            alignItems: 'center',
            justifyContent: 'center',
            marginTop: '50%',
          }}>
          <AlertIconRed />
          <Text style={styles.notfoundText}>No Task Found</Text>
        </View>
      </View>

      <ReusableBottomSheet
        bottomSheetModalRef={bottomSheetModalRef}
        snapPoints={snapPoints}
        handleSheetChanges={handleSheetChanges}
        backdropComponent={({style}) => (
          <Pressable
            onPress={() => closeSheet()}
            style={[style, {backgroundColor: 'rgba(0, 0, 0, 0.7)'}]}
          />
        )}>
        <ScrollView style={styles.contentContainer}>
          <AppInput
            label="Start Date"
            placeholder="mm/dd/yyyy"
            inputRightElement={inputRightElement}
            value={val}
            onChangeText={text => setValue(text)}
            inputStyle={{fontSize: 13}}
            labelSty={{fontSize: 12}}
            style={{marginTop: hp(4), marginBottom: hp(3)}}
          />
          <AppInput
            label="End Date"
            placeholder="mm/dd/yyyy"
            inputRightElement={inputRightElement}
            value={val}
            onChangeText={text => setValue(text)}
            inputStyle={{fontSize: 13}}
            labelSty={{fontSize: 12}}
            style={{marginTop: hp(1), marginBottom: hp(1)}}
          />
          <AppSelectDropdown
            dropdownName="Sort By"
            placeholder="Select"
            ref={appSelectDropdownRef}
            options={['All', 'admin']}
            _color={MyColors.black}
            container={styles.dropdown}
          />
          <AppSelectDropdown
            dropdownName="Status"
            placeholder="Select"
            ref={appSelectDropdownRef}
            options={['All', 'admin']}
            _color={MyColors.black}
            container={styles.dropdown}
          />
          <AppButton
            title={'Search'}
            style={[styles.btn]}
            textStyle={styles.text2}
            onPress={() => {
              closeSheet();
            }}
          />
        </ScrollView>
      </ReusableBottomSheet>
    </PageLayout>
  );
};

export default PeopleTaskPortal;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: hp(3),
    marginHorizontal: hp(1),
  },
  input: {
    marginHorizontal: hp(1),
    marginBottom: 0,
    backgroundColor: MyColors.white,
    marginTop: 12,
  },
  input_m: {
    marginHorizontal: hp(1),
    marginBottom: hp(2),
    backgroundColor: MyColors.white,
    marginTop: 12,
  },
  notfoundText: {
    fontFamily: MyFonts.OpenSansSemiBold,
    width: hp(18),
    textAlign: 'center',
    color: MyColors.redPrimary,
    marginTop: hp(1),
  },
  icon: {
    // top:hp(1.3),
    left: hp(-5),
  },
  dropdown: {
    backgroundColor: MyColors.white,
    marginHorizontal: wp(1),
    // marginBottom:hp(-2),
  },
  heading: {
    marginLeft: hp(2),
    marginVertical: hp(1),
  },
  text_heading: {
    fontFamily: MyFonts.OpenSansBold,
    color: MyColors.black,
  },
  modalBottom: {
    flexDirection: 'row',
    width: '100%',
    height: hp(7),
  },
  btnBox: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '50%',
  },
  textbtn: {
    fontFamily: MyFonts.OpenSansSemiBold,
  },
  contentContainer: {
    width: '90%',
    marginHorizontal: wp(5),
    backgroundColor: MyColors.white,
  },
  btn: {
    borderRadius: 25,
    backgroundColor: MyColors.mainYellow,
    marginTop: hp(5),
    // marginHorizontal:wp(5),
  },
  text2: {
    color: MyColors.black,
  },
});
