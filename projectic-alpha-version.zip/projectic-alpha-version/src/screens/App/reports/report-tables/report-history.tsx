import { Dimensions, GestureResponderEvent, Pressable, StyleSheet, Text, View ,FlatList, ScrollView, Alert} from 'react-native';
import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';    
import GlobalIcon from '../../../../config/GlobalIcons';
import { hp } from '../../../../utils/constants';
import { MyColors } from '../../../../config/MyColors';
import { MyFonts } from '../../../../config/MyFonts';
import Dots from '../../../../components/app-dots/app-dots';

interface IProps { 
    columns?:object,
    values?:object, 
}

const RepHistoryTable: React.FC<IProps> = ({columns,values }) => {  
    const screenWidth = Dimensions.get('window').width; 

  const DataRow =({ index ,data}: { index: number,data:any })=>{   
      return(  
              <Pressable style={styles.dataCell}>
                  <View style={{ width: hp(5),  }}><Text style={[styles.datacelltext, { color: MyColors.textTitle }]}>{index+1}</Text></View>
                  <View style={{ width: hp(15),  }}><Text style={[styles.datacelltext, { textDecorationLine: 'underline', color: MyColors.textTitle }]}>{data.name}</Text></View>
                  <View style={{ width: hp(13),  }}><Text style={[styles.datacelltext,{}]}>{data.val1}</Text></View>
                  <View style={{ width: hp(15),  }}><Text style={[styles.datacelltext,{}]}>{data.val2}</Text></View>
                  <View style={{ width: hp(10),  }}><Dots dot={{backgroundColor:MyColors.mainYellow}}/></View> 
                  <View style={{ width: hp(10),  }}><Dots dot={{backgroundColor:MyColors.mainYellow}}/></View> 
                  <View style={{ width: hp(10),  }}><Dots dot={{backgroundColor:MyColors.mainYellow}}/></View> 
                  <View style={{ width: hp(10),  }}><Dots dot={{backgroundColor:MyColors.mainYellow}}/></View> 
                  <View style={{ width: hp(10),  }}><Text style={styles.datacelltext}>{data.v4}</Text></View>  
              </Pressable>   
      )
    }

  return (
    <View style={[styles.container, { width: '100%',marginBottom:hp(3) }]}> 
      <Text style={styles.chartTitle}>REPORT</Text>
      <View style={styles.headerRow}>
        <Text style={[styles.headerCell, { width: hp(5), }]}>#</Text>
        <Text style={[styles.headerCell, { width: hp(15), }]}>project name</Text>
        <Text style={[styles.headerCell, { width: hp(13), }]}>start date</Text>
        <Text style={[styles.headerCell, { width: hp(15), }]}>end date</Text>
        <Text style={[styles.headerCell, { width: hp(10), }]}>MILESTONE</Text> 
        <Text style={[styles.headerCell, { width: hp(10), }]}>hours</Text> 
        <Text style={[styles.headerCell, { width: hp(10), }]}>budget</Text> 
        <Text style={[styles.headerCell, { width: hp(10), }]}>budget</Text> 
        <Text style={[styles.headerCell, { width: hp(10), }]}>status</Text> 
      </View>

      <ScrollView  showsVerticalScrollIndicator={false}>
        <View style={styles.dataRow}>
        {values.map((value, index) => (
            <DataRow key={index} index={index} data={value}/>
          ))}
        </View>
      </ScrollView>
    </View>
  );
};

export default RepHistoryTable;

const styles = StyleSheet.create({
    container: {
      flex: 1,
      borderWidth: 0.2,
      borderColor: MyColors.grayText,
      backgroundColor:MyColors.white,
      borderRadius: 5,
      padding: 10, 
      marginTop: hp(2),
      height:hp(70)
    },
    header: { 
      fontWeight: 'bold',
      textAlign: 'left', 
    },
    headerRow: {
      flexDirection: 'row',
      borderBottomWidth: 0.1,
      borderBottomColor:  MyColors.grayText,
      backgroundColor:MyColors.offwhite,
      paddingBottom: 5,
      marginBottom: 5, 
    },
    headerCell: {  
    fontFamily:MyFonts.OpenSansSemiBold,
    color: MyColors.black, 
    fontSize: 11, 
    textTransform:'uppercase',
    textAlign: 'left', 
    },
    dataRow: { 
      marginBottom: 5,  
    },
    dataCell: { 
      flexDirection:'row', 
      borderBottomWidth: 0.3, 
      borderBottomColor:MyColors.disable,
    //   marginVertical:hp(0.8),
      paddingVertical:hp(1),
      marginHorizontal:1, 
    },
    datacelltext:{
      textAlign: 'left',
      color:MyColors.black,
      fontFamily:MyFonts.OpenSansRegular,
      fontSize: 12,
    }, 
    chartTitle:{ 
      fontFamily:MyFonts.OpenSansSemiBold,
      fontSize:15,
      color:MyColors.black,
      paddingBottom:hp(1)
    },
  });