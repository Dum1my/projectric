import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { hp, wp } from '../../../utils/constants'; 
import { MyColors } from '../../../config/MyColors';
import { MyFonts } from '../../../config/MyFonts';  
import ReportHistory from './report-history';
import GlobalIcon from '../../../config/GlobalIcons';
import CategoryAndItems from '../../../components/app-items/app-item';
import ProjectTable from './report-tables/project-table';
import AppSelectDropdown, { AppDropdownData } from '../../../components/app-drop-down/app-drop-down';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import ReusableBottomSheet from '../../../components/app-bottom-sheet/app-bottom-sheet';
import AppButton from '../../../components/app-button/app-button';
import AppCheckBox from '../../../components/app-check-box/app-check-box';
import AppInput from '../../../components/app-input/app-input';
import CustomMenu from '../../../components/custom-menu/CustomMenu';

  
export const categories:any = [
    { id: 1, name: 'Project' },
    { id: 2, name: 'portfolio' },
    { id: 3, name: 'budget' },
    { id: 4, name: 'task' },
    { id: 5, name: 'project members' },
    { id: 6, name: 'people' },
    { id: 7, name: 'time sheet' },
    { id: 8, name: 'All save reports' },
];

const ReportCustome = () => {
  const appSelectDropdownRef = useRef<AppDropdownData>(null);
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const [showMenuModal, setShowMenuModal] = useState<boolean>(false)
  const [index, setIndex] = useState<number>();
  const [val, setValue] = useState<string>('');
    const [active,setActive] = useState('status')
    const columns =[
        { id: 1, name: 'DEPARTMENT NAME',  }, 
        { id: 2, name: 'TOTAL MEMBER',   }, 
        { id: 3, name: 'DEPARTMENT HEAD',},
        { id: 3, name: 'EMAIL'},
        { id: 3, name: 'ACTION'}, 
    ]
    const values = [
      { name: 'Support & Sales Ops', v1: '2023-113',v2:'100'},  
      { name: 'KNZ - 32nd Gov Procurement Conference Duplicate', v1: '2023-113',v2:'100'},  
      { name: '32nd Gov Procurement Conference', v1: '2023-113',v2:'100'},  
      { name: 'Marketing & Ops', v1: '2023-113',v2:'100'},  
      { name: 'HET MRI', v1: '2023-113',v2:'100'},  
      { name: 'Portable HET Scanner', v1: '2023-113',v2:'100'},  
      { name: 'ISSUE TAB', v1: '2023-113',v2:'100'},  
      { name: 'Tier2 TTx', v1: '2023-113',v2:'100'},  
      { name: 'Portable HET Scanner', v1: '2023-113',v2:'100'},  
      { name: 'Portable HET Scanner', v1: '2023-113',v2:'100'},  
    ];
    const [projects,] = useState([1,1,1,1,1,1]);
    const screenWidth = Dimensions.get('window').width; 
 
    // variables
    const snapPoints = useMemo(() => ['90%','90%'], []);

    // callbacks
    const openSheet = useCallback(() => { 
      bottomSheetModalRef.current?.present();
    }, []);
    const closeSheet = useCallback(() => { 
      bottomSheetModalRef.current?.close();
    }, []);
  
    const handleSheetChanges = useCallback((index: number) => { 
      setIndex(index)
    }, []);
  
    const inputRightElement = <Pressable style={styles.icon}><GlobalIcon name="search1" library="AntDesign" size={hp(2)} color={MyColors.headerTitle} /></Pressable>;
  return (
   <>
    <PageLayout headerTitle='CUSTOM REPORT'  showRightIcon={true} onPressRight={()=> setShowMenuModal(!showMenuModal)} containerStyles={{width:'100%'}}>  
<View style={{ marginTop: hp(2), marginHorizontal: hp(2) }}>
  <CategoryAndItems categories={categories} itemsData={categories} />
</View>
<ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: 10 }}>
  <ProjectTable columns={columns} values={values} />
</ScrollView> 

  <ReusableBottomSheet bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
  backdropComponent={({ style }) => (<Pressable onPress={()=>closeSheet()} style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >

    <AppInput label='Search' placeholder='Enter Template Title'    inputRightElement={inputRightElement}   value={val} onChangeText={(text) => setValue(text)} inputStyle={{fontSize:13}} labelSty={{fontSize:13}} style={{ width: '90%', marginTop: hp(5), marginHorizontal: 20}} />

  <ScrollView style={{width:'100%'}}> 
  {
    projects.map((v,i)=>{
      return(
    <View  style={styles.contentContainer} key={i}>
      <View style={{flexDirection:'row'}}><AppCheckBox /><Text style={styles.proText}>Proejct</Text></View>
      <GlobalIcon name="dots-grid" library="MaterialCommunityIcons" size={hp(3)} color={MyColors.black} />
    </View>
      )
    })
  }
  </ScrollView>
  <View style={{  
    bottom:11
  }}>
    <AppButton title={'Search'}  style={[styles.btn]} textStyle={styles.text2}  onPress={() => { }} />
  </View>
</ReusableBottomSheet>
</PageLayout>
  {showMenuModal && <View style={styles.customMenu}>
    <CustomMenu onPress={() => {setShowMenuModal(false); openSheet()}} onPress1={() => setShowMenuModal(false)} onPress2={() => setShowMenuModal(false)} />
  </View>}
   </>
  );
};

export default ReportCustome;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
    marginTop: hp(2),
  }, 
  title:{
    fontFamily:MyFonts.OpenSansRegular,
    fontWeight:'bold',
    fontSize:12
  },
  title_amount:{
    fontFamily:MyFonts.OpenSansSemiBold, 
    fontSize:20
  },
  tabBox:{
    flexDirection:'row',
    justifyContent:'center',
    alignItems:'center', 
    marginTop:hp(2),
    elevation:1, 
  },
  btnBox:{
    alignItems:'center',
    justifyContent:'center', 
    backgroundColor:MyColors.white, 
    borderRadius:hp(4),
    marginHorizontal:hp(0.8),
    borderBottomColor:MyColors.offwhite,
    borderBottomWidth:1
  },
  btnText:{
    color:MyColors.white,
    fontSize:10, 
    padding:hp(1),
    fontFamily:MyFonts.OpenSansRegular,
  },
  notfoundText:{ 
    fontFamily:MyFonts.OpenSansSemiBold, 
    width:hp(18),
    // fontSize:hp(18),
    textAlign:'center',
    color:MyColors.black,
    marginTop:hp(1)
  },
  contentContainer:{
    marginHorizontal:wp(5),
    flexDirection:'row',
    justifyContent:'space-between',
    alignItems:'center',
  },
  text_heading:{
    fontFamily:MyFonts.OpenSansSemiBold,
    color:MyColors.black,
    fontSize:15,
  },
  icon:{
    top:hp(1.3),
    left: hp(-3)
},
  proText:{
    fontFamily:MyFonts.OpenSansRegular,
    color:MyColors.black,
    fontSize:12, 
    paddingLeft:wp(2)
  },
  btn:{
    borderRadius:25,
    backgroundColor:MyColors.mainYellow,  
    marginTop:hp(5),
    marginHorizontal:wp(5),
    bottom:0,
    // zIndex:1 
  },
  text2:{
    color:MyColors.black
  },
  customMenu: {
    position: 'absolute',
    right: hp(3),
    zIndex: 1,
    top: hp(10)
  }
});
