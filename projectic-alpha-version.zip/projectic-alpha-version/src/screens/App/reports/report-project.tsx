import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { hp, wp } from '../../../utils/constants'; 
import { MyColors } from '../../../config/MyColors';
import { MyFonts } from '../../../config/MyFonts'; 
import ReportTable from './report-tables/report-table';
import ReportHistory from './report-history';
import GlobalIcon from '../../../config/GlobalIcons';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import ReusableBottomSheet from '../../../components/app-bottom-sheet/app-bottom-sheet';
import AppSelectDropdown, { AppDropdownData } from '../../../components/app-drop-down/app-drop-down';
import AppButton from '../../../components/app-button/app-button';
import { BarChart, LineChart, PieChart, PopulationPyramid } from "react-native-gifted-charts";
import Dots from '../../../components/app-dots/app-dots';


type progressBar={
  color1: string,
  color2: string,
  color3: string,
  color4: string,
  title: string,
}

const ReportProject = () => {
  const appSelectDropdownRef = useRef<AppDropdownData>(null);
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const [index, setIndex] = useState<number>();
    const [active,setActive] = useState('status')
    const columns =[
        { id: 1, name: 'DEPARTMENT NAME',  }, 
        { id: 2, name: 'TOTAL MEMBER',   }, 
        { id: 3, name: 'DEPARTMENT HEAD',},
        { id: 3, name: 'EMAIL'},
        { id: 3, name: 'ACTION'}, 
    ]
      const values = [
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
      ];
    const screenWidth = Dimensions.get('window').width;  
     const snapPoints = useMemo(() => ['40%','90%'], []);
     const openSheet = useCallback(() => { 
       bottomSheetModalRef.current?.present();
     }, []);
   
     const closeSheet = useCallback(() => { 
      bottomSheetModalRef.current?.close();
    }, []);
     const handleSheetChanges = useCallback((index: number) => { 
       setIndex(index)
     }, []);

     const ProgressBar = ({title,color1,color2,color3,color4}:progressBar)=>{
      return(
        <View style={styles.chartContainer}> 
          <View style={[styles.chartBox,{  backgroundColor: color4,}]}><Text>3</Text></View>
          <View style={[styles.chartBox,{  backgroundColor: color3,}]}><Text>2</Text></View>
          <View style={[styles.chartBox,{  backgroundColor: color2,}]}><Text>1</Text></View>
          <View style={[styles.chartBox,{  backgroundColor: color1,}]}><Text>0</Text></View>
          <View><Text style={styles.progressText}>{title}</Text></View>
        </View>
      )
     }
     const BarLine =({num})=>{
      return(
        <View style={{marginTop:hp(3),height:hp(2)}}><Text>{num}</Text><View style={styles.barline} /></View>
      )
     }
  return (
    <PageLayout headerTitle='PROJECT REPORT' showRightIcon={true} onPressRight={()=>{openSheet()}} containerStyles={{marginHorizontal:wp(3)}} isFooter={active == 'status' ? true :false} single={true} footerTitle='Download Report' onPress={()=>{console.log('--')}}>  
        <View style={styles.tabBox}>
            <Pressable onPress={()=>setActive('status')} style={[styles.btnBox,{backgroundColor:active =='status' ? MyColors.buttonSecondary:MyColors.white}]}><Text style={[styles.btnText,{color:active =='status' ? MyColors.white:MyColors.black}]}>Project Status</Text></Pressable>
            <Pressable onPress={()=>setActive('report')} style={[styles.btnBox,{backgroundColor:active =='report' ? MyColors.buttonSecondary:MyColors.white}]}><Text style={[styles.btnText,{color:active =='report' ? MyColors.white:MyColors.black}]}>Health Report</Text></Pressable>
            <Pressable onPress={()=>setActive('history')} style={[styles.btnBox,{backgroundColor:active =='history' ? MyColors.buttonSecondary:MyColors.white}]}><Text style={[styles.btnText,{color:active =='history' ? MyColors.white:MyColors.black}]}>Report History</Text></Pressable>
        </View>
        {
            active == 'status' &&
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginHorizontal:10}}>
          <ReportTable columns={columns} values={values}/>
        </ScrollView>
        }
        {
            active == 'history' &&
                <View style={{justifyContent:'center',alignItems:'center',marginTop:'50%'}}>
                    <GlobalIcon name="closecircle" library="AntDesign" size={hp(8)} color={MyColors.redSecondryAlpha} />
                    <Text style={styles.notfoundText}>No Report Found, Generate A New One</Text>
                </View>
        }
        { active == 'report' && 
        <>
        <ScrollView style={styles.containerBox}>
          <View style={{padding:hp(2)}}><Text style={styles.chartTitle}>REPORT</Text><Text style={styles.reportTitle}>Status Report for All Projects of All Portfolios</Text></View>
          <View style={styles.statusContainer}>
            <View style={styles.statusBox}><Dots dot={[styles.dots,{backgroundColor:MyColors.green,}]}/><Text style={styles.statutText}>Completed</Text></View>
            <View style={styles.statusBox}><Dots dot={[styles.dots,{backgroundColor:MyColors.mainYellow,}]}/><Text style={styles.statutText}>InProgress</Text></View>
            <View style={styles.statusBox}><Dots dot={[styles.dots,{backgroundColor:MyColors.redPrimary,}]}/><Text style={styles.statutText}>Delayed</Text></View>
            <View style={styles.statusBox}><Dots dot={[styles.dots,{backgroundColor:MyColors.grey,}]}/><Text style={styles.statutText}>NoUpdate</Text></View>
          </View> 
           
          <Pressable style={styles.progressContainer}>
              <View style={{ position:'absolute', height:hp(27),  left:hp(3)}}> 
                  <ProgressBar  title={'Milestone Health'} color1={MyColors.green} color2={MyColors.grayText} color3={MyColors.mainYellow} color4={MyColors.greenPrimary}/>  
              </View>
              <View style={{ position:'absolute', height:hp(27),  left:hp(16)}}> 
                  <ProgressBar title={'Hours Health'} color1={MyColors.green} color2={MyColors.grayText} color3={MyColors.mainYellow} color4={MyColors.greenPrimary}/>  
              </View>
              <View style={{ position:'absolute', height:hp(27),  left:hp(29)}}> 
                  <ProgressBar title={'Budget Health'} color1={MyColors.green} color2={MyColors.grayText} color3={MyColors.mainYellow} color4={MyColors.greenPrimary}/>  
              </View> 
              <BarLine num={'4'}/> 
              <BarLine num={'3'}/> 
              <BarLine num={'2'}/> 
              <BarLine num={'1'}/> 
              <BarLine num={'0'}/>
       
          </Pressable>
          </ScrollView>
        <ReportHistory/>
        </>
        }

        <ReusableBottomSheet bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
        backdropComponent={({ style }) => (<View style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >
        <ScrollView style={styles.contentContainer}> 
        <View style={styles.heading}><Text style={styles.text_heading}>PROJECT REPORT</Text></View>
        <AppSelectDropdown dropdownName='Portfolios' placeholder='All Portfolios' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} />
        <AppSelectDropdown dropdownName='Projects'   placeholder='All Projects'   ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} />

          <AppButton title={'Generate Report'}  style={[styles.btn]} textStyle={styles.text2}  onPress={() => { closeSheet()}} />
        
        </ScrollView>
      </ReusableBottomSheet>
    </PageLayout>
  );
};

export default ReportProject;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
    marginTop: hp(2),
  }, 
  title:{
    fontFamily:MyFonts.OpenSansRegular,
    fontWeight:'bold',
    fontSize:12
  },
  title_amount:{
    fontFamily:MyFonts.OpenSansSemiBold, 
    fontSize:20
  },
  tabBox:{
    flexDirection:'row',
    justifyContent:'center',
    alignItems:'center', 
    marginTop:hp(2),
    elevation:1, 
  },
  btnBox:{
    alignItems:'center',
    justifyContent:'center', 
    backgroundColor:MyColors.white, 
    borderRadius:hp(4),
    marginHorizontal:hp(0.8),
    borderBottomColor:MyColors.offwhite,
    borderBottomWidth:1
  },
  btnText:{
    color:MyColors.white,
    fontSize:10, 
    padding:hp(1),
    fontFamily:MyFonts.OpenSansRegular,
  },
  notfoundText:{ 
    fontFamily:MyFonts.OpenSansSemiBold, 
    width:hp(18), 
    textAlign:'center',
    color:MyColors.black,
    marginTop:hp(1)
  },
   
  statusBox:{
    flexDirection:'row',
    justifyContent:'center',
    alignItems:'center'
  },
  dots:{
    width:hp(1),
    height:hp(1)
  },
  statutText:{
    fontFamily:MyFonts.OpenSansRegular,
    fontSize:hp(1.2),
    paddingLeft:hp(0.5),
    color:MyColors.black
  },
  contentContainer: { 
    marginHorizontal:wp(5),
    // backgroundColor:MyColors.offwhite
  },
  heading:{  
    justifyContent:'center',  
    marginVertical:hp(1),
    height:hp(5), 
  },
  text_heading:{
    fontFamily:MyFonts.OpenSansSemiBold,
    color:MyColors.black,
    fontSize:15,
  },
  btn:{
    borderRadius:25,
    backgroundColor:MyColors.mainYellow,  
    marginTop:hp(5)
  },
  text2:{
    color:MyColors.black
  },
  dropdown:{
    backgroundColor:MyColors.white, 
    
    },
    chartTitle:{ 
      fontFamily:MyFonts.OpenSansSemiBold,
      fontSize:15,
      color:MyColors.black
    },
    reportTitle:{ 
      fontFamily:MyFonts.OpenSansSemiBold,
      color:MyColors.grayText,
      fontSize:11,
    },
    containerBox:{
      marginTop:hp(1),
      flex:1,
      backgroundColor:MyColors.white,
      width:'100%',
      marginHorizontal:hp(1),
    },
    barline:{ 
      borderColor: MyColors.lightgrey, 
      borderBottomWidth: 1, 
      bottom: 2, 
      left: hp(2), 
      width: '90%', 
      zIndex:-1
    },
    statusContainer:{
      flexDirection:'row',
      justifyContent:'space-around',
    },
    progressContainer:{
      width:'100%',
      marginTop:hp(1), 
      paddingBottom:hp(2), 
      paddingHorizontal:hp(2),
      backgroundColor:MyColors.white,
      },
    progressText:{
      fontFamily:MyFonts.OpenSansSemiBold,
      color:MyColors.black,
      fontSize:10, 
      textAlign:'center',
      // marginTop:hp(2)
    },
    chartContainer:{
      alignItems:'center',
      width: wp(30),
      position:'absolute',
      bottom:hp(.2), 
    },
    chartBox:{ 
      height: hp(6),
      width: wp(15),
      alignItems: 'center',
      justifyContent:'center',
    }
});
