import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useState } from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { hp } from '../../../utils/constants'; 
import { MyColors } from '../../../config/MyColors';
import { MyFonts } from '../../../config/MyFonts';  
import RepHistoryTable from './report-tables/report-history';

const ReportHistory = () => {
    const [active,setActive] = useState('status')
    const columns =[
        { id: 1, name: 'DEPARTMENT NAME',  }, 
        { id: 2, name: 'TOTAL MEMBER',   }, 
        { id: 3, name: 'DEPARTMENT HEAD',},
        { id: 3, name: 'EMAIL'},
        { id: 3, name: 'ACTION'}, 
    ]
      const values = [
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
        { name: 'ISSUE TAB', val1: '11-24-2023',val2: '11-24-2023',val3: '2222' ,v4:'pending',v5:'100'},   
      ]; 
  
  return ( 
    <View style={styles.container}> 
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginHorizontal:10}}>
        <RepHistoryTable columns={columns} values={values}/> 
        </ScrollView> 
  </View>
  );
};

export default ReportHistory;

const styles = StyleSheet.create({
  container:{
    // marginTop:hp(5)
  }
});
