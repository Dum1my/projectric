import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import PageLayout from '../../../../layouts/page-layout/page-layout'; 
import { hp, wp } from '../../../../utils/constants'; 
import { MyColors } from '../../../../config/MyColors';
import { MyFonts } from '../../../../config/MyFonts';
import DepartmentTable from '../department-table/department-table';
import AppSelectDropdown, { AppDropdownData } from '../../../../components/app-drop-down/app-drop-down';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import ReusableBottomSheet from '../../../../components/app-bottom-sheet/app-bottom-sheet';
import AppButton from '../../../../components/app-button/app-button';
import AppInput from '../../../../components/app-input/app-input';

const DepartmentIndex = () => {
  const appSelectDropdownRef = useRef<AppDropdownData>(null);
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const [index, setIndex] = useState<number>();
  const [val, setValue] = useState<string>('');
    const columns =[
        { id: 1, name: 'DEPARTMENT NAME',  }, 
        { id: 2, name: 'TOTAL MEMBER',   }, 
        { id: 3, name: 'DEPARTMENT HEAD',},
        { id: 3, name: 'EMAIL'},
        { id: 3, name: 'ACTION'}, 
    ]
      const values = [
        { name: 'SEO', val1: '1',val2: 'Deckard shaw',val3: 'test@g.com' },  
        { name: 'PMO', val1: '2',val2: 'Cathy James',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
      ];
  const screenWidth = Dimensions.get('window').width; 
     // variables
     const snapPoints = useMemo(() => ['40%','90%'], []);

     // callbacks
     const openSheet = useCallback(() => { 
       bottomSheetModalRef.current?.present();
     }, []);
     const closeSheet = useCallback(() => { 
      bottomSheetModalRef.current?.close();
    }, []);
   
     const handleSheetChanges = useCallback((index: number) => { 
       setIndex(index)
     }, []);
  return (
    <PageLayout headerTitle='ALL DEPARTMENTS' containerStyles={{width:'100%'}} isFooter={true} single={true} footerTitle='+ Add New Department' onPress={()=>{openSheet()}}>  
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginHorizontal:10}}>
        <DepartmentTable columns={columns} values={values}/> 
        </ScrollView>

        <ReusableBottomSheet bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
        backdropComponent={({ style }) => (<Pressable onPress={()=>closeSheet()} style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >
        <ScrollView style={styles.contentContainer}> 
        <View style={styles.heading}><Text style={styles.text_heading}>VIEW</Text></View>
        <AppInput label='Department Name' placeholder='Product' optional={true}  value={val} onChangeText={(text) => setValue(text)} inputStyle={{fontSize:13}} labelSty={{fontSize:11}} style={{ width: '100%',marginBottom:10,marginTop:hp(3)}} />
        <AppSelectDropdown  dropdownName='Department Head' placeholder='Courtney David' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} />
        <AppButton title={'Save'}  style={[styles.btn]} textStyle={styles.text2}  onPress={() => {closeSheet() }} />
        
        </ScrollView>
      </ReusableBottomSheet>
    </PageLayout>
  );
};

export default DepartmentIndex;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
    marginTop: hp(2),
  }, 
  title:{
    fontFamily:MyFonts.OpenSansRegular,
    fontWeight:'bold',
    fontSize:12
  },
  title_amount:{
    fontFamily:MyFonts.OpenSansSemiBold, 
    fontSize:20
  },
     
  contentContainer: {
    // flex: 1,
    // alignItems: 'center',
    marginHorizontal:wp(5),
    marginTop: hp(2),
    backgroundColor:MyColors.white
  },
  heading:{ 
    // marginLeft:hp(2), 
    justifyContent:'center', 
    // paddingLeft:hp(0),
    marginVertical:hp(1),
    // height:hp(5), 
  },
  text_heading:{
    fontFamily:MyFonts.OpenSansSemiBold,
    color:MyColors.black,
    fontSize:15,
  },
  btn:{
    borderRadius:25,
    backgroundColor:MyColors.mainYellow,  
    marginTop:hp(5)
  },
  text2:{
    color:MyColors.black
  },
  dropdown:{
    backgroundColor:MyColors.white,
    // marginHorizontal:wp(5),  
    // height:hp(5)
    },
});
