import { Dimensions, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import PageLayout from '../../layouts/page-layout/page-layout' 
import { MyFonts } from '../../config/MyFonts'
import { MyColors } from '../../config/MyColors'
import { responsiveSize } from '../../config/Metrix'
import { hp, screen_height, wp } from '../../utils/constants'
import CancelIcon from '../../assets/svgs/CancelIcon'

const Reminders = () => {
  return (
    <PageLayout headerTitle='REMINDERS'> 
    <View style={styles.container}>
     <CancelIcon height={hp(1.2)} width={wp(2)} />
     <Text style={styles.title}>There Are No Reminders</Text>
    </View>  
</PageLayout>
  )
}

export default Reminders

const styles = StyleSheet.create({
  container:{
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    height: screen_height / 1.3
  },
  title:{
    fontFamily: MyFonts.OpenSansSemiBold,
    color: MyColors.headerTitle,
    fontSize: responsiveSize(15),
    // marginTop: hp(1.2)
   }
})