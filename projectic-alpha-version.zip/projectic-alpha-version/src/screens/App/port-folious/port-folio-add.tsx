import { Dimensions, Pressable, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React, { useRef, useState } from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { hp, wp } from '../../../utils/constants';
import AppInput from '../../../components/app-input/app-input';
import AppSelectDropdown, { AppDropdownData } from '../../../components/app-drop-down/app-drop-down';
import { MyColors } from '../../../config/MyColors';
import { useNavigation } from '@react-navigation/native';
import GlobalIcon from '../../../config/GlobalIcons';
import DateTimePicker from '@react-native-community/datetimepicker';



const PortFoiloAdd = () => {
    const navigation:any = useNavigation();
    const [val, setValue] = useState<string>('');
    const [date, setDate] = useState(new Date());
    const [showPicker, setShowPicker] = useState(false);
    const appSelectDropdownRef = useRef<AppDropdownData>(null);
    const inputRightElement = <Pressable style={styles.icon}><GlobalIcon name="calendar"  library="EvilIcons" size={hp(4)}  color={MyColors.headerTitle} /></Pressable>;
  
    const onChange = (event:string, selectedDate:any) => {
        const currentDate = selectedDate || date; 
        setShowPicker(false);
        setDate(currentDate);
      };
    
    
  return (
    <PageLayout headerTitle='PORTFOLIO' footerTitle='save' showBackIcon={true} isFooter={true} single={true} footerbtnSty={{borderRadius:20}} onPress={()=> navigation.navigate('project_view')}>  
    <View style={styles.container}>
        <AppInput label='Project Name*' value={val} onChangeText={(text) => setValue(text)} labelSty={styles.lable} style={{width:'100%',marginBottom:10}}/>
        <AppSelectDropdown dropdownName='Portfolio Type' optional={true} ref={appSelectDropdownRef} options={[]} _color={MyColors.black} buttonStyle={styles.buttonStyle}/>
        <AppSelectDropdown  dropdownName='Contact Person'   ref={appSelectDropdownRef} options={[]}  _color={MyColors.black}  buttonStyle={styles.buttonStyle} />
        <AppInput label='Estimated Budget' optional={true} value={val} onChangeText={(text) => setValue(text)} labelSty={styles.lable} style={{width:'100%',marginTop:hp(5)}}/>
        <AppInput label='Estimated Work Hours' optional={false} value={val} onChangeText={(text) => setValue(text)} labelSty={styles.lable} style={{width:'100%',marginTop:hp(0.5),marginBottom:10}}/>
        <AppSelectDropdown  dropdownName='Portfolio Size' optional={true}   ref={appSelectDropdownRef} options={[]}  _color={MyColors.black}  buttonStyle={styles.buttonStyle} />
        
        <TouchableOpacity activeOpacity={0.7} onPress={() => { setShowPicker(true) }}>
        <AppInput editable={false} label='Portfolio Create On' optional={false} inputRightElement={inputRightElement} value={date} onChangeText={(text) => setValue(text)} labelSty={styles.lable} style={{width:'100%',marginTop:hp(5),marginBottom:10}}/>
        </TouchableOpacity>
        <AppSelectDropdown  dropdownName='Portfolio Status*'   ref={appSelectDropdownRef} options={[]}  _color={MyColors.black}  buttonStyle={styles.buttonStyle} />
        <AppInput multiline={true} number={5} inputStyle={{minHeight:200}} label='Portfolio Location' value={val} onChangeText={(text) => setValue(text)} labelSty={styles.lable} style={{width:'100%',marginTop:hp(5)}} />
        <AppInput label='Portfolio Description*' value={val} onChangeText={(text) => setValue(text)} labelSty={styles.lable} style={{width:'100%',marginBottom:10,height:hp(10)}}/>
    </View>
    {showPicker && (  <DateTimePicker    value={date} mode="date"  display="default" onChange={onChange} /> )}
    </PageLayout>
  );
};

export default PortFoiloAdd;

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    marginTop: hp(5),
    marginHorizontal:20, 
  }, 
  lable:{
    fontSize:12, 
  },
  icon: {
    justifyContent:'center',
    backgroundColor: MyColors.white, 
    right:40, 
  },
  buttonStyle: {
    backgroundColor: MyColors.white
  },
  dropdown:{
    backgroundColor:MyColors.white,
    marginHorizontal:hp(1.2), 
  },
});
