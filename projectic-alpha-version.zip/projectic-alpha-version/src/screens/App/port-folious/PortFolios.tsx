import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const PortFolios = () => {
  return (
    <View>
      
      <Text>PortFolios</Text>
    </View>
  )
}

export default PortFolios

const styles = StyleSheet.create({})