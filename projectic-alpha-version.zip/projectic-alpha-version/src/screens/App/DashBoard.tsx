import {Dimensions, Pressable, StyleSheet, View} from 'react-native';
import React, {useState} from 'react';
import PageLayout from '../../layouts/page-layout/page-layout';
import AppCard from '../../components/app-card/app-card';
import {MyColors} from '../../config/MyColors';
import {ScrollView} from 'react-native-gesture-handler';
import {hp, useOrientation} from '../../utils/constants';
import GlobalIcon from '../../config/GlobalIcons';
import AppInput from '../../components/app-input/app-input';
import {responsiveSize} from '../../config/Metrix';
import {BarChart} from 'react-native-gifted-charts';
import { yAxisLabels } from '../../utils/objects';
import { useNavigation } from '@react-navigation/native'; 
import { TouchableOpacity } from '@gorhom/bottom-sheet';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Text } from 'react-native-svg';
import moment from 'moment';


const DashBoard = () => {
  const navigation = useNavigation();
  const [val, setValue] = useState<string>('');
  const [date, setDate] = useState<string | any>(new Date());
  const [showPicker, setShowPicker] = useState(false);
  const barData = [
    {value: 250, label: 'Test1', frontColor: MyColors.orangeText},
    {value: 500, label: 'Test 2', frontColor: MyColors.mainYellow},
    {value: 745, label: 'Test 3', frontColor: MyColors.greenPrimary},
    {value: 320, label: 'Test 4', frontColor: MyColors.headerTitle},
    {value: 310, label: 'Test 4', frontColor: MyColors.buttonSecondary},
    {value: 310, label: 'Test 4', frontColor: MyColors.redSecondryAlpha},
  ];

  const onChange = (event: any, selectedDate: any) => {
    const currentDate = selectedDate || date;
    setShowPicker(false);
    setDate(currentDate);
  };

  const inputRightElement = (
    <Pressable style={styles.icon}>
      <GlobalIcon
        name="calendar"
        library="EvilIcons"
        size={hp(4)}
        color={MyColors.headerTitle}
      />
    </Pressable>
  );
  return (
    <PageLayout headerTitle="DASHBOARD">
      <ScrollView>
        <View style={styles.container}>
          <AppCard
            title={'PORTFOLIOS'}
            label={'Add New Portfolio'}
            iconName={'bag-shopping'}
            library={'FontAwesome6'}
            number={6}
            iconBgColor={MyColors.orangeText} 
            numberStyle={{
              color: MyColors.headerTitle,
            }}
            onpress={() => {navigation.navigate('port_folios')}}
            onpress1={() => {navigation.navigate('portfolio_add')}}
          /> 
          <AppCard title={'PROJECTS'} label={'Add New Project'} iconName={'bag-shopping'} library={'FontAwesome6'} number={3} iconBgColor={MyColors.textTitle} onpress={() => {navigation.navigate('project_view')}} onpress1={() => {navigation.navigate('project_add')}} /> 
          <AppCard title={'PEOPLE'} iconName={'account-group'} library={'MaterialCommunityIcons'} number={4} iconBgColor={MyColors.lightGreen} onpress={() => {navigation.navigate('people_view')}} />
          <AppCard title={'BUDGET'} library={'MaterialCommunityIcons'} amountTitle={'Estimated'} amount={'34,000'} actualAmount={'3,777'} navigation={'budget'} onpress={() => {navigation.navigate('budget')}} />
 
        </View>

         
        <View style={styles.chartMainContainer}>
          <View style={styles.menuIcon}>
            <GlobalIcon
              color={MyColors.black}
              size={hp(3)}
              name={'menu'}
              library={'Entypo'}
            />
          </View>

          <View style={styles.dateBox}>
          <View style={{ width: '45%' }}>
            <TouchableOpacity activeOpacity={0.7} onPress={() => { setShowPicker(true) }}>
              <AppInput editable={false} label="Start Date" placeholder="11/20/2023" value={val} onChangeText={text => console.log(text)} inputRightElement={inputRightElement} style={styles.calenderBox}/>
            </TouchableOpacity>
          </View>
          <View style={{ width: '45%' }}>
            <TouchableOpacity activeOpacity={0.7}  onPress={() => { setShowPicker(true) }}>
              <AppInput editable={false} label="Start Date" placeholder="11/20/2023" value={val} onChangeText={text => setValue(text)} inputRightElement={inputRightElement} style={styles.calenderBox}/>
            </TouchableOpacity>
          </View>
        </View>

          <View style={styles.chartContainer}>
           <ScrollView horizontal showsHorizontalScrollIndicator={false}>
           <Pressable style={{paddingRight: hp(2)}}>
           <BarChart
              width={Dimensions.get('window').width}  
              height={hp(70)}
              barWidth={25}
              noOfSections={11}
              barBorderRadius={2}
              frontColor="lightgray"
              data={barData}
              yAxisThickness={1}
              yAxisColor={'#DDE3FB'}
              xAxisThickness={1}
              xAxisColor={'#DDE3FB'}
              yAxisLabelTexts={yAxisLabels}
              stepHeight={50}
              spacing={40}  
              hideRules={true}
              showScrollIndicator={true}
            />
           </Pressable>
           </ScrollView>
          </View>
        </View>
      </ScrollView> 
      {showPicker && (  <DateTimePicker    value={date} mode="date"  display="default" onChange={onChange} /> )}
    </PageLayout>
  );
};

export default DashBoard;

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: hp(3),
  },
  chartMainContainer: {
    marginHorizontal: hp(3),
    marginTop: 20,
    backgroundColor: MyColors.white,
    padding: 10,
    marginBottom: hp(5)
  },
  menuIcon: {
    alignItems: 'flex-end',
  },
  dateBox: { 
    flexDirection: 'row', 
    justifyContent: 'space-around', 
    width: '100%',
    marginTop: hp(2), 
  },
  calenderBox: {
    // width: '100%',
    // width:hp(20),
    borderRadius: 20,
  },
  icon: {
    justifyContent:'center',
    backgroundColor: 'transparent', 
    right:30, 
    bottom: 3,
  }, 
  chartContainer: {
    width: '100%',
    alignItems: 'center',
    marginTop: hp(2),
    marginBottom: 20,
    borderColor: '#ECECEC',
    // borderWidth: 2,
    borderRadius: 10, 
  },
});
