import {StyleSheet, Text, View} from 'react-native';
import React from 'react'; 
import {MyStylesMain} from '../../styles/GlobalStyles';
import {FlatList} from 'react-native-gesture-handler';
import NotificationCard from '../../components/notification-card/notification-card';
import {notificationsData} from '../../utils/dummyData';
import CollectionLayout from '../../layouts/collection-layout/collection-layout';

const Notifications = () => {
  const globalStyle = MyStylesMain();


  return (
    <CollectionLayout
    containerStyle={globalStyle.container} 
    headerTitle={'NOTIFICATIONS'}
    flatList={{
        data: notificationsData,
        keyExtractor: (item, index) => index.toString(),
        listHeaderComponent: (<React.Fragment key={'list-header-components-fragment'}></React.Fragment>),
        listEmptyComponent: (<> </>),
        renderItem: ({ item, index }) =>  <NotificationCard item={item} /> ,
        // renderedItemsContainerStyle: { ...styles.renderContainer, ...styles.pageItem },
        // listFooterComponent: <View style={styles.footerContainer}></View>,
        onEndReachedThreshold: 0.01,
    }}
/> 
  );
};

export default Notifications;

const styles = StyleSheet.create({});
