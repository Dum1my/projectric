import { StyleSheet, Text, View } from 'react-native'
import React from 'react' 
import { useNavigation } from '@react-navigation/native';  
import PageLayout from '../../../../layouts/page-layout/page-layout';

const DashBoard = () => {
  const navigation = useNavigation();
  return (
    <PageLayout headerTitle='Dashboard'>  
    
            <View></View>
    </PageLayout>
  )
}

export default DashBoard

const styles = StyleSheet.create({
  container:{
    flex:1 
  },
  text:{

  }
})