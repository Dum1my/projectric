import { ScrollView, StyleSheet, Text, View } from 'react-native'
import React from 'react' 
import { useNavigation } from '@react-navigation/native';  
import PageLayout from '../../../layouts/page-layout/page-layout';
import UsersTable from './admin-tables/users-table';
import { MyColors } from '../../../config/MyColors';
import { hp } from '../../../utils/constants';
import CategoryAndItems from '../../../components/app-items/app-item';
import ArchiveTable from './admin-tables/archive-table';


 

const AdminArchive = () => {
  const navigation = useNavigation();
  const columns :any=[  
    { id: 1, name: 'NAME',  },  
    { id: 1, name: 'DELETED AT',  },  
    { id: 1, name: 'ACTION',  },   
]
  const values:any = [
    { name: 'Foodio 1 - Content development ', val1: '11-24-2024',val2: 'Restore',},       
    { name: 'Website Design', val1: '11-24-2024',val2: 'Restore',},       
    { name: 'Gather Requirements', val1: '11-24-2024',val2: 'Restore',},       
    { name: 'Opening Act for Alicia', val1: '11-24-2024',val2: 'Restore',},       
    { name: 'Booth Design & Build', val1: '11-24-2024',val2: 'Restore',},       
  ];

  const categories:any = [
    { id: 1, name: 'Project' },
    { id: 2, name: 'portfolio' },
    { id: 3, name: 'budget' },
    { id: 4, name: 'task' },
    { id: 5, name: 'project members' },
    { id: 6, name: 'people' },
    { id: 7, name: 'time sheet' },
    { id: 8, name: 'All save reports' },
  ];
  return (
    <PageLayout headerTitle='ARCHIVE'>  

    <View style={{marginTop:hp(2),marginHorizontal:hp(2)}}>
        <CategoryAndItems categories={categories} itemsData={categories} />
        </View>  
     
      <View  
      >
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: hp(0.5),}}>
        <ArchiveTable columns={columns} values={values} onPress={(data) => { console.log('----', data) }} />
        </ScrollView>
      </View> 
    </PageLayout>
  )
}

export default AdminArchive

const styles = StyleSheet.create({
  container:{ 

  },
  text:{

  }
})