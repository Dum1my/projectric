import { Pressable, StyleSheet, Text, View ,ScrollView} from 'react-native'
import React, { useCallback, useMemo, useRef, useState } from 'react' 
import { useNavigation } from '@react-navigation/native';  
import PageLayout from '../../../layouts/page-layout/page-layout';
import UsersTable from './admin-tables/users-table';
import { hp ,wp} from '../../../utils/constants';
import { MyColors } from '../../../config/MyColors';
import AppInput from '../../../components/app-input/app-input';
import GlobalIcon from '../../../config/GlobalIcons'; 
import AppModal from '../../../components/app-modal/app-modal';
import { MyFonts } from '../../../config/MyFonts';
import AppSelectDropdown, { AppDropdownData } from '../../../components/app-drop-down/app-drop-down';
import BottomSheet, { BottomSheetModal } from '@gorhom/bottom-sheet';
import AppButton from '../../../components/app-button/app-button';
import ReusableBottomSheet from '../../../components/app-bottom-sheet/app-bottom-sheet';

const AdminUsers = () => {
  const navigation = useNavigation();
  const [search, setSearch] = useState<string>('');
  const [isOpen, setOpen] = useState(false);
  const appSelectDropdownRef = useRef<AppDropdownData>(null);
  const columns :any=[
    { id: 1, name: '#',  },  
    { id: 1, name: 'NAME',  },  
    { id: 1, name: 'ROLE',  },  
    { id: 1, name: 'EMAIL',  },  
    { id: 1, name: 'date created',  },  
    { id: 1, name: 'system access',  },  
    { id: 1, name: 'actions',  },  
]
  const values:any = [
    { name: 'admin ', val1: 'manager',val2: 'Deckard@gmail.com',val3: '12-12-2024' ,v4:'pending',v5:'100'},       
    { name: 'devloper', val1: 'manager',val2: 'Deckard@gmail.com',val3: '12-12-2024' ,v4:'pending',v5:'100'},       
  ];

  const editFunc=()=>{
    // console.log('data: ', data);
    setOpen(true)
    
  }
  
  
  
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  
  // variables
  const snapPoints = useMemo(() => ['35%','90%'], []);
  
  // callbacks
  const openSheet = useCallback(() => { 
    bottomSheetModalRef.current?.present();
  }, []);
  
  const closeSheet = useCallback(() => { 
    bottomSheetModalRef.current?.close();
  }, []);
  const handleSheetChanges = useCallback((index: number) => {
    console.log('handleSheetChanges', index);
  }, []);
  
  const inputLeftElement = <Pressable style={styles.icon}><GlobalIcon name="search" library="EvilIcons" size={hp(2.5)} color={MyColors.grayText} /></Pressable>;
  return ( 
    <PageLayout headerTitle='USER ACCESS LEVEL SETTINGS' showRightIcon={true} onPressRight={()=>{openSheet()}} containerStyles={{marginHorizontal:wp(5),marginTop:hp(2)}}>  
    
    <View> 
    <AppInput   label="Search User Name"  placeholder="Search" inputLeftElement={inputLeftElement} value={search} onChangeText={(text) => setSearch(text)} style={styles.searchBox}/>
           
            <ScrollView horizontal showsHorizontalScrollIndicator={false}> 
              <UsersTable  columns={columns} values={values}  onPress={editFunc}/>
            </ScrollView> 

          <AppModal isOpen={isOpen} handleOnClose={()=>{setOpen(false)}} >
            <View style={{flex:1,width:'80%'}}>
                <View style={styles.heading}><Text style={styles.text_heading}>Edit User Credentials</Text></View>
            <ScrollView style={{marginHorizontal:10}} showsVerticalScrollIndicator={false}>
                    <View style={{marginTop:hp(2),  marginHorizontal:hp(1), }}> 
                     <AppInput   label="First Name" optional={true} labelSty={styles.lableText}   value={search} onChangeText={(text) => setSearch(text)} style={styles.input_m}/> 
                     <AppInput   label="Last Name"  optional={true} labelSty={styles.lableText}   value={search} onChangeText={(text) => setSearch(text)} style={styles.input_m}/> 
                     <AppInput   label="Email"      optional={true} labelSty={styles.lableText}   value={search} onChangeText={(text) => setSearch(text)} style={styles.input_m}/> 
                     <AppInput   label="User Name"                  labelSty={styles.lableText}   value={search} onChangeText={(text) => setSearch(text)} style={styles.input_m}/> 
                     <AppSelectDropdown dropdownName='Role' ref={appSelectDropdownRef}  options={['manager','admin']} _color={MyColors.black} container={styles.dropdown}  buttonStyle={styles.buttonStyle}/> 
                     <AppInput   label="Password"  labelSty={styles.lableText}    value={search} onChangeText={(text) => setSearch(text)} style={styles.input_m}/>  
                    </View>
            </ScrollView>
            <View style={styles.modalBottom}>
                <Pressable onPress={()=>{setOpen(false)}} style={[styles.btnBox,{borderRightWidth:0.2,borderColor:MyColors.disable}]}><Text style={[styles.textbtn,{color:MyColors.redPrimary}]}>Cancel</Text></Pressable>
                <Pressable onPress={()=>{setOpen(false)}}  style={styles.btnBox}><Text style={[styles.textbtn,{color:MyColors.greenPrimary}]}>Save</Text></Pressable>
            </View>
            </View>
          </AppModal>

          </View>
    
      <ReusableBottomSheet bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
                backdropComponent={({ style }) => (<Pressable onPress={()=>closeSheet()} style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >
        <ScrollView style={styles.contentContainer}>
          <View style={styles.heading}><Text style={styles.text_heading}>USER ACCESS LEVEL SETTINGS</Text></View>

          <AppSelectDropdown dropdownName='Filter User' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={[styles.dropdown,{marginHorizontal:hp(1)}]} />

          <AppButton title={'Search'} style={[styles.btn]} textStyle={styles.text2}  onPress={() => { closeSheet()}} />
        </ScrollView>
      </ReusableBottomSheet>
    </PageLayout> 
  )
}

export default AdminUsers

const styles = StyleSheet.create({
  container: { 
    flex: 1,
    width:'100%',
    borderWidth: 0.2,
    borderColor: MyColors.grayText,
    backgroundColor:MyColors.white,
    borderRadius: 5,
    padding: 10, 
    marginTop: hp(2),
    marginHorizontal: 10,
    height:hp(60) 
  },
  text:{

  },
  searchBox:{ 
    marginTop:hp(5)
  },
  icon:{ 
    justifyContent:'center',
    backgroundColor: MyColors.white, 
    left:10, 
    bottom:2,
},
input_m:{ 
  // marginHorizontal:hp(1), 
  backgroundColor:MyColors.white,
  marginTop:hp(.8), 
  marginBottom: hp(3),
}, 
dropdown:{
backgroundColor:MyColors.white,
// marginHorizontal:wp(3), 
bottom:hp(2),
marginBottom:hp(2),
},
heading:{  
  justifyContent:'center', 
  paddingLeft:hp(1),
  marginVertical:hp(1),
  height:hp(5), 
},
text_heading:{
  fontFamily:MyFonts.OpenSansBold,
  color:MyColors.black,
  fontSize:15,
},
modalBottom:{
  flexDirection:'row',
  width:'100%',
  height:hp(7)
},
btnBox:{
  alignItems:'center',
  justifyContent:'center', 
  width:'50%',
},
textbtn:{
  fontFamily:MyFonts.OpenSansSemiBold,
},
contentContainer: { 
  // backgroundColor:MyColors.offwhite,
  marginHorizontal:hp(2), 
},
btn:{
  borderRadius:25,
  backgroundColor:MyColors.mainYellow,  
},
text2:{
  color:MyColors.black
},
lableText:{
  fontSize:12,
  fontFamily:MyFonts.OpenSansSemiBold,
  color:MyColors.black,
},
buttonStyle: {
  backgroundColor: MyColors.white
},
})