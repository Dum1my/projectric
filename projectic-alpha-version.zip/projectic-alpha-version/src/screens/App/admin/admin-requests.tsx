import { ScrollView, StyleSheet, Text, View } from 'react-native'
import React from 'react' 
import { useNavigation } from '@react-navigation/native';  
import PageLayout from '../../../layouts/page-layout/page-layout';
import UsersTable from './admin-tables/users-table';
import { hp } from '../../../utils/constants';
import { MyColors } from '../../../config/MyColors';
import { MyFonts } from '../../../config/MyFonts';
import RequestTable from './admin-tables/request-table';
import GlobalIcon from '../../../config/GlobalIcons';

const AdminRequests = () => {
  const navigation = useNavigation();
  const columns :any=[
    { id: 1, name: '#',  },  
    { id: 1, name: 'MEMBER NAME',  },  
    { id: 1, name: 'EMAIL',  },   
    { id: 1, name: 'date created',  },   
    { id: 1, name: 'actions',  },  
]
  const values:any = [
    { name: 'admin ', val1: 'Deckard shaw',val2: 'deckard@gmail.com',val3: '12-12-2024' ,v4:'pending',v5:'100'},       
    { name: 'admin ', val1: 'Henry James',val2: 'henryJ@gmail.com',val3: '12-12-2024' ,v4:'pending',v5:'100'},       
    { name: 'admin ', val1: 'Cathy James',val2: 'cathyjames@yopmail.com',val3: '12-12-2024' ,v4:'pending',v5:'100'},       
    { name: 'admin ', val1: 'Joshua James',val2: 'joshua.james@futureisapp.com',val3: '12-12-2024' ,v4:'pending',v5:'100'},       
  ];
  return (
    <PageLayout headerTitle='ALL PENDING REQUESTS' >
      <View>

        <View style={styles.headingBox}><Text style={styles.textHeader}>Click <GlobalIcon name="check" library="Feather" size={hp(2)} color={MyColors.mainYellow} /> under Action Bar to grant user permission</Text></View>
        <View 
        // style={styles.container} 
        >
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: 10 }}>
            <RequestTable   columns={columns} values={values} onPress={(data) => { console.log('----', data) }} />
          </ScrollView>
        </View>
      </View>
    </PageLayout>
  )
}

export default AdminRequests

const styles = StyleSheet.create({
  container: { 
    flex: 1,
    width:'100%',
    borderWidth: 0.2,
    borderColor: MyColors.grayText,
    backgroundColor:MyColors.white,
    borderRadius: 5,
    padding: 10, 
    marginTop: hp(2),
    marginHorizontal: hp(2),
    height:hp(60)
    // height:'50%'
  },
  headingBox:{
    marginHorizontal:hp(2.5),
    marginTop:hp(1)
  },
  textHeader:{
    fontFamily:MyFonts.OpenSansRegular,
    color:MyColors.black, 
  }
})