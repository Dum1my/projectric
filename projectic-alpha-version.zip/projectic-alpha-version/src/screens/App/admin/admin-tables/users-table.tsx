import { Dimensions, GestureResponderEvent, Pressable, StyleSheet, Text, View ,FlatList, ScrollView, Alert, Switch} from 'react-native';
import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';   
import { hp } from '../../../../utils/constants';
import { MyColors } from '../../../../config/MyColors';
import { MyFonts } from '../../../../config/MyFonts'; 
import GlobalIcon from '../../../../config/GlobalIcons';

interface IProps { 
    columns?:[
      {
        id:number,
        name:string
      }
    ],
    values?:[
      {
        name: string, 
        val1: string,val2: string,val3: string ,v4:string,v5:string
      }
    ], 
    onPress: (event: GestureResponderEvent) => void;
}

const UsersTable: React.FC<IProps> = ({columns,values ,onPress}) => {  
  const [isEnabled, setIsEnabled] = useState(false);
  const toggleSwitch = () => setIsEnabled(previousState => !previousState);  
    // const screenWidth = Dimensions.get('window').width; 
    // const numColumns:any = values?.name.length; 
    // const columnWidth = numColumns;
    // let _width = Math.round(columnWidth);
    // console.log('columnWidth: ---->>', _width);

  const DataRow =({ index ,data}: { index: number,data:any })=>{    
      return(  
              <Pressable style={styles.dataCell} key={index}>
                  <View style={{ width: hp(5),  }}><Text style={[styles.datacelltext, { color: MyColors.textTitle }]}>{index+1}</Text></View>
                  <View style={{ width: hp(8),  }}><Text style={[styles.datacelltext, {}]}>{data?.name}</Text></View>
                  <View style={{ width: hp(15),  }}><Text style={[styles.datacelltext,{}]}>{data?.val1}</Text></View>
                  <View style={{ width: hp(17),  }}><Text style={[styles.datacelltext,{}]}>{data?.val2}</Text></View> 
                  <View style={{ width: hp(15),  }}><Text style={[styles.datacelltext,{}]}>{data?.val3}</Text></View> 
                  <View style={{ width: hp(15),     alignItems: 'center', }}><Switch  trackColor={{false: '#767577', true: '#81b0ff'}}  thumbColor={isEnabled ? '#f5dd4b' : '#f4f3f4'}   ios_backgroundColor="#3e3e3e"  onValueChange={toggleSwitch}  value={isEnabled}/></View> 
                  <View style={styles.actionBox}>
                    <Pressable onPress={(data)=> onPress(data)} style={{marginRight:hp(1)}}><GlobalIcon name="edit" library="Feather" size={hp(2)} color={MyColors.grayText} /></Pressable>
                    <Pressable><GlobalIcon name="delete" library="AntDesign" size={hp(2)} color={MyColors.grayText}  /></Pressable> 
                  </View> 
              </Pressable>   
      )
    }   
    
  return (
    <View   style={[ styles.container, { width: '100%' }]} >  

    {
      columns?.map((val:object, index:number)=>{ 
        if(index === 0){
          return( 
        <Pressable style={styles.headerRow} key={index}>
          <Text style={[styles.headerCell, { width: hp(5), }]}>#</Text>
          <Text style={[styles.headerCell, { width: hp(8), }]}>NAME</Text>
          <Text style={[styles.headerCell, { width: hp(15), }]}>ROLE</Text>
          <Text style={[styles.headerCell, { width: hp(17), }]}>EMAIL</Text>
          <Text style={[styles.headerCell, { width: hp(15), }]}>date created</Text> 
          <Text style={[styles.headerCell, { width: hp(15), }]}>system access</Text> 
          <Text style={[styles.headerCell, { width: hp(15), }]}>actions</Text>  
        </Pressable> 
          ) 
        }
      })
    }

      <ScrollView  showsVerticalScrollIndicator={false} horizontal={true} >
        <View style={styles.dataRow}>
        {/* <DataRow /> */}
        {values?.map((value:object, index:number) => (
            <DataRow key={index} index={index} data={value}/>
          ))}
        </View>
      </ScrollView> 
    </View>
  );
};

export default UsersTable;

const styles = StyleSheet.create({
    container: {
      flex: 1,
      borderWidth: 0.2,
      borderColor: MyColors.grayText,
      backgroundColor:MyColors.white,
      borderRadius: 5,
      padding: 10, 
      marginTop: hp(2),
      height:hp(70)
    },
    header: { 
      fontWeight: 'bold',
      textAlign: 'left', 
    },
    headerRow: {
      flexDirection: 'row',
      borderBottomWidth: 0.1,
      borderBottomColor:  MyColors.grayText,
      backgroundColor:MyColors.offwhite,
      paddingBottom: 5,
      marginBottom: 5, 
    },
    headerCell: {  
    fontFamily:MyFonts.OpenSansSemiBold,
    color: MyColors.black, 
    fontSize: 11, 
    textTransform:'uppercase',
    textAlign: 'left', 
    },
    dataRow: { 
      marginBottom: 5,  
    },
    dataCell: { 
      flexDirection:'row', 
      borderBottomWidth: 0.3, 
      borderBottomColor:MyColors.disable,
    //   marginVertical:hp(0.8),
      paddingVertical:hp(1),
      marginHorizontal:1, 
    },
    datacelltext:{
      // textAlign: 'left',
      color:MyColors.black,
      fontFamily:MyFonts.OpenSansRegular,
      // fontSize: 12,
    }, 
    actionBox:{
      flexDirection:'row',
      // justifyContent:'space-around', 
      width: hp(15),
      marginHorizontal:hp(1)
  }
  });