import { Dimensions, GestureResponderEvent, Pressable, StyleSheet, Text, View ,FlatList, ScrollView, Alert, Switch} from 'react-native';
import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';   
import { hp } from '../../../../utils/constants';
import { MyColors } from '../../../../config/MyColors';
import { MyFonts } from '../../../../config/MyFonts'; 
import GlobalIcon from '../../../../config/GlobalIcons';

interface IProps { 
    columns:any,
    values:any,
    onPress: (event: GestureResponderEvent) => void;
}

const ArchiveTable: React.FC<IProps> = ({columns,values ,onPress}) => {  
  console.log('columns: ', columns);
  const [isEnabled, setIsEnabled] = useState(false);
  const toggleSwitch = () => setIsEnabled(previousState => !previousState);  
    // const screenWidth = Dimensions.get('window').width; 
    // const numColumns:any = values?.name.length; 
    // const columnWidth = numColumns;
    // let _width = Math.round(columnWidth);
    // console.log('columnWidth: ---->>', _width);

  const DataRow =({ data}: { data:any })=>{     
      return(  
              <Pressable style={styles.dataCell} > 
                  <View style={{ width: hp(15),  }}><Text style={[styles.datacelltext, {}]}>{data?.name}</Text></View>
                  <View style={{ width: hp(15),  }}><Text style={[styles.datacelltext,{}]}>{data?.val1}</Text></View> 
                  <View style={{ width: hp(15),  }}><Text style={[styles.datacelltext,{color:MyColors.mainYellow}]}>{data?.val2}</Text></View> 
              </Pressable>   
      )
    }
 

  return (
    <View  style={[ styles.container, { width: '100%' }]}>  
    { 
      <Pressable style={styles.headerRow}>
        <Text style={[styles.headerCell, { width: hp(15), }]}>{columns[0].name}</Text>
        <Text style={[styles.headerCell, { width: hp(15), }]}>{columns[1].name}</Text>
        <Text style={[styles.headerCell, { width: hp(15), }]}>{columns[2].name}</Text> 
      </Pressable>
    }

      <ScrollView  showsVerticalScrollIndicator={false} > 
        <View style={styles.dataRow}>
        {values?.map((value:object, index:any) =>  <DataRow key={index}  data={value}/> )}
        </View>
      </ScrollView> 
    </View>
  );
};

export default ArchiveTable;

const styles = StyleSheet.create({
    container: {
      flex: 1,
      borderWidth: 0.2,
      borderColor: MyColors.grayText,
      backgroundColor:MyColors.white,
      borderRadius: 5,
      padding: 10, 
      marginTop: hp(2),
      height:hp(70),
      marginHorizontal: hp(2),
    },
    header: { 
      fontWeight: 'bold',
      textAlign: 'left', 
    },
    headerRow: {
      flexDirection: 'row',
      borderBottomWidth: 0.1,
      borderBottomColor:  MyColors.grayText,
      backgroundColor:MyColors.offwhite,
      paddingBottom: 5,
      marginBottom: 5, 
    },
    headerCell: {  
    fontFamily:MyFonts.OpenSansSemiBold,
    color: MyColors.black, 
    fontSize: 11, 
    textTransform:'uppercase',
    textAlign: 'left', 
    },
    dataRow: { 
      marginBottom: 5,  
    },
    dataCell: { 
      flexDirection:'row', 
      borderBottomWidth: 0.3, 
      borderBottomColor:MyColors.disable,
    //   marginVertical:hp(0.8),
      paddingVertical:hp(1),
      marginHorizontal:1, 
    },
    datacelltext:{
      textAlign: 'left',
      color:MyColors.black,
      fontFamily:MyFonts.OpenSansRegular,
      // fontSize: 12,
    }, 
    actionBox:{
      flexDirection:'row',
      // justifyContent:'space-around', 
      width: hp(15),
      marginHorizontal:hp(1)
  }
  });