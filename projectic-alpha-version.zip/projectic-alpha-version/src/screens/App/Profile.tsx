import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import PageLayout from '../../layouts/page-layout/page-layout';
import {hp, screen_height} from '../../utils/constants';
import {MyFonts} from '../../config/MyFonts';
import {responsiveSize} from '../../config/Metrix';
import {MyColors} from '../../config/MyColors';
import AppButton from '../../components/app-button/app-button';
import GlobalIcon from '../../config/GlobalIcons';
import LogoutIcon from '../../assets/svgs/LogoutIcon';
import { useNavigation } from '@react-navigation/native';
import { useDispatch } from 'react-redux';
import { saveInitalRoute, saveToken } from '../../store/user/userSlice';

const Profile = () => {
  const navigation = useNavigation()
  const dispatch = useDispatch()
  const handleSignOut = () => {
    console.log('--------');

    dispatch(saveToken(null))
    dispatch(saveInitalRoute('LogInScreen')) 
  };
  return (
    <PageLayout headerTitle="PROFILE">
      <View style={styles.container}>
        <View style={styles.innerContainer}>
          <View style={styles.titleContainer}>
            <Text style={styles.title}>Company Name:</Text>
            <Text style={styles.title}>Projectric</Text>
          </View>
          <View style={styles.titleContainer}>
            <Text style={styles.title}>Company Code:</Text>
            <Text style={styles.title}>@PROJ0001</Text>
          </View>
        </View>
        <View style={{marginTop: 20}}>
          <AppButton
            title="Invite"
            leftIcon={
              <GlobalIcon
                color={MyColors.headerTitle}
                size={hp(2.5)}
                name={'share'}
                library={'Entypo'}
              />
            }
            contentContainerStyle={styles.contentContainerStyle}
            centerContainerStyle={styles.centerContainerStyle}
            textStyle={styles.buttonText}
            style={styles.buttonStyle}
          />
          <AppButton
            title="Logout"
            leftIcon={
              <LogoutIcon height={2.5} width={2.5} />
            }
            contentContainerStyle={styles.contentContainerStyle}
            centerContainerStyle={styles.centerContainerStyle}
            textStyle={[styles.buttonText, {color: MyColors.white}]}
            style={[styles.buttonStyle, {backgroundColor: MyColors.redPrimary}]}
            onPress={() => handleSignOut()}
          />
        </View>
      </View>
    </PageLayout>
  );
};

export default Profile;

const styles = StyleSheet.create({
  container: {
    marginHorizontal: hp(2),
    marginTop: hp(5),
    flex: 1,
    justifyContent: 'space-between',
    height: screen_height / 1.4,
  },
  innerContainer:{
    marginHorizontal: hp(3)
  },
  titleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: hp(1),
  },
  title: {
    fontFamily: MyFonts.OpenSansSemiBold,
    fontSize: responsiveSize(15),
    color: MyColors.headerTitle,
  },
  contentContainerStyle: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  centerContainerStyle: {
    flex: 0,
  },
  buttonText: {
    color: MyColors.headerTitle,
    fontFamily: MyFonts.OpenSansSemiBold,
    fontSize: responsiveSize(12),
  },
  buttonStyle: {
    borderRadius: hp(5),
    marginVertical: hp(1)
  }
});
