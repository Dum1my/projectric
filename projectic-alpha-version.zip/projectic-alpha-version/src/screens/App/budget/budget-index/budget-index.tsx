import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import PageLayout from '../../../../layouts/page-layout/page-layout'; 
import { hp, wp } from '../../../../utils/constants';
import PorjectTable from '../../projects/project-tables/data-table'; 
import { MyColors } from '../../../../config/MyColors';
import { MyFonts } from '../../../../config/MyFonts';
import ReusableBottomSheet from '../../../../components/app-bottom-sheet/app-bottom-sheet';
import AppSelectDropdown, { AppDropdownData } from '../../../../components/app-drop-down/app-drop-down';
import AppButton from '../../../../components/app-button/app-button';
import { responsiveSize } from '../../../../config/Metrix';
import { BottomSheetModal } from '@gorhom/bottom-sheet';

const BudgetIndex = () => {
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const appSelectDropdownRef = useRef<AppDropdownData>(null);
  const [index, setIndex] = useState<number>();

  const data = [
    { id: 1, name: 'John', description: 'New York', budget: '2000', actual: '16', variance: '500' },
    { id: 2, name: 'Alice', description: 'Los Angeles', budget: '2000', actual: '16', variance: '500' },
    { id: 3, name: 'Bob', description: 'Chicago', budget: '2000', actual: '16', variance: '500' },
    { id: 4, name: 'Doe', description: 'Houston', budget: '2000', actual: '16', variance: '500' },
    { id: 4, name: 'Doe', description: 'Houston', budget: '2000', actual: '16', variance: '500' },
    { id: 4, name: 'Doe', description: 'Houston', budget: '2000', actual: '16', variance: '500' },
    { id: 4, name: 'Doe', description: 'Houston', budget: '2000', actual: '16', variance: '500' },
    { id: 4, name: 'Doe', description: 'Houston', budget: '2000', actual: '16', variance: '500' },
  ];
  const data1 =[ 'PORTFOLIO NAME','PROJECT NAME','BUDGET ($)', 'ACTUAL ($)', 'VARIANCE ($)' ]

const openSheet = useCallback(() => { 
  bottomSheetModalRef.current?.present();
}, []);

const closeSheet = useCallback(() => { 
  bottomSheetModalRef.current?.close();
}, []);

const handleSheetChanges = useCallback((index: number) => { 
  setIndex(index)
}, []);

const snapPoints = useMemo(() => ['42%','90%'], []);

  return (
    <PageLayout headerTitle='BUDGET' containerStyles={{width:'100%'}} showRightIcon={true} onPressRight={()=> openSheet()}> 
    <View style={styles.header}>
            <View style={styles.headerBox}>
                <Text style={styles.title}>BUDGET</Text>
                <Text style={[styles.title_amount,{color:MyColors.redPrimary}]}>$34,000</Text>
            </View> 
            <View style={styles.headerBox}>
                <Text style={styles.title}>ACTUAL</Text>
                <Text style={[styles.title_amount,{color:MyColors.greenPrimary}]}>$37,00</Text>
            </View> 
    </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginHorizontal:10}}>
           <PorjectTable data={data} data1={data1} cellWidth={wp(40)} /> 
        </ScrollView>

        <ReusableBottomSheet bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
        backdropComponent={({ style }) => (<Pressable onPress={()=>closeSheet()} style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >
          <ScrollView style={styles.modalContainer}>
          <Text style={styles.modalTitle}>BUDGET</Text>
          <AppSelectDropdown dropdownName='Portfolios' placeholder='All Portfolios' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} buttonStyle={styles.buttonStyle} />
          <AppSelectDropdown dropdownName='Projects' placeholder='All Projects' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} buttonStyle={styles.buttonStyle} />
          <AppButton title={'View Budget'}  style={[styles.btn]} textStyle={styles.text2}  onPress={() => closeSheet() } />
          </ScrollView>
      </ReusableBottomSheet>
    </PageLayout>
  );
};

export default BudgetIndex;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
    marginTop: hp(2),
  }, 
  header:{
    flexDirection:'row',
    // width:'95%',
    marginHorizontal:20,
    marginTop:hp(2), 
    backgroundColor:MyColors.white,
  },
  headerBox:{
    width:'50%',
    margin:hp(2)
  },
  title:{
    fontFamily:MyFonts.OpenSansRegular,
    fontWeight:'bold',
    fontSize:12
  },
  title_amount:{
    fontFamily:MyFonts.OpenSansSemiBold, 
    fontSize:20
  },
  modalContainer:{
    width: '100%',
    paddingHorizontal: wp(5)
  },
  modalTitle:{
    fontSize: responsiveSize(20),
    fontFamily: MyFonts.OpenSansBold,
    color: MyColors.headerTitle
  },
  buttonStyle: {
    backgroundColor: '#F8FAFF'
  },
  btn:{
    borderRadius:25,
    backgroundColor:MyColors.mainYellow,  
    marginTop:hp(5)
  },
  text2:{
    color:MyColors.black
  },
  dropdown:{
    backgroundColor:MyColors.white,
    marginHorizontal:hp(1.2), 
  },
});
