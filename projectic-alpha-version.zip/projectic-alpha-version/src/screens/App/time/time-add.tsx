import { Button, Dimensions, InputAccessoryView, Pressable, ScrollView, StyleSheet, Text, TextInput, View, } from 'react-native';
import React, { useRef, useState } from 'react';  
import PageLayout from '../../../layouts/page-layout/page-layout';
import { hp } from '../../../utils/constants';
import { MyFonts } from '../../../config/MyFonts';
import { MyColors } from '../../../config/MyColors';
import AppSelectDropdown, { AppDropdownData } from '../../../components/app-drop-down/app-drop-down';
import AppInput from '../../../components/app-input/app-input';
import GlobalIcon from '../../../config/GlobalIcons'; 
import AppCheckBox from '../../../components/app-check-box/app-check-box';
import { useNavigation } from '@react-navigation/native';

const TimeAdd = () => {
  const navigation:any = useNavigation();
    const appSelectDropdownRef = useRef<AppDropdownData>(null);
    const [val, setValue] = useState<string>('');


    const CountInput=({title})=>{
      return(
        <View style={styles.countBox}>
        <Text style={styles.titleCount}>{title}</Text>
        <View style={styles.countbox}>
          <TextInput style={styles.inputcunt} keyboardType="numeric" />
          <View>
            <GlobalIcon name="caretup" library="AntDesign" size={hp(1.3)} color={MyColors.headerTitle} /><GlobalIcon name="caretdown" library="AntDesign" size={hp(1.3)} color={MyColors.headerTitle} />
          </View>
        </View> 
        </View> 
      )
    }

  return (
    <PageLayout headerTitle='ADD NEW TIME' showBackIcon={true} containerStyles={{width:'100%'}} isFooter={true} single={true} footerTitle='Save' onPress={()=>navigation.navigate('time_entry')}>  
      <View style={styles.container}>
        <View style={{marginHorizontal:10}}>
          <Text style={styles.textTitle}>SELECTED USER: <Text style={{ color: MyColors.mainYellow }}>JOE SMITH</Text></Text>
        </View>
        <AppSelectDropdown dropdownName='Select Project' optional={true} ref={appSelectDropdownRef} options={[]} _color={MyColors.black} container={styles.dropdown} />
        <AppSelectDropdown dropdownName='Task' optional={true} ref={appSelectDropdownRef} options={[]} _color={MyColors.black} container={styles.dropdown} />

        <AppInput label='Description' optional={true} labelSty={{fontSize:12}} placeholder='' number={9} multiline={true} value={val} onChangeText={(text) => setValue(text)} style={styles.inputBox} inputStyle={styles.input} />
        <View style={styles.checkBox}><AppCheckBox /><Text>Billable</Text></View>
        <View style={styles.checkBox}><AppCheckBox /><Text>Overide Rate</Text></View>
        <View style={{ flexDirection: 'row', flex: 1 }}>
          <CountInput title={'MON, 08'} /><CountInput title={'TUE,09'} />
        </View>
        <View style={{ flexDirection: 'row' }}>
          <CountInput title={'WED,10'} /><CountInput title={'THU, 11'} />
        </View>
        <View style={{ flexDirection: 'row' }}>
          <CountInput title={'FRI, 12'} /><CountInput title={'SAT, 13'} />
        </View>


      </View>
    </PageLayout>
  );
};

export default TimeAdd;

const styles = StyleSheet.create({
    container:{ 
        marginTop:hp(2),
        marginHorizontal:hp(2),
        marginBottom:hp(4)
    },
    textTitle:{
        fontFamily:MyFonts.OpenSansBold,
        color:MyColors.headerTitle
    },
    dropdown:{ 
        marginHorizontal:hp(1.2), 
        marginTop:hp(1.5), 
        // backgroundColor:MyColors.white
        // backgroundColor:'red',
        // marginBottom:10 
      },
      inputBox:{
        top:hp(5),
        width:'95%', 
        paddingTop:hp(6),
        marginHorizontal:hp(1),   
        height:hp(22),  
        // backgroundColor:'red',
        
      },
      input:{
        height: 'auto', // Adjust height automatically for multiline input
        textAlignVertical: 'top',
        minHeight:130,  
        backgroundColor:MyColors.white,
      },
      countBox:{
        flex:1,
        width:'100%',
      },
      countbox:{
        marginTop:hp(1),
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: hp(0.1),
        borderColor: MyColors.disable,
        backgroundColor:MyColors.white,
        borderRadius: 5,
        padding: hp(0.1),
        paddingHorizontal:hp(.5),
        width:'90%', 
        marginHorizontal:hp(1),   
      },
      titleCount:{
        fontFamily:MyFonts.OpenSansBold,
        color:MyColors.headerTitle, 
        paddingLeft:hp(1), 
      },
      checkBox:{
        flexDirection:'row',
        marginHorizontal:5,
        justifyContent:'flex-start',
        marginVertical:hp(.3),
        paddingBottom:hp(2)
      },
      countinput:{
        flexDirection:'row', 
      }, 
      inputcunt:{
        flex: 1,
        textAlign: 'left', 
      }
});
