import { Button, Dimensions, InputAccessoryView, Pressable, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View, } from 'react-native';
import React, { useCallback, useMemo, useRef, useState } from 'react';  
import PageLayout from '../../../layouts/page-layout/page-layout';
import { hp } from '../../../utils/constants';
import { MyFonts } from '../../../config/MyFonts';
import { MyColors } from '../../../config/MyColors';
import AppSelectDropdown, { AppDropdownData } from '../../../components/app-drop-down/app-drop-down';
import AppInput from '../../../components/app-input/app-input';
import GlobalIcon from '../../../config/GlobalIcons';
import TimeApproveTable from './time-tables/time-approve-table';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import ReusableBottomSheet from '../../../components/app-bottom-sheet/app-bottom-sheet';
import AppButton from '../../../components/app-button/app-button';
import DateTimePicker from '@react-native-community/datetimepicker';

const TimeApprove = () => {
    const appSelectDropdownRef = useRef<AppDropdownData>(null);
    const bottomSheetModalRef = useRef<BottomSheetModal>(null);
    const [val, setValue] = useState<string>('');
    const [index, setIndex] = useState<number>();
    const [date, setDate] = useState(new Date());
    const [showPicker, setShowPicker] = useState(false);
    const columns =[
        { id: 1, name: 'DEPARTMENT NAME',  }, 
        { id: 2, name: 'TOTAL MEMBER',   }, 
        { id: 3, name: 'DEPARTMENT HEAD',},
        { id: 3, name: 'EMAIL'},
        { id: 3, name: 'ACTION'}, 
    ]
      const values = [
        { name: 'SEO', val1: '1',val2: 'Deckard shaw',val3: 'test@g.com' },  
      ];

      // variables
  const snapPoints = useMemo(() => ['35%','35%'], []);

  // callbacks
  const openSheet = useCallback(() => {
    bottomSheetModalRef.current?.present();
  }, []);
  const closeSheet = useCallback(() => { 
    bottomSheetModalRef.current?.close();
  }, []);

  const handleSheetChanges = useCallback((index: number) => { 
    console.log('index: ', index);
    setIndex(index)
  }, []);

  const onChange = (event:string, selectedDate:any) => {
    const currentDate = selectedDate || date;
    setShowPicker(false);
    setDate(currentDate);
  };
 
    const inputRightElement = <Pressable style={styles.icon}><GlobalIcon name="calendar" library="EvilIcons" size={hp(4)} color={MyColors.headerTitle} /></Pressable>;
  return (
    <PageLayout headerTitle='APPROVE TIME ENTRY' showRightIcon={true} onPressRight={()=>{openSheet()}} containerStyles={{width:'100%'}}>  
     { 
     index != 0 ?
       <View style={styles.container}> 
       <View style={styles.dateBox}> 
              <View style={{ width: '45%' }}>
                <TouchableOpacity activeOpacity={0.7} onPress={() => { setShowPicker(true) }}>
                  <AppInput editable={false} label='Filter List Start' placeholder='11/20/2023' value={val} onChangeText={(text) => setValue(text)} inputRightElement={inputRightElement} style={styles.calenderBox} />
                </TouchableOpacity>
              </View>
              <View style={{ width: '45%' }}>
                <TouchableOpacity activeOpacity={0.7} onPress={() => { setShowPicker(true) }}>
                  <AppInput editable={false} label='Filter List End' placeholder='11/20/2023' value={val} onChangeText={(text) => setValue(text)} inputRightElement={inputRightElement} style={styles.calenderBox} />
                </TouchableOpacity>
              </View>
       </View>
           <AppSelectDropdown dropdownName='Filter'  ref={appSelectDropdownRef} options={[]} _color={MyColors.black} container={styles.dropdown} />
           <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginHorizontal: 10 }}>
           <TimeApproveTable columns={columns} values={values}/>
           </ScrollView>
     </View>
     :
     <View style={[styles.container,{alignItems:'center',justifyContent:'center',marginTop:hp(30)}]}>
     <GlobalIcon name="clock-time-five" library="MaterialCommunityIcons" size={hp(10)} color={MyColors.black} />
     <Text style={styles.text_heading}>Please Select A User To Approve Time Entry</Text>
     </View>
     }

      <ReusableBottomSheet bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
        backdropComponent={({ style }) => (<Pressable onPress={()=>closeSheet()} style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >
        <ScrollView style={styles.contentContainer}> 

          <AppSelectDropdown dropdownName='Department' placeholder='Select' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown}  buttonStyle={styles.buttonStyle}/>
          <AppSelectDropdown dropdownName='Select User' placeholder='Select' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown}  buttonStyle={styles.buttonStyle}/>

          <AppButton title={'Search'}  style={[styles.btn]} textStyle={styles.text2}  onPress={() => { closeSheet()}} />
        </ScrollView>
      </ReusableBottomSheet>
      {showPicker && (  <DateTimePicker    value={date} mode="date"  display="default" onChange={onChange} /> )}
    </PageLayout>
  );
};

export default TimeApprove;

const styles = StyleSheet.create({
    container:{ 
        marginTop:hp(2), 
        marginHorizontal:hp(2),
        marginBottom:hp(4), 
    },
    dateBox:{
        flexDirection:'row',
        justifyContent:'space-around',  
        top:hp(2),  
        width:'100%', 
    },
    icon:{
        // top:hp(0.5),
        // left: hp(-5), 
        justifyContent:'center',
        backgroundColor: MyColors.white, 
        right:40, 
    },
    calenderBox:{ 
        // width:'45%',
        borderRadius:20, 
    },
    text_heading:{
      fontFamily:MyFonts.OpenSansSemiBold,
      color:MyColors.black,
      fontSize:15,
    },
    dropdown:{ 
        marginHorizontal: 10, 
        // backgroundColor:MyColors.white
      },

      contentContainer: {
        // flex: 1,
        // alignItems: 'center',
        // backgroundColor:MyColors.offwhite
      },
      btn:{
        borderRadius:25,
        backgroundColor:MyColors.mainYellow,  
        marginTop:hp(5)
      },
      text2:{
        color:MyColors.black
      },
      buttonStyle: {
        backgroundColor:MyColors.white
      },
});
