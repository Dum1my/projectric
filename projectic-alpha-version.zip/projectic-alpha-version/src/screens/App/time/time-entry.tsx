import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useCallback, useMemo, useRef, useState } from 'react'; 
import PageLayout from '../../../layouts/page-layout/page-layout';
import { MyFonts } from '../../../config/MyFonts';
import { hp, wp } from '../../../utils/constants';
import TimeTable from './time-tables/time-table';
import { useNavigation } from '@react-navigation/native';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import ReusableBottomSheet from '../../../components/app-bottom-sheet/app-bottom-sheet';
import { MyColors } from '../../../config/MyColors';
import AppSelectDropdown, { AppDropdownData } from '../../../components/app-drop-down/app-drop-down';
import AppButton from '../../../components/app-button/app-button';
import GlobalIcon from '../../../config/GlobalIcons';
import TimeIconSvg from '../../../assets/svgs/TimeIconSvg';

const TimeEntry = () => {
  const navigation:any = useNavigation();
  const appSelectDropdownRef = useRef<AppDropdownData>(null);
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const [index, setIndex] = useState<number>();
    const columns:any =[
        { id: 1, name: 'DEPARTMENT NAME',  }, 
        { id: 2, name: 'TOTAL MEMBER',   }, 
        { id: 3, name: 'DEPARTMENT HEAD',},
        { id: 3, name: 'EMAIL'},
        { id: 3, name: 'ACTION'}, 
    ]
      const values:any = [
        { name: 'SEO', val1: '1',val2: 'Deckard shaw',val3: 'test@g.com' },  
        { name: 'PMO', val1: '2',val2: 'Cathy James',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
        { name: 'SEO', val1: '33',val2: 'Deckard shaw',val3: 'test@g.com' }, 
      ];
  const screenWidth = Dimensions.get('window').width; 
       // variables
       const snapPoints = useMemo(() => ['35%'], []);

       // callbacks
       const openSheet = useCallback(() => { 
         bottomSheetModalRef.current?.present();
       }, []);
       const closeSheet = useCallback(() => { 
        bottomSheetModalRef.current?.close();
      }, []);
       const handleSheetChanges = useCallback((index: number) => {
         console.log('handleSheetChanges', index);
         setIndex(index)
       }, []);
  
  return (
    <PageLayout headerTitle='TIME ENTRY' showRightIcon={true} onPressRight={()=>{openSheet()}} containerStyles={{width:'100%'}} isFooter={true} single={true} footerTitle='+ Enter Time' onPress={()=>navigation.navigate('time_add')}>  
     
           { 
            index != 0 ?
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginHorizontal:10}}>
        <TimeTable columns={columns} values={values}/>
        </ScrollView>
        :
        <View style={styles.container}>
        <TimeIconSvg color={MyColors.black} width={hp(10)} height={hp(10)}  />
        <Text style={styles.text_heading}>Please Select A User To View Timing</Text>
        </View>
         }

        <ReusableBottomSheet bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
        backdropComponent={({ style }) => (<Pressable onPress={()=>closeSheet()} style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >
        <ScrollView style={styles.contentContainer}> 

        <AppSelectDropdown dropdownName='Department' placeholder='Select' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} />
        <AppSelectDropdown dropdownName='Select User' placeholder='Select' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} />

          <AppButton title={'Search'}  style={[styles.btn]} textStyle={styles.text2}  onPress={() => {closeSheet() }} />
        
        </ScrollView>
      </ReusableBottomSheet>
        
    </PageLayout>
  );
};

export default TimeEntry;

const styles = StyleSheet.create({
 
  contentContainer: {
    // flex: 1,
    // alignItems: 'center',
    marginHorizontal:wp(5),
    // backgroundColor:MyColors.offwhite
  },
  container:{
    alignItems:'center',justifyContent:'center',marginTop:hp(30)
  },
  text_heading:{
    fontFamily:MyFonts.OpenSansSemiBold,
    color:MyColors.black,
    fontSize:15,
  },
  btn:{
    borderRadius:25,
    backgroundColor:MyColors.mainYellow,  
    marginTop:hp(5)
  },
  text2:{
    color:MyColors.black
  },
  dropdown:{
    backgroundColor:MyColors.white,
    // marginHorizontal:wp(5),  
    // height:hp(5)
    },
});
