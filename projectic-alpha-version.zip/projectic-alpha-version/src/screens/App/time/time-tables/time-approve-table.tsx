import { Dimensions, GestureResponderEvent, Pressable, StyleSheet, Text, View ,FlatList, ScrollView, Alert} from 'react-native';
import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';    
import GlobalIcon from '../../../../config/GlobalIcons';
import { hp } from '../../../../utils/constants';
import { MyColors } from '../../../../config/MyColors';
import { MyFonts } from '../../../../config/MyFonts';
import AppCheckBox from '../../../../components/app-check-box/app-check-box';

interface IProps { 
    columns?:{ id: number; name: string; }[],
    values?:{ name: string; val1: string; val2: string; val3: string; }[], 
}

const TimeApproveTable: React.FC<IProps> = ({columns,values }) => {  
 

  const DataRow =({ index ,data}: { index: number,data:any })=>{  
      return(  
          <Pressable style={styles.dataCell}>
                <Pressable style={{width:hp(10),alignItems:'center',justifyContent: 'center'}}><View style={styles.btnAdd}><AppCheckBox /></View></Pressable> 
                <View style={[styles.headerFirstCell,{width:hp(20),}]}>
                  <View>
                  <View style={styles.descriptionContainer}>
                    <Text style={styles.descriptionTitle}>Project:</Text>
                    <Text style={styles.descriptionSubTitle}>Development</Text>
                  </View>
                  <View style={styles.descriptionContainer}>
                    <Text style={styles.descriptionTitle}>Billable:</Text>
                    <Text style={styles.descriptionSubTitle}>No</Text>
                  </View>
                  <View style={styles.descriptionContainer}>
                    <Text style={styles.descriptionTitle}>Override Rate:</Text>
                    <Text style={styles.descriptionSubTitle}>No</Text>
                  </View>
                  <View style={styles.descriptionContainer}>
                    <Text style={styles.descriptionTitle}>Description: <Text style={styles.descriptionSubTitle}>CREATE NEW BOX FOR FREE USERS</Text></Text>
                  </View>
                  </View></View> 
                <View style={[styles.headerFirstCell,{width:hp(20)}]}><Text style={[styles.datacelltext, {textAlign: 'left'}]}>2023-WK46(13-Nov - 19-Nov)</Text></View> 
                <View style={[styles.headerFirstCell,{width:hp(7)}]}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={[styles.headerFirstCell,{width:hp(7)}]}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={[styles.headerFirstCell,{width:hp(7)}]}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={[styles.headerFirstCell,{width:hp(7)}]}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={[styles.headerFirstCell,{width:hp(7)}]}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={[styles.headerFirstCell,{width:hp(7)}]}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={[styles.headerFirstCell,{width:hp(7)}]}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={[styles.headerFirstCell,{width:hp(10),alignItems:'center'}]}><Text style={styles.datacelltext}>11</Text></View> 
          </Pressable>  
      )
    }

  return (
    <View style={[styles.container, { width: '100%' }]}>

      <View style={styles.headerRow}>
        <Text style={[styles.headerCell, { width: hp(10), }]}>Actions</Text>
        <Text style={[styles.headerCell, { width: hp(20), }]}>Description</Text>
        <Text style={[styles.headerCell, { width: hp(20), }]}>Week</Text>
        <Text style={[styles.headerCell, { width: hp(7), textAlign: 'center'}]}>Mon</Text>
        <Text style={[styles.headerCell, { width: hp(7),textAlign: 'center' }]}>Tue</Text>
        <Text style={[styles.headerCell, { width: hp(7),textAlign: 'center' }]}>Wed</Text>
        <Text style={[styles.headerCell, { width: hp(7),textAlign: 'center' }]}>Thu</Text>
        <Text style={[styles.headerCell, { width: hp(7), textAlign: 'center'}]}>Fri</Text>
        <Text style={[styles.headerCell, { width: hp(7), textAlign: 'center'}]}>Sat</Text>
        <Text style={[styles.headerCell, { width: hp(7),textAlign: 'center' }]}>Sun</Text>
        <Text style={[styles.headerCell, { width: hp(10),textAlign: 'center' }]}>Total</Text>
      </View>
      <View style={styles.headerFirstRow}>
        <Text style={[styles.headerFirstCell, { width: hp(10), }]}></Text>
        <Text style={[styles.headerFirstCell, { width: hp(20), }]}></Text>
        <Text style={[styles.headerFirstCell, { width: hp(20),textAlign: 'left',}]}>2023-WK(45)</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>06</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>07</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>08</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>09</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>10</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>11</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>12</Text>
        <Text style={[styles.headerFirstCell, { width: hp(10), }]}></Text>
      </View>
      

      <ScrollView horizontal={true} >
        <View style={styles.dataRow}>
        {values?.map((value, index) => (
            <DataRow key={index} index={index} data={value}/>
          ))}
        </View>
      </ScrollView>

      <View style={styles.headerFirstRow}>
        <Text style={[styles.headerFirstCell, { width: hp(10), }]}></Text>
        <Text style={[styles.headerFirstCell, { width: hp(20), }]}></Text>
        <Text style={[styles.headerFirstCell, { width: hp(20),textAlign: 'left',}]}>SUB TOTAL</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>06</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>07</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>08</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>09</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>10</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>11</Text>
        <Text style={[styles.headerFirstCell, { width: hp(7), }]}>12</Text>
        <Text style={[styles.headerFirstCell, { width: hp(10), }]}>11</Text>
      </View>
    </View>
  );
};

export default TimeApproveTable;

const styles = StyleSheet.create({
    container: {
      flex: 1,
      borderWidth: 0.2,
      borderColor: MyColors.grayText,
      backgroundColor:MyColors.white,
      borderRadius: 5,
      padding: 10, 
      marginTop: hp(2),
    },
    header: {
      // flex: 1,
      fontWeight: 'bold',
      textAlign: 'left', 
    },
    headerRow: {
      flexDirection: 'row',
      borderBottomWidth: 0.1,
      borderBottomColor:  MyColors.grayText,
      backgroundColor:MyColors.offwhite,
      paddingBottom: 5,
      marginBottom: 5,
      paddingVertical: 5
      // flex: 1,
      // flexGrow:1,
    },
    headerCell: {  
    fontFamily:MyFonts.OpenSansSemiBold,
    color: MyColors.black, 
    fontSize: 13, 
    textAlign: 'left',
    textTransform:'uppercase',
    marginHorizontal:1,  
    },
    headerFirstRow: {
      flexDirection: 'row',
      borderBottomWidth: 0.1,
      borderBottomColor:  MyColors.grayText,
      paddingBottom: 5,
      marginBottom: 5,
    },
    headerFirstCell: {
      // fontFamily:MyFonts.OpenSansSemiBold,
      color: MyColors.headerTitle, 
      fontSize: 12,
      // textAlign: 'left',
      marginHorizontal:1, 
      textAlign: 'center',
      paddingVertical: hp(1.5) ,
      justifyContent: 'center',
      // alignItems: 'center'
    },
    dataRow: {
      // flexDirection: 'row',
      marginBottom: 5,  
    },
    dataCell: {
      // flex: 1,
      //  flexGrow:1,
      flexDirection:'row', 
      borderBottomWidth: 0.3, 
      borderBottomColor: '#ccc',
      marginVertical:hp(0.8),
      marginHorizontal:1, 
      paddingVertical:hp(1),
    //   backgroundColor:MyColors.redPrimary,
    },
    btnAdd:{
        // alignItems:'center',
        // backgroundColor:MyColors.redSecondry,
        // justifyContent:'center',
        // padding:5,
        marginRight:hp(6),
    },
    datacelltext:{
      // textAlign: 'left',
      textAlign: 'center',
      color:MyColors.black,
      fontFamily:MyFonts.OpenSansRegular,
      fontSize:12, 
    },
    activetext:{
        fontFamily:MyFonts.OpenSansRegular,
        color: MyColors.mainYellow,
        paddingLeft:hp(2) 
    },
    descriptionContainer:{
      flexDirection: 'row'
    },
    descriptionTitle:{
      fontSize: 12,
      fontFamily:MyFonts.OpenSansBold,
      color: MyColors.headerTitle
    },
    descriptionSubTitle:{
      fontSize: 12,
      fontFamily:MyFonts.OpenSansRegular,
      color: MyColors.headerTitle,
      marginLeft: hp(.5)
    }
  });