import { Dimensions, GestureResponderEvent, Pressable, StyleSheet, Text, View ,FlatList, ScrollView, Alert} from 'react-native';
import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';    
import GlobalIcon from '../../../../config/GlobalIcons';
import { hp } from '../../../../utils/constants';
import { MyColors } from '../../../../config/MyColors';
import { MyFonts } from '../../../../config/MyFonts';

interface IProps { 
    columns?:[],
    values?:[], 
}

const TimeTable: React.FC<IProps> = ({columns,values }) => {  
 

  const DataRow =({ index ,data}: { index: number,data:any })=>{  
      return(  
          <Pressable style={styles.dataCell}>
                <Pressable style={{width:hp(10),alignItems:'center',}}><View style={styles.btnAdd}><GlobalIcon name="add" library="Ionicons" size={hp(1.3)} color={MyColors.redPrimary} /></View></Pressable> 
                <View style={{width:hp(13),alignItems:'center'}}><Text style={[styles.datacelltext,{}]}  numberOfLines={2}></Text></View> 
                <View style={{width:hp(20),alignItems:'center'}}><Text style={styles.datacelltext}>2023-WK46(13-Nov - 19-Nov)</Text></View> 
                <View style={{width:hp(7),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={{width:hp(7),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={{width:hp(7),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={{width:hp(7),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={{width:hp(7),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={{width:hp(7),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={{width:hp(7),alignItems:'center'}}><Text style={styles.datacelltext}>155</Text></View> 
                <View style={{width:hp(14),alignItems:'center'}}><Text style={styles.datacelltext}></Text></View> 
          </Pressable>  
      )
    }

  return (
    <View style={[styles.container, { width: '100%' ,marginBottom:hp(3)}]}>

      <View style={styles.headerRow}>
        <Text style={[styles.headerCell, { width: hp(10), }]}>Actions</Text>
        <Text style={[styles.headerCell, { width: hp(13), }]}>Description</Text>
        <Text style={[styles.headerCell, { width: hp(20), }]}>Week</Text>
        <Text style={[styles.headerCell, { width: hp(7), }]}>Mon</Text>
        <Text style={[styles.headerCell, { width: hp(7), }]}>Tue</Text>
        <Text style={[styles.headerCell, { width: hp(7), }]}>Wed</Text>
        <Text style={[styles.headerCell, { width: hp(7), }]}>Thu</Text>
        <Text style={[styles.headerCell, { width: hp(7), }]}>Fri</Text>
        <Text style={[styles.headerCell, { width: hp(7), }]}>Sat</Text>
        <Text style={[styles.headerCell, { width: hp(7), }]}>Sun</Text>
        <Text style={[styles.headerCell, { width: hp(14), }]}>Total</Text>
      </View>

      <ScrollView horizontal={true} >
        <View style={styles.dataRow}>
        {values?.map((value, index) => (
            <DataRow key={index} index={index} data={value}/>
          ))}
        </View>
      </ScrollView>
    </View>
  );
};

export default TimeTable;

const styles = StyleSheet.create({
    container: {
      flex: 1,
      borderWidth: 0.2,
      borderColor: MyColors.grayText,
      backgroundColor:MyColors.white,
      borderRadius: 5,
      padding: 10, 
      marginTop: hp(2),
    },
    header: {
      // flex: 1,
      fontWeight: 'bold',
      textAlign: 'left', 
    },
    headerRow: {
      flexDirection: 'row',
      borderBottomWidth: 0.1,
      borderBottomColor:  MyColors.grayText,
      backgroundColor:MyColors.offwhite,
      paddingBottom: 5,
      marginBottom: 5,
      // flex: 1,
      // flexGrow:1,
    },
    headerCell: {  
      fontSize: 13, 
      textAlign: 'left',
      marginHorizontal:1, 
      color: MyColors.black, 
      textTransform:'uppercase', 
      fontFamily:MyFonts.OpenSansSemiBold,
    },
    dataRow: {
      // flexDirection: 'row',
      marginBottom: 5,  
    },
    dataCell: {
      // flex: 1,
      //  flexGrow:1,
      flexDirection:'row', 
      borderBottomWidth: 0.3, 
      borderBottomColor: '#ccc',
      marginVertical:hp(0.8),
      marginHorizontal:1, 
      paddingVertical:hp(1),
    //   backgroundColor:MyColors.redPrimary,
    },
    btnAdd:{
        // alignItems:'center',
        backgroundColor:MyColors.redSecondry,
        // justifyContent:'center',
        padding:5,
        marginRight:hp(6),
    },
    datacelltext:{
      textAlign: 'left',
      color:MyColors.black,
      fontFamily:MyFonts.OpenSansRegular,
      fontSize:12, 
    },
    activetext:{
        fontFamily:MyFonts.OpenSansRegular,
        color: MyColors.mainYellow,
        paddingLeft:hp(2) 
    }
  });