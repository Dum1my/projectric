import {
  Dimensions,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {hp, screen_width, wp} from '../../../utils/constants';
import Dots from '../../../components/app-dots/app-dots';
import {MyColors} from '../../../config/MyColors';
import {responsiveSize} from '../../../config/Metrix';
import {MyFonts} from '../../../config/MyFonts';
import GlobalIcon from '../../../config/GlobalIcons';
import ProjectDetailTable from './project-tables/project-detail-table';
import ProjectGanttChart from './project-tables/project-gantt-chart';
import {PieChart} from 'react-native-chart-kit';
import PageLayout from '../../../layouts/page-layout/page-layout';
import {useNavigation} from '@react-navigation/native';
import AppModal from '../../../components/app-modal/app-modal';
import AppInput from '../../../components/app-input/app-input';

const ProjectName = () => {
  const navigation = useNavigation();
  const [selectTab, setSelectTab] = useState<number>(0);
  const [selectArrowTab, setSelectArrowTab] = useState<number>(0);
  const [isOpen, setIsOpen] = useState<boolean>(false);

  const chart = [
    {
      name: 'Cancelled',
      population: 21500000,
      color: MyColors.greenPrimary,
      legendFontColor: '#7F7F7F',
      legendFontSize: 15,
    },
    {
      name: 'Not started',
      population: 2800000,
      color: MyColors.redPrimary,
      legendFontColor: '#7F7F7F',
      legendFontSize: 15,
    },
    {
      name: 'Complated',
      population: 527612,
      color: MyColors.redSecondry,
      legendFontColor: '#7F7F7F',
      legendFontSize: 15,
    },
    {
      name: 'Moscow',
      population: 11920000,
      color: MyColors.redSecondry,
      legendFontColor: '#7F7F7F',
      legendFontSize: 15,
    },
  ];

  const [data] = useState([
    {name: 'Project Flow'},
    {name: 'Intake'},
    {name: 'Requirements'},
    {name: 'Design & Build'},
    {name: 'QA'},
    {name: 'Go Live!'},
    {name: 'Post Validation'},
    {name: 'Sign-off'},
  ]);

  const [tabs] = useState([
    {name: 'Dashboard'},
    {name: 'Project Details'},
    {name: 'Budget'},
    {name: 'Milestones'},
    {name: 'Members'},
    {name: 'Task'},
  ]);

  const data2 = [
    {
      date: '2023-03',
      budget: '10,600.00',
      actual: '2,316.00',
      variance: '8,284.00',
      percentage: 21,
      note: '',
    },
    {
      date: '2023-03',
      budget: '10,600.00',
      actual: '2,316.00',
      variance: '8,284.00',
      percentage: 21,
      note: '',
    },
    {
      date: '2023-03',
      budget: '10,600.00',
      actual: '2,316.00',
      variance: '8,284.00',
      percentage: 21,
      note: '',
    },
    {
      date: '2023-03',
      budget: '10,600.00',
      actual: '2,316.00',
      variance: '8,284.00',
      percentage: 21,
      note: '',
    },
    {
      date: '2023-03',
      budget: '10,600.00',
      actual: '2,316.00',
      variance: '8,284.00',
      percentage: 21,
      note: '',
    },
    {
      date: '2023-03',
      budget: '10,600.00',
      actual: '2,316.00',
      variance: '8,284.00',
      percentage: 21,
      note: '',
    },
    {
      date: '2023-03',
      budget: '10,600.00',
      actual: '2,316.00',
      variance: '8,284.00',
      percentage: 21,
      note: '',
    },
  ];

  return (
    <PageLayout
      headerTitle="PROJECT NAME"
      footerTitle="Save As Template"
      showBackIcon={true}
      isFooter={true}
      single={true}
      footerbtnSty={{borderRadius: 20}}
      onPress={() => setIsOpen(true)}>
      <View style={{marginHorizontal: wp(5)}}>
        <View style={styles.heading}>
          <Dots
            dot={{
              backgroundColor: MyColors.mainYellow,
              width: hp(1.5),
              height: hp(1.5),
            }}
          />
          <Text style={styles.text_h}>
            {' '}
            KNZ - 32ND GOV PROCUREMENT CONFERENCE
          </Text>
        </View>
        <View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {data?.map((item, i) => (
              <Pressable
                onPress={() => setSelectArrowTab(i)}
                style={[
                  styles.flowBox,
                  selectArrowTab == i
                    ? {width: hp(17), backgroundColor: MyColors.buttonSecondary}
                    : {width: hp(15)},
                ]}
                key={i}>
                {selectArrowTab != i && <View style={styles.leftArrow} />}
                <View style={styles.flowBoxContainer}>
                  {selectArrowTab == i && (
                    <GlobalIcon
                      library="FontAwesome"
                      name="pencil-square-o"
                      size={hp(2)}
                      color={MyColors.white}
                    />
                  )}
                  <Text
                    style={{
                      marginLeft: hp(0.5),
                      color: selectArrowTab == i ? MyColors.white : '#616161',
                    }}>
                    {item.name}
                  </Text>
                </View>
                <View
                  style={[
                    styles.rightArrow,
                    selectArrowTab == i
                      ? {backgroundColor: MyColors.buttonSecondary}
                      : {backgroundColor: MyColors.lightoffgrey},
                  ]}
                />
              </Pressable>
            ))}
          </ScrollView>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {tabs?.map((item, i) => (
              <Pressable
                key={i}
                onPress={() => setSelectTab(i)}
                style={[
                  styles.tabBox,
                  i == selectTab
                    ? {
                        backgroundColor: MyColors.buttonSecondary,
                        borderWidth: 1,
                        borderColor: MyColors.grayText,
                      }
                    : {borderWidth: 1, borderColor: MyColors.grayText},
                ]}>
                <Text
                  style={[
                    styles.tabbtnText,
                    {
                      color:
                        i == selectTab ? MyColors.white : MyColors.grayText,
                    },
                  ]}>
                  {item.name}
                </Text>
              </Pressable>
            ))}
          </ScrollView>

          <View style={styles.healthBox}>
            <Text style={styles.title}>HEALTH</Text>
            <View style={styles.healthTitleBox}>
              <View style={{width: '50%'}}>
                <Text style={styles.healthTitle}>Time</Text>
                <Text style={styles.healthTitle}>Progress</Text>
                <Text style={styles.healthTitle}>Cost</Text>
              </View>
              <View style={{width: '50%'}}>
                <Text
                  style={[styles.healthTitle, {color: MyColors.headerTitle}]}>
                  0% behind schedule
                </Text>
                <Text
                  style={[styles.healthTitle, {color: MyColors.headerTitle}]}>
                  27% tasks complete
                </Text>
                <Text
                  style={[styles.healthTitle, {color: MyColors.headerTitle}]}>
                  54% Budget Spent to date
                </Text>
              </View>
            </View>
          </View>

          <View style={styles.chartBox}>
            <Text style={styles.title}>TASK</Text>
            <View style={styles.pieChartContainer}>
              <PieChart
                data={chart}
                width={Dimensions.get('window').width}
                height={hp(25)}
                chartConfig={{
                  decimalPlaces: 2,
                  color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
                  labelColor: (opacity = 1) =>
                    `rgba(255, 255, 255, ${opacity})`,
                }}
                accessor={'population'}
                backgroundColor={'transparent'}
                paddingLeft={`${screen_width / 4}`}
                hasLegend={false}
              />
            </View>
          </View>

          <View style={styles.pj_ganttChat}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <ProjectGanttChart />
            </ScrollView>
          </View>

          <View style={styles.projectDetailBudgetContainer}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <ProjectDetailTable
                title="PROJECT DETAILED BUDGET"
                items={data2}
              />
            </ScrollView>
          </View>
          <View style={[styles.chartBox, {marginBottom: hp(10)}]}>
            <Text style={styles.title}>MEMBER UTILZATION</Text>
            <View style={styles.memberInnerContainer}>
              <Text style={styles.memberTitleContainer}></Text>
              <Text style={styles.memberTitleContainer}>Name</Text>
            </View>
            <View style={{flexDirection: 'row', marginTop: hp(2)}}>
              <View style={styles.memberTitleContainer}>
                <GlobalIcon
                  library="Entypo"
                  name="chevron-small-down"
                  color={MyColors.grey}
                />
              </View>
              <Text style={styles.memberTitleContainer}>Courtney David</Text>
            </View>
          </View>
        </View>
      </View>

      <AppModal
        isOpen={isOpen}
        handleOnClose={() => setIsOpen(false)}
        modalViewStyle={{height: hp(42)}}>
        <View style={styles.modalContainer}>
          <Text
            style={[
              styles.title,
              {
                marginBottom: hp(5),
                paddingHorizontal: hp(2),
                paddingTop: hp(2),
              },
            ]}>
            SAVE AS TEMPLATE
          </Text>
          <View style={{padding: hp(2)}}>
            <AppInput
              label="Title"
              placeholder="Title"
              optional={true}
              value=""
              onChangeText={() => {}}
            />
            <AppInput
              label="Description"
              placeholder="Description"
              optional={true}
              value=""
              onChangeText={() => {}}
            />
          </View>
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.button}
              onPress={() => setIsOpen(false)}>
              <Text style={{color: MyColors.redPrimary}}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setIsOpen(false)}
              style={[
                styles.button,
                {borderLeftColor: MyColors.grayText, borderLeftWidth: 0.5},
              ]}>
              <Text style={{color: MyColors.greenPrimary}}>Save</Text>
            </TouchableOpacity>
          </View>
        </View>
      </AppModal>
    </PageLayout>
  );
};

export default ProjectName;

const styles = StyleSheet.create({
  footerLft: {
    backgroundColor: MyColors.redSecondry,
    borderColor: MyColors.redSecondry,
    width: '100%',
  },
  heading: {
    flexDirection: 'row',
    // justifyContent:'center',
    alignItems: 'center',
    marginTop: hp(3),
    marginBottom: hp(1),
  },
  text_h: {
    color: MyColors.headerTitle,
    fontFamily: MyFonts.OpenSansBold,
    fontSize: responsiveSize(14),
  },
  flowBox: {
    marginTop: hp(2),
    width: hp(15),
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    height: hp(3),
    marginHorizontal: hp(1.3),
    position: 'relative',
    backgroundColor: MyColors.lightoffgrey,
  },
  flowBoxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    justifyContent: 'center',
  },
  leftArrow: {
    backgroundColor: '#F8FAFF',
    height: hp(2),
    width: hp(2),
    transform: [{rotate: '45deg'}],
    position: 'absolute',
    left: -8,
    zIndex: -1,
  },
  rightArrow: {
    backgroundColor: MyColors.lightoffgrey,
    height: hp(2),
    width: hp(2),
    transform: [{rotate: '45deg'}],
    position: 'absolute',
    right: -8,
    zIndex: -1,
  },
  tabBox: {
    borderRadius: 30,
    width: hp(15),
    marginTop: hp(3.5),
    marginHorizontal: hp(1),
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabbtnText: {
    padding: hp(1),
    color: MyColors.white,
    textAlign: 'center',
  },
  healthBox: {
    marginTop: hp(2),
    backgroundColor: MyColors.white,
    borderRadius: 10,
    padding: 10,
    borderColor: MyColors.borderColor,
    borderWidth: 1,
  },
  healthTitleBox: {
    flexDirection: 'row',
    marginTop: hp(1),
  },
  healthTitle: {
    color: MyColors.greenPrimary,
    fontFamily: MyFonts.OpenSansRegular,
    fontSize: responsiveSize(12),
    marginTop: hp(0.5),
  },
  title: {
    fontSize: responsiveSize(15),
    fontFamily: MyFonts.OpenSansBold,
    color: MyColors.headerTitle,
  },
  chartBox: {
    marginTop: hp(2),
    backgroundColor: MyColors.white,
    borderRadius: 10,
    borderColor: MyColors.borderColor,
    borderWidth: 1,
    padding: 10,
  },
  pieChartContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  pj_ganttChat: {
    marginTop: hp(2),
    backgroundColor: MyColors.white,
    borderColor: MyColors.borderColor,
    borderWidth: 1,
    borderRadius: 10,
  },
  projectDetailBudgetContainer: {
    marginTop: hp(2),
  },
  ganerateProject: {
    alignContent: 'center',
    alignItems: 'center',
    // width:'50%',
    marginHorizontal: 15,
    marginTop: '44%',
  },
  ganerateTitle: {
    textAlign: 'center',
    color: MyColors.textTitle,
    fontSize: 20,
  },
  icon: {
    justifyContent: 'center',
    backgroundColor: 'transparent',
    right: 40,
    bottom: 3,
  },
  calenderBox: {
    borderRadius: 20,
    marginTop: hp(5),
  },
  memberInnerContainer: {
    flexDirection: 'row',
    paddingVertical: hp(2),
    borderBottomColor: MyColors.lightgrey,
    borderBottomWidth: 1,
  },
  memberTitleContainer: {width: '50%'},
  modalContainer: {
    width: hp(45),
    flex: 1,
    justifyContent: 'space-between',
  },
  buttonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  button: {
    width: '50%',
    justifyContent: 'center',
    alignItems: 'center',
    borderTopColor: MyColors.grayText,
    borderTopWidth: 0.5,
    paddingVertical: hp(2),
  },
});
