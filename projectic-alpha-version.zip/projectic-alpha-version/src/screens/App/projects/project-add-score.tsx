
import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useCallback, useMemo, useRef, useState } from 'react'; 
import { hp, wp } from '../../../utils/constants'; 
import AppInput from '../../../components/app-input/app-input'; 
import { MyColors } from '../../../config/MyColors';
import { useNavigation } from '@react-navigation/native'; 
import { MyFonts } from '../../../config/MyFonts';
import HeaderLayout from '../../../layouts/header-layout/header-layout'; 
import { BottomSheetModal } from '@gorhom/bottom-sheet'; 
import { MyStylesMain } from '../../../styles/GlobalStyles'; 
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { responsiveSize } from '../../../config/Metrix';
import ScoreTable from './project-tables/project-score';

const ProjectScore = () => {
  const navigation:any = useNavigation(); 
  const [search, setSearch] = useState<string>(''); 
  const [whyText, setWhyText] = useState<string>(''); 
  const columns =[ 'CATEGORY','EMAIL','DESIGNATION','DEPARTMENT','ACTION']
  const values = [
    { id: 1, category: 'Reward', matric: 'Revenue Increasing', description: 'This project will generate measurable, incremental revenue', reward:false,
    example: [ { name:'3 = samll risk'},{ name:'4 = samll risk'},{ name:'5 = samll risk'},] ,forecated:2,autualscore:2}, 
    { id: 1, category: 'Reward', matric: 'Revenue Increasing', description: 'This project will generate measurable, incremental revenue', reward: false,
    example: [ { name:'3 = samll risk'},{ name:'4 = samll risk'},{ name:'5 = samll risk'},] ,forecated:2,autualscore:2}, 
    { id: 1, category: 'Reward', matric: 'Revenue Increasing', description: 'This project will generate measurable, incremental revenue', reward: true,
    example: [ { name:'3 = samll risk'},{ name:'4 = samll risk'},{ name:'5 = samll risk'},] ,forecated:2,autualscore:2}, 
    { id: 1, category: 'Reward', matric: 'Revenue Increasing', description: 'This project will generate measurable, incremental revenue', reward: false,
    example: [ { name:'3 = samll risk'},{ name:'4 = samll risk'},{ name:'5 = samll risk'},] ,forecated:2,autualscore:2}, 
    { id: 1, category: 'Reward', matric: 'Revenue Increasing', description: 'This project will generate measurable, incremental revenue', reward: true,
    example: [ { name:'3 = samll risk'},{ name:'4 = samll risk'},{ name:'5 = samll risk'},] ,forecated:2,autualscore:2}, 
  ];
 
  
  return (
    <PageLayout headerTitle='ADD NEW SCORE'  containerStyles={{width:'100%'}} showBackIcon={true} isFooter={true} footerTitle='Submit' onPress={()=> navigation.goBack()}  single={true}>
        <View style={styles.container}>

        <View style={styles.inputContainer}>
            <AppInput label="Portfolio Name" optional={true} labelSty={styles.lable}  placeholder=""  value={search} onChangeText={(text) => setSearch(text)} style={styles.inputBox}/>
            <AppInput label="Why We Are Doing This Project" optional={true} labelSty={styles.lable}  placeholder=""  value={whyText} onChangeText={(text) => setWhyText(text)} style={styles.inputBox}/>
        </View>

        <ScrollView  horizontal showsHorizontalScrollIndicator={false} style={{minHeight: hp(55)}}> 
        <ScoreTable  columns={columns} values={values} />
        </ScrollView>


          <View style={styles.footerBox}>
              <Text style={styles.footerTitle}>RECOMMENDATION</Text>
              <View style={styles.recommendationBox}>
                <View style={[styles.header, {backgroundColor: MyColors.offwhite, padding: 5}]}>
                  <Text style={styles.title}>IMPACT</Text>
                  <Text style={[styles.title, {width: '20%',textAlign: 'center'}]}>RANGE</Text>
                </View>
                <View style={styles.header}>
                  <Text style={[styles.title, {color: MyColors.headerTitle, fontFamily: MyFonts.OpenSansRegular}]}>Projects looks feasible proceed</Text>
                  <Text style={[styles.title, {color: MyColors.greenPrimary,fontFamily: MyFonts.OpenSansRegular, width: '20%',textAlign: 'center'}]}>21 to 30</Text>
                </View>
                <View style={styles.header}>
                  <Text style={[styles.title, {color: MyColors.headerTitle,fontFamily: MyFonts.OpenSansRegular}]}>Projects is feasible but keep a close eye on it</Text>
                  <Text style={[styles.title, {color: MyColors.orangeText,fontFamily: MyFonts.OpenSansRegular,width: '20%',textAlign: 'center'}]}>11 to 20</Text>
                </View>
                <View style={styles.header}>
                  <Text style={[styles.title, {color: MyColors.headerTitle,fontFamily: MyFonts.OpenSansRegular}]}>Projects is risky, would not recommend - only proceed if it meets strategic objective. keep a very close eye</Text>
                  <Text style={[styles.title, {color: MyColors.greenPrimary,fontFamily: MyFonts.OpenSansRegular, width: '20%',textAlign: 'center'}]}>{`< 10`}</Text>
                </View>
              </View>
          </View>
        </View>
    </PageLayout>
  );
};

export default ProjectScore;

const styles = StyleSheet.create({
  container: {
    flex: 1,  
    // marginTop: hp(1),
    marginHorizontal: hp(3), 
  },
  inputContainer: {
    marginTop:hp(5),
    flexDirection:'row',
    justifyContent:'space-around',
    // width:'100%'
  },
  inputBox:{
    width:'46%',
  },
  lable:{
    fontSize: responsiveSize(9.5),
    fontFamily:MyFonts.OpenSansSemiBold,
    color:MyColors.black, 
  },
  btn:{
    borderRadius:25,
    backgroundColor:MyColors.mainYellow,  
    marginTop:hp(5)
  },
  text2:{
    color:MyColors.black
  },
  footerBox:{
    width: '100%',
    marginTop: hp(2),
    marginBottom:hp(5)
  },
  footerTitle: {
    color: MyColors.headerTitle,
    fontFamily: MyFonts.OpenSansBold,
    fontSize: responsiveSize(15)
  },
  recommendationBox:{
    padding: hp(1),
    marginTop: hp(1),
    borderRadius: 5,
    backgroundColor: MyColors.white
  },
  header:{
    flexDirection: 'row', 
    width: '100%',
    justifyContent: 'space-between',
    paddingHorizontal: hp(.2),
    marginBottom: hp(1)
  },
  title: {
    color: MyColors.black,
    fontFamily: MyFonts.OpenSansSemiBold,
    fontSize: responsiveSize(12),
    width: '80%'
  },
});
