import { Dimensions, GestureResponderEvent, Pressable, StyleSheet, Text, View ,FlatList, ScrollView, Alert, TextInput} from 'react-native';
import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';    
import GlobalIcon from '../../../../config/GlobalIcons';
import { hp, wp } from '../../../../utils/constants';
import { MyColors } from '../../../../config/MyColors';
import { MyFonts } from '../../../../config/MyFonts';

interface IProps { 
    columns?:object,
    values?:any, 
}

type InputCount={
    title?:string,
    count?:number
}

const ScoreTable: React.FC<IProps> = ({columns,values }) => {  
    const screenWidth = Dimensions.get('window').width; 
 
    const CountInput=({title,color})=>{
        return(
          <View style={styles.countBox}>
          {/* <Text style={styles.titleCount}>{title && title}</Text> */}
          <View style={[styles.countbox,{backgroundColor:color}]}>
            <TextInput style={styles.inputcunt} keyboardType="numeric" />
            <View style={{right:7}}> 
              <GlobalIcon name="caretdown" library="AntDesign" size={hp(1.3)} color={MyColors.headerTitle} />
            </View>
          </View> 
          </View> 
        )
      }


  const DataRow =({ index ,data}: { index: number,data:any })=>{  
      return(  
          <Pressable style={styles.dataCell} key={index}>
            {
              data.reward && 
              <View style={styles.rewardCount}>
               <View style={[styles.cellBox,{width:hp(20)}]}><CountInput color={MyColors.blue}/></View> 
              <View style={[styles.cellBox,{width:hp(20)}]}><CountInput color={MyColors.blue}/></View>  
              </View>
            } 
          {
            !data.reward &&
            <>
              <View style={[styles.cellBox, { width: hp(12) }]}><Text style={[styles.datacelltext]}>{data.category}</Text></View>
              <View style={[styles.cellBox, { width: hp(20), paddingHorizontal: hp(.5) }]}><Text style={styles.datacelltext} numberOfLines={2}>{data.matric}</Text></View>
              <View style={[styles.cellBox, { width: hp(25) }]}><Text style={styles.datacelltext}>{data.description}</Text></View>
              <View style={[styles.cellBox, { width: hp(15) }]}>
                {
                  data.example.map((v: any, i: number) => {
                    return (
                      <Text key={i} style={styles.datacelltext}>{v.name}</Text>
                    )
                  })
                }
              </View>
              <View style={[styles.cellBox, { width: hp(20) }]}><CountInput color={MyColors.white} /></View>
              <View style={[styles.cellBox, { width: hp(20) }]}><CountInput color={MyColors.white} /></View>
            </>
          }
        </Pressable>   
      )
    }

  return (
    <View style={[styles.container, { width: '100%' }]}>

      <View style={styles.headerRow}>
        <Text style={[styles.headerCell, { width: hp(12), }]}>CATEGORY</Text>
        <Text style={[styles.headerCell, { width: hp(20), }]}>METRIC</Text>
        <Text style={[styles.headerCell, { width: hp(25), }]}>DESCRIPTION</Text>
        <Text style={[styles.headerCell, { width: hp(15), }]}>EXAMPLE</Text>
        <Text style={[styles.headerCell, { width: hp(20), }]}>FORCASTED SCORE</Text>
        <Text style={[styles.headerCell, { width: hp(20), }]}>ACTUAL SCORE</Text> 
      </View>

      <ScrollView>
        <Pressable style={styles.dataRow}>
        {values.map((value:object, index:number) => (
            <DataRow key={index} index={index} data={value}/>
          ))}
          <Pressable style={styles.rewardCount}>
          <Text style={styles.totalScore}>Net Total Score</Text>
          <View style={[styles.cellBox,{width:hp(20), paddingRight:5}]}><Text style={styles.countScore}>0</Text></View> 
          <View style={[styles.cellBox,{width:hp(20)}]}><Text style={styles.countScore}>0</Text></View>  
          </Pressable>
        </Pressable>
      </ScrollView>
    </View>
  );
};

export default ScoreTable;

const styles = StyleSheet.create({
    container: {
      // flex: 1,
      borderWidth: 0.2,
      borderColor: MyColors.grayText,
      backgroundColor:MyColors.white,
      borderRadius: 5,
      padding: 10, 
      marginTop: hp(2), 
    },
    header: {
      // flex: 1,
      fontWeight: 'bold',
      textAlign: 'left', 
    },
    headerRow: {
      flexDirection: 'row',
      borderBottomWidth: 0.1,
      borderBottomColor:  MyColors.grayText, 
      paddingBottom: 5,
      marginBottom: 5, 
    //   marginLeft:wp(0.5)
    },
    headerCell: {  
    fontFamily:MyFonts.OpenSansSemiBold,
    color: MyColors.black, 
    fontSize: 13,  
    paddingHorizontal:hp(1.5), 
    // marginHorizontal:1,  
    },
    dataRow: { 
    //   marginBottom: 5,   
    },
    dataCell: { 
      flexDirection:'row', 
      borderBottomWidth: 0.3, 
      borderBottomColor: MyColors.disable, 
      paddingVertical:hp(1.5),
    //   marginHorizontal:1,  
      marginLeft:wp(3), 
    },
    cellBox:{

    },
    datacelltext:{
    //   textAlign: 'left',
      color:MyColors.black,
      fontFamily:MyFonts.OpenSansRegular,
    },
    activetext:{
        fontFamily:MyFonts.OpenSansRegular,
        color: MyColors.mainYellow,
        paddingLeft:hp(2) 
    },

    countBox:{
        // flex:1,
        // width:'100%', 
      },
      countbox:{
        // marginTop:hp(1),
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: hp(0.1),
        borderColor: MyColors.disable,
        backgroundColor:MyColors.white, 
        borderRadius: 5,
        // padding: hp(0.5),
        width:'90%', 
        // marginHorizontal:hp(1),   
      },
      rewardCount:{
        flex:1,
        justifyContent:'flex-end',
        flexWrap:'wrap-reverse',
        flexDirection:'row',
        alignSelf:'flex-end'
        },
      titleCount:{
        fontFamily:MyFonts.OpenSansBold,
        color:MyColors.headerTitle, 
        paddingLeft:hp(1), 
      },
      countinput:{
        flexDirection:'row', 
      }, 
      inputcunt:{
        flex: 1,
        textAlign: 'left',
        color:MyColors.white, 
      },
      totalScore: {
        textTransform:'uppercase',
        color:MyColors.black,
        fontFamily:MyFonts.OpenSansSemiBold,
      },
      countScore:{
        fontFamily:MyFonts.OpenSansSemiBold,
        paddingLeft:hp(.5),
        fontSize:15
      }
  });