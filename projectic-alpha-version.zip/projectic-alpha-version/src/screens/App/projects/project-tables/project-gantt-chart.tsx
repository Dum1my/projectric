import {Pressable, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {hp, wp} from '../../../../utils/constants';
import {MyColors} from '../../../../config/MyColors';
import GlobalIcon from '../../../../config/GlobalIcons';
import {MyFonts} from '../../../../config/MyFonts';
import {responsiveSize} from '../../../../config/Metrix';

const ProjectGanttChart = () => {
  const months = ['March', 'April', 'May'];
  const date = [
    '22 Mar 2023',
    '25 Mar 2023',
    '29 Mar 2023',
    '1 Apr 2023',
    '5 Apr 2023',
    '8 Apr 2023',
  ];

  const data = [
    {
      title: 'KNZ - 32nd Gov Procurement Conference',
      value: 85,
      items: [
        {
          title: 'Sponsorship Secured',
          value: 20,
          items_data: [
            {
              title: 'Review Sponsorship Prospectus',
              value: 12,
            },
            {
              title: 'Get Sponsorship Selection Approved',
              value: 12,
            },
            {
              title: 'Purchase Sponsorship',
              value: 12,
            },
          ],
        },
        {
          title: 'Sponsorship Secured',
          value: 20,
          items_data: [
            {
              title: 'Review Sponsorship Prospectus',
              value: 12,
            },
            {
              title: 'Get Sponsorship Selection Approved',
              value: 12,
            },
            {
              title: 'Purchase Sponsorship',
              value: 12,
            },
          ],
        },
      ],
    },
  ];

  return (
    <Pressable style={styles.container}>
      <Text style={styles.title}>PROJECT GANTT CHART</Text>

      <View>
        <View style={styles.tableContainer}>
          <View style={styles.emptySpace}></View>
          <View>
            <View style={styles.headerContainer}>
              <Text style={styles.monthHeading}>Mar 22,2023 - May 29,2023</Text>
              <View style={styles.headerSubContainer}>
                <Text style={styles.headerSubTitle}>Zoom</Text>
                <View style={styles.headerSubTitleContainer}>
                  <Text style={styles.headerSubTitle}>12W</Text>
                </View>
                <View style={styles.headerSubTitleContainer}>
                  <Text style={styles.headerSubTitle}>6W</Text>
                </View>
                <View style={styles.headerSubTitleContainer}>
                  <Text style={styles.headerSubTitle}>3W</Text>
                </View>
                <View style={styles.headerSubTitleContainer}>
                  <Text
                    style={[
                      styles.headerSubTitle,
                      {
                        color: MyColors.black,
                      },
                    ]}>
                    All
                  </Text>
                </View>
              </View>
            </View>
            <View style={styles.monthsContainer}>
              {months.map((item, index) => {
                return (
                  <View key={index} style={styles.month}>
                    <Text style={styles.monthTitle}>{item}</Text>
                  </View>
                );
              })}
            </View>
            <View style={styles.dateContainer}>
              {date.map((item, index) => {
                return (
                  <View key={index} style={styles.date}>
                    <Text style={styles.dateTitle}>{item}</Text>
                  </View>
                );
              })}
            </View>
          </View>
        </View>
        {data.map((item, index) => {
          return (
            <View key={index}>
              <View style={styles.itemContainer}>
                <View style={styles.items}>
                  <GlobalIcon
                    color={MyColors.headerTitle}
                    size={hp(1.5)}
                    name={'caretdown'}
                    library={'AntDesign'}
                  />
                  <Text style={styles.itemTitle}>{item?.title}</Text>
                </View>
                <View style={styles.colorsWidth}>
                  {item?.value && (
                    <View
                      style={[styles.color, {width: wp(item?.value)}]}></View>
                  )}
                </View>
              </View>
              {item?.items.length > 0 &&
                item?.items.map((val, index) => {
                  return (
                    <View key={index}>
                      <View style={styles.itemContainer}>
                        <View
                          style={[
                            styles.items,
                            {
                              paddingLeft: hp(3),
                            },
                          ]}>
                          <GlobalIcon
                            color={MyColors.headerTitle}
                            size={hp(1.5)}
                            name={'caretdown'}
                            library={'AntDesign'}
                          />
                          <Text style={styles.itemTitle}>{val?.title}</Text>
                        </View>
                        <View style={styles.colorsWidth}>
                          {val?.value && (
                            <View
                              style={[
                                styles.color,
                                {
                                  width: wp(val?.value),
                                  backgroundColor: MyColors.headerTitle,
                                },
                              ]}></View>
                          )}
                        </View>
                      </View>
                      {val?.items_data.length > 0 &&
                        val?.items_data.map((v, i) => {
                          return (
                            <View key={i} style={styles.itemContainer}>
                              <View
                                style={[
                                  styles.items,
                                  {
                                    paddingLeft: hp(5),
                                  },
                                ]}>
                                <Text style={styles.innerItemTitle}>
                                  {v?.title}
                                </Text>
                              </View>
                              <View style={styles.colorsWidth}>
                                {v?.value && (
                                  <View
                                    style={[
                                      styles.color,
                                      {
                                        width: wp(v?.value),
                                        backgroundColor: MyColors.grey,
                                      },
                                    ]}></View>
                                )}
                              </View>
                            </View>
                          );
                        })}
                    </View>
                  );
                })}
            </View>
          );
        })}
      </View>
    </Pressable>
  );
};

export default ProjectGanttChart;

const styles = StyleSheet.create({
  container: {
    padding: hp(2),
  },
  tableContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  emptySpace: {
    height: hp(10),
    width: wp(70),
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerSubContainer: {flexDirection: 'row', alignItems: 'center'},
  headerSubTitle: {
    color: MyColors.grayText,
    fontSize: responsiveSize(10),
    fontFamily: MyFonts.OpenSansRegular,
  },
  headerSubTitleContainer: {
    backgroundColor: '#F8F8F8',
    padding: hp(0.5),
    marginRight: hp(0.2),
  },
  monthHeading: {
    color: '#2F56C2',
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansRegular,
  },
  monthsContainer: {flexDirection: 'row'},
  month: {
    height: hp(5),
    width: wp(40),
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: MyColors.disable,
  },
  monthTitle: {
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansRegular,
    color: MyColors.headerTitle,
  },
  dateContainer: {flexDirection: 'row'},
  date: {
    height: hp(5),
    width: wp(20),
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: MyColors.disable,
  },
  dateTitle: {
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansRegular,
    color: MyColors.headerTitle,
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderColor: MyColors.disable,
    borderWidth: 1,
  },
  itemTitle: {
    fontFamily: MyFonts.OpenSansSemiBold,
    color: MyColors.headerTitle,
    fontSize: responsiveSize(12),
  },
  items: {
    width: wp(70),
    borderBottomColor: MyColors.disable,
    borderBottomWidth: 0.2,
    height: hp(5),
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  colorsWidth: {
    width: wp(70),
    height: hp(5),
    justifyContent: 'center',
    borderTopWidth: 0.5,
    borderBottomWidth: 0.2,
    borderLeftWidth: 1,
    borderTopColor: MyColors.disable,
    borderBottomColor: MyColors.disable,
    borderLeftColor: MyColors.disable,
    borderRightColor: 'transparent',
  },
  color: {
    height: hp(3),
    backgroundColor: 'yellow',
    marginLeft: hp(1),
  },
  title: {
    marginBottom: hp(1),
    fontFamily: MyFonts.OpenSansBold,
    fontSize: responsiveSize(15),
    color: MyColors.headerTitle,
  },
  innerItemTitle: {
    fontFamily: MyFonts.OpenSansRegular,
    fontSize: responsiveSize(12),
    color: MyColors.headerTitle,
  },
});
