import {Pressable, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {hp, wp} from '../../../../utils/constants';
import GlobalIcon from '../../../../config/GlobalIcons';
import {MyColors} from '../../../../config/MyColors';
import {ScrollView} from 'react-native-gesture-handler';
import {TouchableOpacity} from '@gorhom/bottom-sheet';
import {responsiveSize} from '../../../../config/Metrix';
import {MyFonts} from '../../../../config/MyFonts';

interface IProps {
  title?: string;
  serial?: boolean;
  cellWidth?: any;
  data?:{
        id: number | undefined;
        name: string | undefined;
        age?: number | undefined;
        location?: string | undefined;
      }
    | any;
  data1?: string[];
}

const PorjectTable: React.FC<IProps> = ({
  title,
  serial,
  cellWidth,
  data,
  data1,
}) => {
  return (
    <View style={[styles.container, {width: '100%'}]}>
      {title && <Text style={styles.header}>{title}</Text>}
      <Pressable style={[styles.headerRow]}>
        {serial && <Text style={[styles.headerCell, {width: wp(10)}]}>#</Text>}
        {data1?.map((item: any, index: number) => {
          return (
            <Text
              key={index}
              style={[
                styles.dataCell,
                { 
                  width: cellWidth,
                  color: MyColors.black,
                  fontSize: responsiveSize(12),
                  fontFamily: MyFonts.OpenSansSemiBold,
                },
              ]}>
              {item}
            </Text>
          );
        })}
      </Pressable>

      <ScrollView horizontal={false}>
        {data?.map((item: any, index: number) => {
          return (
            <Pressable key={index} style={styles.dataRow}>
              {serial && (
                <Text
                  style={[styles.dataCell, styles.cellTitle, {width: wp(10)}]}>
                  {item.id}
                </Text>
              )}
              {item?.name && (
                <Text
                  style={[
                    styles.dataCell,
                    styles.cellTitle,
                    {width: cellWidth},
                  ]}>
                  {item?.name}
                </Text>
              )}
              {item?.description && (
                <Text
                  style={[
                    styles.dataCell,
                    styles.cellTitle,
                    {width: cellWidth},
                  ]}>
                  {item?.description}
                </Text>
              )}
              {item?.budget && (
                <Text
                  style={[
                    styles.dataCell,
                    styles.cellTitle,
                    {width: cellWidth},
                  ]}>
                  {item?.budget}
                </Text>
              )}
              {item?.actual && (
                <Text
                  style={[
                    styles.dataCell,
                    styles.cellTitle,
                    {width: cellWidth},
                  ]}>
                  {item?.actual}
                </Text>
              )}
               {item?.variance && (
                <Text
                  style={[
                    styles.dataCell,
                    styles.cellTitle,
                    {width: cellWidth},
                  ]}>
                  {item?.variance}
                </Text>
              )}
                {item?.email && (
                <Text
                  style={[
                    styles.dataCell,
                    styles.cellTitle,
                    {width: cellWidth},
                  ]}>
                  {item?.email}
                </Text>
              )}
              {item?.designation && (
                <Text
                  style={[
                    styles.dataCell,
                    styles.cellTitle,
                    {width: cellWidth},
                  ]}>
                  {item?.designation}
                </Text>
              )}
              {item?.department && (
                <Text
                  style={[
                    styles.dataCell,
                    styles.cellTitle,
                    {width: cellWidth},
                  ]}>
                  {item?.department}
                </Text>
              )}
              {data1?.includes('ACTION') && (
                <View
                  style={[
                    styles.dataCell,
                    {
                      flexDirection: 'row',
                      alignItems: 'center',
                      width: cellWidth,
                    },
                  ]}>
                  <TouchableOpacity
                    style={{
                      padding: 5,
                      marginRight: 5,
                    }}>
                    <GlobalIcon
                      name="edit"
                      library="Feather"
                      size={hp(2)}
                      color={MyColors.grayText}
                    />
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={{
                      padding: 5,
                      marginRight: 5,
                    }}>
                    <GlobalIcon
                      name="delete"
                      library="AntDesign"
                      size={hp(2)}
                      color={MyColors.grayText}
                    />
                  </TouchableOpacity>
                </View>
              )}
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
};

export default PorjectTable;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 0.2,
    borderColor: MyColors.grayText,
    backgroundColor: MyColors.white,
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
    marginTop: hp(2),
  },
  header: {
    fontWeight: 'bold',
    textAlign: 'left',
  },
  headerRow: {
    flexDirection: 'row',
    borderBottomWidth: 0.1,
    borderBottomColor: MyColors.grayText,
    backgroundColor: MyColors.offwhite,
    paddingBottom: 5,
    marginBottom: 5,
  },
  headerCell: {
    fontWeight: 'bold',
    textAlign: 'left',
    padding: hp(0.3),
    marginHorizontal: 1,
    width: wp(40),
  },
  dataRow: {
    flexDirection: 'row',
    paddingVertical: hp(1),
    borderBottomWidth: 0.3,
    borderBottomColor: '#ccc',
  },
  dataCell: {
    textAlign: 'left',
    padding: hp(0.3),
    marginHorizontal: 1,
    width: wp(40),
  },
  cellTitle: {
    color: MyColors.headerTitle,
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansRegular,
  },
});
