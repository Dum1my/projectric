import {Pressable, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {MyColors} from '../../../../config/MyColors';
import {hp, wp} from '../../../../utils/constants';
import {MyFonts} from '../../../../config/MyFonts';
import {responsiveSize} from '../../../../config/Metrix';
import GlobalIcon from '../../../../config/GlobalIcons';
import { ScrollView } from 'react-native-gesture-handler';
import { useNavigation } from '@react-navigation/native';
import { TouchableOpacity } from '@gorhom/bottom-sheet';

interface ProjectViewTableProps {
  headingItems: string[];
  items: object[];
  title?: string;
}

const ProjectViewTable: React.FC<ProjectViewTableProps> = ({
  headingItems,
  items,
  title,
}) => {
  const navigation:any = useNavigation();
  return (
    <Pressable style={styles.container}>
      {title && <Text style={styles.title}>{title}</Text>}
      <View>
        <View style={styles.headingContainer}>
          {headingItems.map((item, index) => {
            return (
              <View
                key={index}
                style={[
                  styles.heading,
                  {
                    width: item == '#' ? wp(15) : wp(30),
                    alignItems: item == 'PROJECT NAME' || item == 'PORTFOLIO' ? 'flex-start' : 'center',
                  },
                ]}>
                <Text style={styles.headingTitle}>{item}</Text>
              </View>
            );
          })}
        </View>
        <ScrollView showsVerticalScrollIndicator={false} style={{height: hp(50)}}>
        {items.map((item: any, index) => {
          return (
            <View key={index} style={styles.itemsContainer}>
              {item?.id && (
                <View
                  style={[
                    styles.itemsTitle2,
                    {
                      width: item.id ? wp(15) : wp(25),
                    },
                  ]}>
                  <Text style={styles.itemText}>{item.id}</Text>
                </View>
              )}
              <TouchableOpacity activeOpacity={.6} style={[styles.itemsTitle, {alignItems: 'flex-start'}]} onPress={()=>{navigation.navigate('project_name')}}>
                <Text style={[styles.itemText, {textDecorationColor: MyColors.blue, textDecorationLine: 'underline',color: MyColors.blue}]}>{item.projectname}</Text>
              </TouchableOpacity>
              <TouchableOpacity activeOpacity={.6} style={[styles.itemsTitle2, {alignItems: 'flex-start'}]} onPress={()=>{ navigation.navigate('project_portfolio')}}>
                <Text style={[styles.itemText, {textDecorationColor: MyColors.blue,textDecorationLine: 'underline',color: MyColors.blue}]}>{item.portfolio}</Text>
              </TouchableOpacity>
              <View style={styles.itemsTitle2}>
                <Text style={styles.itemText}>{item.priority}</Text>
              </View>
              <View style={styles.itemsTitle2}>
                <Text style={styles.itemText}>{item.start_date}</Text>
              </View>
              <View style={styles.itemsTitle2}>
                <Text style={styles.itemText}>{item.end_date}</Text>
              </View>
              <View style={styles.itemsTitle2}>
                <View style={styles.statusIcon}></View>
              </View>
              <View style={styles.itemsTitle2}>
                <Text style={styles.itemText}>{item.budget}</Text>
              </View>
              <View style={styles.itemsTitle2}>
                <Text style={styles.itemText}>{item.actual}</Text>
              </View>
              <View style={styles.itemsTitle2}>
              <GlobalIcon color={MyColors.grayText} size={hp(2)} name={'delete'} library={'AntDesign'} />
              </View>
            </View>
          );
        })}
        </ScrollView>
      </View>
    </Pressable>
  );
};

export default ProjectViewTable;

const styles = StyleSheet.create({
  container: {
    backgroundColor: MyColors.white,
    paddingTop: hp(1),
    marginRight: hp(0.5),
    borderRadius: hp(1),
    borderWidth: 1,
    borderColor: MyColors.skyBlue,
  },
  title: {
    marginBottom: hp(1),
    fontFamily: MyFonts.OpenSansBold,
    fontSize: responsiveSize(12),
    color: MyColors.lightBlack,
    marginLeft: hp(2),
  },
  headingContainer: {
    flexDirection: 'row',
    backgroundColor: MyColors.offwhite,
    paddingVertical: hp(0.8),
  },
  heading: {
    justifyContent: 'center',
  },
  headingTitle: {
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansSemiBold,
    color: MyColors.lightBlack,
  },
  itemsContainer: {
    flexDirection: 'row',
    paddingVertical: hp(2),
    borderBottomColor: MyColors.skyBlue,
    borderBottomWidth: 1,
  },
  itemsTitle: {
    width: wp(30),
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemsTitle2: {
    width: wp(30),
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemText: {
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansRegular,
    color: MyColors.headerTitle,
  },
  statusIcon: {
    height: hp(2),
    width: hp(2),
    borderRadius: hp(2),
    backgroundColor: MyColors.aqua,
}
});
