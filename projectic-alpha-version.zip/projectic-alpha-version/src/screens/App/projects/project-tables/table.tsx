import {Pressable, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {MyColors} from '../../../../config/MyColors';
import {hp, wp} from '../../../../utils/constants';
import {MyFonts} from '../../../../config/MyFonts';
import {responsiveSize} from '../../../../config/Metrix';
import { useNavigation } from '@react-navigation/native';

interface TableProps {
  headingItems: string[];
  items: object[];
  title?: string;
}

const Table: React.FC<TableProps> = ({headingItems, items, title}) => {
  const navigation = useNavigation()
  return (
    <Pressable style={styles.container}>
      {title && <Text style={styles.title}>{title}</Text>}
      <View>
        <View style={styles.headingContainer}>
          {headingItems.map((item, index) => {
            return (
              <View
                key={index}
                style={[
                  styles.heading,
                  {
                    width: item == '#' ? wp(15) : wp(25),
                    alignItems:
                      item == 'PROJECT NAME' ? 'flex-start' : 'center',
                  },
                ]}>
                <Text style={styles.headingTitle}>{item}</Text>
              </View>
            );
          })}
        </View>
        {items.map((item: any, index) => {
          return (
            <View style={styles.itemsContainer} key={index}>
              {item?.id && (
                <View
                  style={[
                    styles.itemsTitle2,
                    {
                      width: item.id ? wp(15) : wp(25),
                    },
                  ]}>
                  <Text style={styles.itemText}>{item.id}</Text>
                </View>
              )}
              {item.name && (
                <View style={styles.itemsTitle}>
                  <Text style={styles.itemText}>{item.name}</Text>
                </View>
              )}
              <View style={styles.itemsTitle2}>
                <Text style={styles.itemText}>{item.reward}</Text>
              </View>
              <View style={styles.itemsTitle2}>
                <Text style={styles.itemText}>{item.risk}</Text>
              </View>
              <View style={styles.itemsTitle2}>
                <Text style={styles.itemText}>{item.score}</Text>
              </View>
              {headingItems.includes('VISIT') && (
                <TouchableOpacity onPress={() => navigation.navigate('project_score')} style={styles.itemsTitle2}>
                  <Text style={[styles.itemText, {color: MyColors.blue, textDecorationLine: 'underline'}]}>Visit</Text>
                </TouchableOpacity>
              )}
            </View>
          );
        })}
      </View>
    </Pressable>
  );
};

export default Table;

const styles = StyleSheet.create({
  container: {
    backgroundColor: MyColors.white,
    paddingTop: hp(1),
    marginRight: hp(0.5),
    borderRadius: hp(1),
    borderWidth: 1,
    borderColor: MyColors.skyBlue,
  },
  title: {
    marginBottom: hp(1),
    fontFamily: MyFonts.OpenSansBold,
    fontSize: responsiveSize(12),
    color: MyColors.lightBlack,
    marginLeft: hp(2),
  },
  headingContainer: {
    flexDirection: 'row',
    backgroundColor: MyColors.offwhite,
    paddingVertical: hp(0.8),
  },
  heading: {
    justifyContent: 'center',
  },
  headingTitle: {
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansSemiBold,
    color: MyColors.lightBlack,
  },
  itemsContainer: {
    flexDirection: 'row',
    paddingVertical: hp(2),
    borderBottomColor: MyColors.skyBlue,
    borderBottomWidth: 1,
  },
  itemsTitle: {
    width: wp(25),
    justifyContent: 'center',
  },
  itemsTitle2: {
    width: wp(25),
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemText: {
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansRegular,
    color: MyColors.headerTitle,
  },
});
