import {Pressable, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {MyColors} from '../../../../config/MyColors';
import {hp, wp} from '../../../../utils/constants';
import {MyFonts} from '../../../../config/MyFonts';
import {responsiveSize} from '../../../../config/Metrix';
import GlobalIcon from '../../../../config/GlobalIcons';
import { ScrollView } from 'react-native';

interface ProjectDetailTableProps {
  items: object[];
  title?: string;
}

const ProjectDetailTable: React.FC<ProjectDetailTableProps> = ({
  items,
  title,
}) => {
  const headings = ['Date', 'Budget ($)', 'Actual ($)', 'Variance ($)', 'Percentage (%)', 'Notes'];
  return (
    <Pressable style={styles.container}>
      {title && <Text style={styles.title}>{title}</Text>}
      <View style={styles.table}>
        <View style={styles.headingContainer}>
          {headings.map((item, index) => {
            return (
              <View
                key={index}
                style={[
                  styles.heading,
                  {
                    width: item == '#' ? wp(15) : wp(30),
                    // alignItems: 'center',
                    paddingHorizontal: hp(1)
                  },
                ]}>
                <Text style={styles.headingTitle}>{item}</Text>
              </View>
            );
          })}
        </View>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={{maxHeight: hp(30)}}>
          {items.map((item: any, index) => {
            return (
              <View key={index} style={[styles.itemsContainer, index == 0 && {backgroundColor: MyColors.lightBlue}]}>
                {item?.id && (
                  <View
                    style={[
                      styles.itemsTitle2,
                      {
                        width: item.id ? wp(15) : wp(25),
                      },
                    ]}>
                    <Text style={styles.itemText}>{item.id}</Text>
                  </View>
                )}
                <View style={styles.itemsTitle}>
                  <Text
                    style={
                      styles.itemText}>
                    {item.date}
                  </Text>
                </View>
                <View style={styles.itemsTitle2}>
                  <Text
                    style={
                      styles.itemText
                    }>
                    {item.budget}
                  </Text>
                </View>
                <View style={styles.itemsTitle2}>
                  <Text style={styles.itemText}>{item.actual}</Text>
                </View>
                <View style={[styles.itemsTitle2, {backgroundColor: index !- 0 ? '#DAF0E0' : 'transparent'}]}>
                  <Text style={styles.itemText}>{item.variance}</Text>
                </View>
                <View style={[styles.itemsTitle2, {backgroundColor: index !- 0 ? '#DAF0E0' : 'transparent'}]}>
                  <Text style={styles.itemText}>{item.percentage + "%"}</Text>
                </View>
                <View style={[styles.itemsTitle2, {
                    width: wp(50)
                }]}>
                  <Text style={styles.itemText}>{item.notes}</Text>
                </View>
              </View>
            );
          })}
        </ScrollView>
      </View>
    </Pressable>
  );
};

export default ProjectDetailTable;

const styles = StyleSheet.create({
  container: {
    backgroundColor: MyColors.white,
    paddingVertical: hp(1),
    marginRight: hp(0.5),
    borderWidth: 1,
    borderColor: MyColors.skyBlue,
    borderRadius: 10
  },
  table: {
    borderWidth: 1,
    marginHorizontal: 10,
    borderColor: '#AEAEAE'
  },
  title: {
    marginBottom: hp(1),
    fontFamily: MyFonts.OpenSansBold,
    fontSize: responsiveSize(12),
    color: MyColors.lightBlack,
    marginLeft: hp(2),
  },
  headingContainer: {
    flexDirection: 'row',
    backgroundColor: MyColors.offwhite,
    paddingVertical: hp(0.8),
  },
  heading: {
    justifyContent: 'center',
  },
  headingTitle: {
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansBold,
    color: MyColors.lightBlack,
  },
  itemsContainer: {
    flexDirection: 'row',
    borderBottomColor: MyColors.skyBlue,
    borderBottomWidth: 1,
  },
  itemsTitle: {
    width: wp(30),
    justifyContent: 'center',
    // alignItems: 'center',
    paddingVertical: hp(2),
    paddingHorizontal: hp(1)
  },
  itemsTitle2: {
    width: wp(30),
    justifyContent: 'center',
    // alignItems: 'center',
    paddingVertical: hp(2),
    paddingHorizontal: hp(1)
  },
  itemText: {
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansSemiBold,
    color: MyColors.headerTitle,
  },
  statusIcon: {
    height: hp(2),
    width: hp(2),
    borderRadius: hp(2),
    backgroundColor: MyColors.aqua,
  },
});
