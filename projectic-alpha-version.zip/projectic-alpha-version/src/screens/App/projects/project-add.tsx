import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useRef, useState } from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { hp, wp } from '../../../utils/constants';
import AppInput from '../../../components/app-input/app-input';
import AppSelectDropdown, { AppDropdownData } from '../../../components/app-drop-down/app-drop-down';
import { MyColors } from '../../../config/MyColors';
import { useNavigation } from '@react-navigation/native';
import GlobalIcon from '../../../config/GlobalIcons';
import { RFValue } from 'react-native-responsive-fontsize';
import { MyFonts } from '../../../config/MyFonts';



const ProjectAdd = () => {
    const navigation:any = useNavigation();
    const [val, setValue] = useState<string>('');
    const appSelectDropdownRef = useRef<AppDropdownData>(null);
    const inputRightElement = <Pressable style={styles.icon}><GlobalIcon name="calendar"  library="EvilIcons" size={hp(4)}  color={MyColors.headerTitle} /></Pressable>;
  
  return (
    <PageLayout headerTitle='ADD NEW PROJECT' footerTitle='Save' showBackIcon={true} isFooter={true} single={true} footerbtnSty={{borderRadius:20}} onPress={()=> navigation.navigate('project_view')}>  
    <View style={styles.container}>
        <AppInput label='Project Name' optional={true} value={val} onChangeText={(text) => setValue(text)} labelSty={styles.lable} style={{width:'100%',marginBottom:10}}/>
        <AppSelectDropdown labelText={styles.labelText} dropdownName='Link Project with Portfolio' ref={appSelectDropdownRef} options={[]} _color={MyColors.black} buttonStyle={styles.buttonStyle}/>
        <AppSelectDropdown labelText={styles.labelText} dropdownName='Project Type' optional={true} ref={appSelectDropdownRef} options={[]}_color={MyColors.black} buttonStyle={styles.buttonStyle}/>
        <AppSelectDropdown labelText={styles.labelText} dropdownName='Contact Person'ref={appSelectDropdownRef} options={[]} _color={MyColors.black}buttonStyle={styles.buttonStyle}/>
        <AppInput label='Project Start Date' placeholder='mm/dd/yy' optional={true} inputRightElement={inputRightElement} value={val} onChangeText={(text) => setValue(text)} labelSty={styles.lable} style={{width:'100%',marginTop:hp(5)}}/>
        <AppInput label='Project End Date' placeholder='mm/dd/yy' optional={true} inputRightElement={inputRightElement} value={val} onChangeText={(text) => setValue(text)} labelSty={styles.lable} style={{width:'100%', marginBottom: 5}}/>
        <AppSelectDropdown labelText={styles.labelText} dropdownName='Project Priority' optional={true} ref={appSelectDropdownRef} options={[]}  _color={MyColors.black} buttonStyle={styles.buttonStyle} />
        <AppSelectDropdown labelText={styles.labelText} dropdownName='Project Complexity' optional={true} ref={appSelectDropdownRef} options={[]}  _color={MyColors.black} buttonStyle={styles.buttonStyle} />
        <AppInput label='Project Hours' optional={true} value={val} onChangeText={(text) => setValue(text)} labelSty={styles.lable} style={{width:'100%',marginTop:hp(5)}}/>
        <AppInput label='Project Description' value={val} onChangeText={(text) => setValue(text)} labelSty={styles.lable} style={{width:'100%',marginBottom:10,minHeight: hp(12), maxHeight: hp(15)}} multiline={true} inputContainer={{minHeight: hp(12),maxHeight: hp(15)}}/>
    </View>
    </PageLayout>
  );
};

export default ProjectAdd;

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    marginTop: hp(5),
    marginHorizontal:20,
    paddingBottom: hp(5) 
  }, 
  lable:{
    fontSize:12, 
  },
  icon: {
    justifyContent:'center',
    backgroundColor: MyColors.white, 
    right:40, 
  },
  buttonStyle: {
    backgroundColor: MyColors.white
  },
  dropdown:{
    backgroundColor:MyColors.white,
    marginHorizontal:hp(1.2), 
  },
  labelText: {
    fontSize: RFValue(12),
    color: MyColors.black,
    fontFamily: MyFonts.OpenSansSemiBold,
  }
});
