import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { hp, wp } from '../../../utils/constants';
import AppInput from '../../../components/app-input/app-input'; 
import { useNavigation } from '@react-navigation/native';
import AppButton from '../../../components/app-button/app-button';
import ReusableBottomSheet from '../../../components/app-bottom-sheet/app-bottom-sheet';
import { responsiveSize } from '../../../config/Metrix';
import { MyFonts } from '../../../config/MyFonts';
import { MyColors } from '../../../config/MyColors';
import { BottomSheetModal } from '@gorhom/bottom-sheet';

const ProjectWorkFlow = () => {
  const navigation:any = useNavigation();
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const [index, setIndex] = useState<number>();
  const [step1, setStep1] = useState<string>('');
  const [step2, setStep2] = useState<string>('');
  const [step3, setStep3] = useState<string>('');
  const [step4, setStep4] = useState<string>('');
  const [step5, setStep5] = useState<string>('');
  const [step6, setStep6] = useState<string>('');
  const [step7, setStep7] = useState<string>('');

  const openSheet = useCallback(() => { 
    bottomSheetModalRef.current?.present();
  }, []);
  
  const closeSheet = useCallback(() => { 
    bottomSheetModalRef.current?.close();
  }, []);
  
  const handleSheetChanges = useCallback((index: number) => { 
    setIndex(index)
  }, []);
  
  const snapPoints = useMemo(() => ['25%','90%'], []);
  
  return (
    <PageLayout headerTitle='WORKFLOW' footerTitle='Save' onPress={() => navigation.navigate('project_view')} containerStyles={{width:'100%'}} isFooter={true} single={true} showRightIcon={true} onPressRight={()=> openSheet()}> 
    <View style={styles.container}>
    <AppInput label='Step 1' optional={true} placeholder='Intake' value={step1} onChangeText={(text) => setStep1(text)} labelSty={styles.lable} style={styles.input}/>
    <AppInput label='Step 2' optional={true} placeholder='Requirements' value={step2} onChangeText={(text) => setStep2(text)} labelSty={styles.lable} style={styles.input}/>
    <AppInput label='Step 3' optional={true} placeholder='Design & Build' value={step3} onChangeText={(text) => setStep3(text)} labelSty={styles.lable} style={styles.input}/>
    <AppInput label='Step 4' optional={true} placeholder='QA' value={step4} onChangeText={(text) => setStep4(text)} labelSty={styles.lable} style={styles.input}/>
    <AppInput label='Step 5' optional={true} placeholder='Go Live!' value={step5} onChangeText={(text) => setStep5(text)} labelSty={styles.lable} style={styles.input}/>
    <AppInput label='Step 6' optional={true} placeholder='Post Validation' value={step6} onChangeText={(text) => setStep6(text)} labelSty={styles.lable} style={styles.input}/>
    <AppInput label='Step 7' optional={true} placeholder='Sign-Off' value={step7} onChangeText={(text) => setStep7(text)} labelSty={styles.lable} style={styles.input} inputStyle={styles.inputText}/>
    </View>

    <ReusableBottomSheet bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
        backdropComponent={({ style }) => (<Pressable onPress={()=>closeSheet()} style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >
          <ScrollView style={styles.modalContainer}>
          <AppButton title={'Add Step'}  style={[styles.btn, {marginTop: hp(5), marginBottom: hp(2)}]} textStyle={styles.text2}  onPress={() => closeSheet() } />
          <AppButton title={'Remove Step'}  style={[styles.btn, {backgroundColor: '#F6F5F8'}]} textStyle={styles.text2}  onPress={() => closeSheet() } />
          </ScrollView>
      </ReusableBottomSheet>
    </PageLayout>
  );
};

export default ProjectWorkFlow;

const styles = StyleSheet.create({
  container: {
    flex: 1,  
    marginTop: hp(5),
    marginHorizontal:hp(2)
  }, 
  modalContainer:{
    width: '100%',
    paddingHorizontal: wp(5)
  },
  buttonStyle: {
    backgroundColor: '#F8FAFF'
  },
  btn:{
    borderRadius:25,
    backgroundColor:MyColors.mainYellow,  
  },
  text2:{
    color:MyColors.black
  },
  dropdown:{
    backgroundColor:MyColors.white,
    marginHorizontal:hp(1.2), 
  },
  lable:{
    fontSize:12,
  },
  input:{
    width:'100%',
    marginVertical:10,
    fontSize:2,
    marginBottom:hp(3)
  },
  inputText:{
    fontSize:10
  }
});
