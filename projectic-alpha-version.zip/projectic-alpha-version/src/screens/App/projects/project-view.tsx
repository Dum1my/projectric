import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React, {useCallback, useMemo, useRef, useState} from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout';
import {hp, wp} from '../../../utils/constants';
import AppInput from '../../../components/app-input/app-input';
import AppButton from '../../../components/app-button/app-button';
import {MyColors} from '../../../config/MyColors';
import {useNavigation} from '@react-navigation/native';
import ProjectViewTable from './project-tables/project-view-table';
import { responsiveSize } from '../../../config/Metrix';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import ReusableBottomSheet from '../../../components/app-bottom-sheet/app-bottom-sheet';
import { MyFonts } from '../../../config/MyFonts';
import AppSelectDropdown, { AppDropdownData } from '../../../components/app-drop-down/app-drop-down';
import GlobalIcon from '../../../config/GlobalIcons';

const ProjectView = () => {
  const navigation: any = useNavigation();
  const appSelectDropdownRef = useRef<AppDropdownData>(null);
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);
  const [search, setSearch] = useState<string>('');
  const [index, setIndex] = useState<number>();

  const headings = [
    '#',
    'PROJECT NAME',
    'PORTFOLIO',
    'PRIORITY',
    'START DATE',
    'END DATE',
    'STATUS',
    'BUDGET ($)',
    'ACTUAL ($)',
    'ACTION',
  ];

  const data = [
    {
      id: 1,
      projectname: 'Portable HET Scanner',
      portfolio: 'H Project',
      priority: 'medium',
      start_date: '11-17-2023',
      end_date: '12-17-2023',
      status: 'active',
      budget: 0,
      actual: 0,
    },
    {
      id: 2,
      projectname: 'Marketing & Ops',
      portfolio: 'Sand Box',
      priority: 'medium',
      start_date: '11-17-2023',
      end_date: '12-17-2023',
      status: 'active',
      budget: 0,
      actual: 0,
    },
    {
      id: 3,
      projectname: 'KNZ - 32nd Gov Procurement Conference Duplicate',
      portfolio: 35,
      priority: 'medium',
      end_date: '12-17-2023',
      start_date: '11-17-2023',
      status: 'active',
      budget: 0,
      actual: 0,
    },
    {
      id: 4,
      projectname: 'Issue TAB',
      portfolio: 40,
      priority: 9,
      start_date: '11-17-2023',
      end_date: '12-17-2023',
      status: 'active',
      budget: 0,
      actual: 0,
    },
    {
      id: 5,
      projectname: 'HET MRI',
      portfolio: 40,
      priority: 'medium',
      start_date: '11-17-2023',
      end_date: '12-17-2023',
      status: 'active',
      budget: 0,
      actual: 0,
    },
    {
      id: 6,
      projectname: 'DEVLEOPMENT',
      portfolio: 40,
      priority: 'medium',
      start_date: '11-17-2023',
      end_date: '12-17-2023',
      status: 'active',
      budget: 0,
      actual: 0,
    },
    {
      id: 7,
      projectname: 'API DOCUMENTATION',
      portfolio: 40,
      priority: 'medium',
      start_date: '11-17-2023',
      end_date: '12-17-2023',
      status: 'active',
      budget: 0,
      actual: 0,
    },
    {
      id: 8,
      projectname: '32nd Gov Procurment Conference',
      portfolio: 40,
      priority: 'medium',
      start_date: '11-17-2023',
      end_date: '12-17-2023',
      status: 'active',
      budget: 0,
      actual: 0,
    },
  ];

  const openSheet = useCallback(() => { 
    bottomSheetModalRef.current?.present();
  }, []);
  
  const closeSheet = useCallback(() => { 
    bottomSheetModalRef.current?.close();
  }, []);
  
  const handleSheetChanges = useCallback((index: number) => { 
    setIndex(index)
  }, []);
  
  const snapPoints = useMemo(() => ['30%','90%'], []);
  const inputLeftElement = <Pressable style={styles.icon}><GlobalIcon name="search" library="FontAwesome" size={hp(2)} color={MyColors.grayText} /></Pressable>;
  return (
    <PageLayout headerTitle="VIEW ALL"  footerTitle="Add New Score"  containerStyles={{width: '100%'}} showRightIcon={true} onPressRight={()=> openSheet()} >
      <View style={styles.container}>
        <AppInput  label="Search Projects" placeholder="Search"  value={search} onChangeText={text => setSearch(text)} inputLeftElement={inputLeftElement} style={{width: '100%',marginBottom:10}}  />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} >
          <ProjectViewTable headingItems={headings} items={data} />
        </ScrollView>

        <View style={styles.button}>
          <AppButton title='Apply Template' style={styles.applyButton} textStyle={styles.applyButtonText} onPress={()=>navigation.navigate('SelectTemplate')} />
          <AppButton title='+ Add New Project'  style={styles.newButton} textStyle={styles.newButtonText} onPress={()=>navigation.navigate('project_add')} />
        </View>
      </View>


      <ReusableBottomSheet  bottomSheetModalRef={bottomSheetModalRef} snapPoints={snapPoints} handleSheetChanges={handleSheetChanges}
        backdropComponent={({ style }) => (<Pressable onPress={()=>closeSheet()} style={[style, { backgroundColor: 'rgba(0, 0, 0, 0.7)' }]} />)} >
          <ScrollView style={styles.modalContainer}>
          <Text style={styles.modalTitle}>View All</Text>
          <AppSelectDropdown dropdownName='Fliter Portfolio' placeholder='All' ref={appSelectDropdownRef} options={['All', 'admin']} _color={MyColors.black} container={styles.dropdown} buttonStyle={styles.buttonStyle} />
          <AppButton title={'Search'}  style={[styles.btn, {marginTop: hp(5), marginBottom: hp(2)}]} textStyle={styles.text2}  onPress={() => closeSheet() } />
          </ScrollView>
      </ReusableBottomSheet>
    </PageLayout>
  );
};

export default ProjectView;

const styles = StyleSheet.create({
  container:{paddingHorizontal: hp(2), marginVertical: hp(5)},
  button: {flexDirection: 'row', marginTop: hp(4), justifyContent: 'space-between'},
  applyButton :{
    borderRadius: hp(10),
    width: '45%',
    backgroundColor: 'transparent',
    borderColor: MyColors.mainYellow,
    borderWidth: 2,
  },
  applyButtonText: {
    fontSize: responsiveSize(12),
    color: MyColors.mainYellow
  },
  newButton: {
    borderRadius: hp(10),
    width: '45%',
  },
  newButtonText: {
    fontSize: responsiveSize(10),
    color: MyColors.black
  },
  modalContainer:{
    width: '100%',
    paddingHorizontal: wp(5)
  },
  modalTitle:{
    fontSize: responsiveSize(15),
    fontFamily: MyFonts.OpenSansBold,
    color: MyColors.black,
    paddingLeft:hp(1)
  },
  btn:{
    borderRadius:25,
    backgroundColor:MyColors.mainYellow,  
  },
  text2:{
    color:MyColors.black
  },
  buttonStyle: {
    backgroundColor: '#F8FAFF'
  },
  dropdown:{
    backgroundColor:MyColors.white,
    marginHorizontal:hp(1.2), 
  },
  icon:{
    left: hp(1),
    marginRight: wp(2)
},
  // container: {
  //   flex: 1,
  //   borderWidth: 1,
  //   borderColor: '#ccc',
  //   borderRadius: 5,
  //   padding: 10,
  //   marginBottom: 20,
  //   marginTop: hp(2),
  // },
  // header: {
  //   // flex: 1,
  //   fontWeight: 'bold',
  //   textAlign: 'left',
  // },
  // headerRow: {
  //   flexDirection: 'row',
  //   borderBottomWidth: 1,
  //   borderBottomColor: '#ccc',
  //   paddingBottom: 5,
  //   marginBottom: 5,
  // },
  // headerCell: {
  //   flex: 1,
  //   fontWeight: 'bold',
  //   textAlign: 'center',
  // },
  // dataRow: {
  //   flexDirection: 'row',
  //   marginBottom: 5,
  // },
  // dataCell: {
  //   flex: 1,
  //   textAlign: 'center',
  // },
  // footerBtn: {
  //   width: '40%',
  // },
  // footerLft: {},
  // textsty1: {
  //   color: MyColors.mainYellow,
  // },

});
