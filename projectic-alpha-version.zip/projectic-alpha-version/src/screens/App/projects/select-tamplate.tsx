import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useRef, useState } from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { hp, screen_width, wp } from '../../../utils/constants';
import { MyColors } from '../../../config/MyColors';
import { useNavigation } from '@react-navigation/native';
import AppSelectDropdown from '../../../components/app-drop-down/app-drop-down';
import Dots from '../../../components/app-dots/app-dots';
import {
  PieChart,
} from "react-native-chart-kit";
import ProjectDetailTable from './project-tables/project-detail-table';
import ProjectGanttChart from './project-tables/project-gantt-chart';
import { responsiveSize } from '../../../config/Metrix';
import { MyFonts } from '../../../config/MyFonts';
import GlobalIcon from '../../../config/GlobalIcons';
import AppInput from '../../../components/app-input/app-input';
import { RFValue } from 'react-native-responsive-fontsize';
import PieChartWithLabels from '../../../components/pie-chart/PieChart';
import { color } from 'd3';
 

const SelectTemplate = () => {
  const navigation:any = useNavigation();
  const [active, setActive] = useState(0); 
  const [date,setDate] = useState<string>('')
  const [selectTab, setSelectTab] = useState<number>(0)
  const [selectArrowTab, setSelectArrowTab] = useState<number>(0)
  const [data] = useState([
    {name:'Project Flow'},
    {name:'Intake'},
    {name:'Requirements'},
    {name:'Design & Build'},
    {name:'QA'},
    {name:'Go Live!'},
    {name:'Post Validation'},
    {name:'Sign-off'},
  ])
  const chart = [
    {
      name: "Cancelled",
      population: 21500000,
      color: MyColors.greenPrimary,
      legendFontColor: "#7F7F7F",
      legendFontSize: 15
    },
    {
      name: "Not started",
      population: 2800000,
      color: MyColors.redPrimary,
      legendFontColor: "#7F7F7F",
      legendFontSize: 15
    },
    {
      name: "Complated",
      population: 527612,
      color: MyColors.redSecondry,
      legendFontColor: "#7F7F7F",
      legendFontSize: 15
    }, 
    {
      name: "Moscow",
      population: 11920000,
      color:  MyColors.redSecondry,
      legendFontColor: "#7F7F7F",
      legendFontSize: 15
    }
  ];
  const [tabs] = useState([
    {name:'Dashboard'},
    {name:'Project Details'},
    {name:'Budget'},
    {name:'Milestones'},
    {name:'Members'},
    {name:'Task'}, 
  ])

  const titles =[
    { id: 1, name: 'Date($)',  },
    { id: 2, name: 'Budget($)',  },
    { id: 3, name: 'Actual($)',   }, 
    { id: 3, name: 'Variance($)',   },
    { id: 3, name: 'Percentage(%)',   },
]
  const rows = [
    { id: 1, name: 'John', age: 30, location: 'New York' },
    { id: 2, name: 'Alice', age: 25, location: 'Los Angeles' },
    { id: 3, name: 'Bob', age: 35, location: 'Chicago' }, 
  ];
  const dropdownRef= useRef() 

  const generateFunc=()=>{ 
    setActive(active+1);  
    if(active== 2){
      console.log('active: ', active);
      navigation.navigate('project_view')
    }
  }
  const countries = ["1", "2", "4", "3"]
  let title = active == 0 ? 'SELECT TEMPLATE' :active == 1 ? 'PREVIEW': active == 2 ? 'GENERATE PROJECT':'SELECT TEMPLATE'
 
  const data2 = [
    {date: '2023-03', budget: '10,600.00', actual: '2,316.00', variance: '8,284.00', percentage: 21, note: ''},
    {date: '2023-03', budget: '10,600.00', actual: '2,316.00', variance: '8,284.00', percentage: 21, note: ''},
    {date: '2023-03', budget: '10,600.00', actual: '2,316.00', variance: '8,284.00', percentage: 21, note: ''},
    {date: '2023-03', budget: '10,600.00', actual: '2,316.00', variance: '8,284.00', percentage: 21, note: ''},
    {date: '2023-03', budget: '10,600.00', actual: '2,316.00', variance: '8,284.00', percentage: 21, note: ''},
    {date: '2023-03', budget: '10,600.00', actual: '2,316.00', variance: '8,284.00', percentage: 21, note: ''},
    {date: '2023-03', budget: '10,600.00', actual: '2,316.00', variance: '8,284.00', percentage: 21, note: ''},
  ];
 
  const inputRightElement = (
    <Pressable style={styles.icon}>
      <GlobalIcon
        name="calendar"
        library="EvilIcons"
        size={hp(4)}
        color={MyColors.headerTitle}
      />
    </Pressable>
  );

  const pieData = [
    { label: 'Completed: 67.6%', value: 67 , color: '#21CF21'},
    { label: 'Not Started: 26.5%', value: 26, color: '#FA2121' },
    { label: 'Cancelled: 5.9%', value: 7, color: '#FA4C4C' },
  ];

  return (
    <PageLayout showBackIcon={true}  headerTitle={title} footerTitle='Add New Score'isFooter={true} duble={true}  title1='Cancel' title2={active ==0 ?'Preview': active ==1  ? 'Next' :active ==2 ? 'Generate Project' :'Preview' }   onPressbtn1={()=>navigation.navigate('project_view')} onPressbtn2={generateFunc}
    btnSty1={styles.footerLft} textsty1={styles.textsty1}  containerStyles={{width:'100%',backgroundColor: '#F8FAFF'}}> 
            <View style={styles.stepContainer}/>  
          <View style={styles.header_step}>
            <View style={styles.stepView}>
            <Pressable style={[styles.stepBox,{backgroundColor: MyColors.mainYellow}]}>{active == 1 || active == 2 ? <GlobalIcon library='Feather' name='check' size={hp(2)} color={MyColors.white} /> : <Text style={{color:active == 0 ? MyColors.white:MyColors.black}}>1</Text>}</Pressable>
            <Text style={styles.stepText}>Select Template</Text>
            </View>
            <View style={styles.stepView}>
            <Pressable style={[styles.stepBox,{backgroundColor:active == 1 || active == 2 ? MyColors.mainYellow : MyColors.white}]}>{active == 2 ? <GlobalIcon library='Feather' name='check' size={hp(2)} color={MyColors.white} /> : <Text style={{color:active == 1 ? MyColors.white:MyColors.black}}>2</Text>}</Pressable>
            <Text style={styles.stepText}>Preview</Text>
            </View>
            <View style={styles.stepView}>
            <Pressable style={[styles.stepBox,{backgroundColor:active == 2 ? MyColors.mainYellow:MyColors.white}]}><Text style={{color:active == 2 ? MyColors.white:MyColors.black}}>3</Text></Pressable>
            <Text style={styles.stepText}>Generate Project</Text>
            </View>
          </View> 
          {
            active == 0 &&  
            <View style={{
              paddingHorizontal: wp(5),
              paddingTop: hp(2)
            }}>
              <AppSelectDropdown placeholder='Select a template' labelText={{fontSize: RFValue(12),color: MyColors.black,fontFamily: MyFonts.OpenSansSemiBold,}} optional={true} dropdownName='Select Template' _color={MyColors.headerTitle} ref={dropdownRef} options={["Template 1", "Template 2", "Template 3", "Template 4"]} buttonStyle={{borderWidth: 1,borderColor: '#ECECEC',backgroundColor: MyColors.white}}/>
              <AppInput optional={true} editable={false} label="Project Start Date" placeholder="mm/dd/yy" value={date} onChangeText={text => setDate(text)} inputRightElement={inputRightElement} style={styles.calenderBox}/>
            </View>
            } 
          {
          active == 1 &&  
          <View style={{marginHorizontal: wp(5)}}>
            <View style={styles.heading}><Dots dot={{backgroundColor:MyColors.mainYellow,width:hp(1.5),height:hp(1.5)}}/><Text style={styles.text_h}> KNZ - 32ND GOV PROCUREMENT CONFERENCE</Text></View>
            <View>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {data?.map((item,i)=>
                <Pressable onPress={() => setSelectArrowTab(i)} style={[styles.flowBox, selectArrowTab == i ? {width: hp(17), backgroundColor: MyColors.buttonSecondary} : {width: hp(15)}]} key={i}>
                 {selectArrowTab != i && <View style={styles.leftArrow} />}
                  <View style={styles.flowBoxContainer}>
                  {selectArrowTab == i && <GlobalIcon library='FontAwesome' name='pencil-square-o' size={hp(2)} color={MyColors.white} />}
                  <Text style={{marginLeft: hp(.5), color: selectArrowTab == i ? MyColors.white : '#616161'}}>{item.name}</Text>
                  </View>
                  <View style={[styles.rightArrow, selectArrowTab == i ? {backgroundColor: MyColors.buttonSecondary} : {backgroundColor: MyColors.lightoffgrey}]} />
                  </Pressable>
                  )}
              </ScrollView>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {tabs?.map((item,i)=><Pressable key={i} onPress={() => setSelectTab(i)} style={[styles.tabBox, i == selectTab ? {backgroundColor: MyColors.buttonSecondary,borderWidth: 1, borderColor: MyColors.grayText} : {borderWidth: 1, borderColor: MyColors.grayText}]}><Text style={[styles.tabbtnText, {color: i == selectTab ? MyColors.white : MyColors.grayText}]}>{item.name}</Text></Pressable>)}
              </ScrollView>

              <View style={styles.healthBox}>
                  <Text style={styles.title}>HEALTH</Text>
                  <View style={styles.healthTitleBox}>
                        <View style={{width:'50%'}}>
                          <Text style={styles.healthTitle}>Time</Text>
                          <Text style={styles.healthTitle}>Progress</Text>
                          <Text style={styles.healthTitle}>Cost</Text>
                        </View>
                        <View style={{width:'50%'}}>  
                          <Text style={[styles.healthTitle, {color: MyColors.headerTitle}]}>0% behind schedule</Text>
                          <Text style={[styles.healthTitle, {color: MyColors.headerTitle}]}>27% tasks complete</Text>
                          <Text style={[styles.healthTitle, {color: MyColors.headerTitle}]}>54% Budget Spent to date</Text>
                        </View>
                  </View>
              </View>

              <View style={styles.chartBox}>
              <Text style={styles.title}>TASK</Text>
              <View style={styles.pieChartContainer}>
              {/* <PieChart
                data={chart}
                width={Dimensions.get("window").width}
                height={hp(25)}
                chartConfig={{ 
                  decimalPlaces: 2,
                  color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
                  labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
                }}
                accessor={"population"}
                backgroundColor={"transparent"}
                paddingLeft={`${screen_width / 4}`}
                hasLegend={false}
              /> */}
              <PieChartWithLabels data={pieData} />
              </View>
              </View>
                
                <View style={styles.pj_ganttChat}> 
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <ProjectGanttChart />
                </ScrollView>
                </View>
                
                <View style={styles.projectDetailBudgetContainer}> 
               <ScrollView horizontal showsHorizontalScrollIndicator={false}>
               <ProjectDetailTable title='PROJECT DETAILED BUDGET' items={data2} />
               </ScrollView>
                </View>
                <View style={[styles.chartBox, {marginBottom: hp(10)}]}>
                <Text style={styles.title}>MEMBER UTILZATION</Text>
                <View style={styles.memberInnerContainer}>
                  <Text style={styles.memberTitleContainer}></Text>
                  <Text style={styles.memberTitleContainer}>Name</Text>
                </View>
                <View style={{flexDirection: 'row', marginTop: hp(2)}}>
                  <View style={styles.memberTitleContainer}>
                  <GlobalIcon library='Entypo' name='chevron-small-down' color={MyColors.grey} />
                  </View>
                  <Text style={styles.memberTitleContainer}>Courtney David</Text>
                </View>
                </View>
            </View>
          </View>
          } 
          {
            active == 2 &&  
            <View style={styles.ganerateProject}>
              <Text numberOfLines={2} style={styles.ganerateTitle}>Hit Generate Project to create a new project from this template.</Text>
            </View>
          }
    </PageLayout>
  );
};

export default SelectTemplate;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
    marginTop: hp(2),
    width:'100%',
  },
  stepContainer:{
    width:'100%',
    height:10,
    backgroundColor:MyColors.mainYellow,
  },
  header_step:{
    flexDirection:'row',
    justifyContent: 'space-around',
  },
  stepBox:{ 
    justifyContent: 'center', 
    alignItems:'center', 
    width:hp(3),
    height:hp(3),
    borderRadius:50,
    borderColor:MyColors.white,
    borderWidth:1, 
    top:hp(-1.2), 
  },
  stepView:{
    alignContent: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    alignItems:'center',
  },
  stepText:{
    fontSize:12,
    color: MyColors.black
    // textAlign:'left'
  },
  footerLft:{
    backgroundColor:MyColors.redSecondry,
    borderColor:MyColors.redSecondry,
  },
  textsty1:{
    color:MyColors.redPrimary,
  },
   heading:{
    flexDirection:'row',
    // justifyContent:'center',
    alignItems:'center',
    marginTop:hp(3),
    marginBottom: hp(1)
   },
   text_h:{
      color:MyColors.headerTitle,
      fontFamily: MyFonts.OpenSansBold,
      fontSize: responsiveSize(14)
   },
   flowBox:{
    marginTop:hp(2),
    width:hp(15),
    alignItems:'center',
    justifyContent:'center',
    flexDirection: 'row',
    height: hp(3),
    marginHorizontal: hp(1.3),
    position: 'relative',
    backgroundColor: MyColors.lightoffgrey
   },
   flowBoxContainer: {
    flexDirection: 'row',
    alignItems: 'center', 
    width: '100%', 
    justifyContent: 'center'
  },
   leftArrow: {
    backgroundColor: '#F8FAFF',
    height: hp(2),
    width: hp(2),
    transform: [{ rotate: '45deg' }],
    position: 'absolute',
    left: -8,
    zIndex: -1,
  },
  rightArrow: {
    backgroundColor: MyColors.lightoffgrey,
    height: hp(2),
    width: hp(2),
    transform: [{ rotate: '45deg' }],
    position: 'absolute',
    right: -8,
    zIndex: -1,
  },
   tabBox:{
      borderRadius:30, 
      width:hp(15),
      marginTop:hp(3.5),
      marginHorizontal:hp(1),
      alignItems:'center',
      justifyContent:'center',
   },
   tabbtnText:{
    padding:hp(1),
    color:MyColors.white,
    textAlign:'center',
   },
   healthBox:{
    marginTop:hp(2),
    backgroundColor:MyColors.white,
    borderRadius:10,
    padding:10,
    borderColor: MyColors.borderColor,
    borderWidth: 1,
   },
   healthTitleBox:{
    flexDirection:'row',
    marginTop:hp(1),
   },
   healthTitle:{
    color:MyColors.greenPrimary, 
    fontFamily: MyFonts.OpenSansRegular,
    fontSize: responsiveSize(12),
    marginTop: hp(.5)
   },
   title: {
    fontSize: responsiveSize(15),
    fontFamily: MyFonts.OpenSansBold,
    color: MyColors.headerTitle
  },
   chartBox:{
    marginTop:hp(2), 
    backgroundColor:MyColors.white,
    borderRadius:10, 
    borderColor: MyColors.borderColor,
    borderWidth: 1,
    padding: 10,
   },
   pieChartContainer: { flex: 1, justifyContent: 'center', alignItems: 'center',width: '100%'},
   pj_ganttChat:{
    marginTop:hp(2), 
    backgroundColor:MyColors.white,
    borderColor: MyColors.borderColor,
    borderWidth: 1,
    borderRadius: 10
   },
   projectDetailBudgetContainer: {
    marginTop: hp(2),
  },
   ganerateProject:{ 
    alignContent: 'center',
    alignItems:'center', 
    // width:'50%',
    marginHorizontal:15, 
    marginTop:'44%', 
   },
   ganerateTitle:{
    textAlign:'center',
    color:MyColors.textTitle,
    fontSize:20,
   },
   icon: {
    justifyContent:'center',
    backgroundColor: 'transparent', 
    right: 40, 
    bottom: 3,
  }, 
  calenderBox: {
    borderRadius: 20,
    marginTop: hp(5)
  },
  memberInnerContainer: {
    flexDirection: 'row', 
    paddingVertical: hp(2), 
    borderBottomColor: MyColors.lightgrey, 
    borderBottomWidth: 1
  },
  memberTitleContainer: {width: '50%'}
});
