import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useRef, useState } from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { hp, screen_width, wp } from '../../../utils/constants';
import { MyColors } from '../../../config/MyColors';
import { useNavigation } from '@react-navigation/native';
import AppSelectDropdown from '../../../components/app-drop-down/app-drop-down';
import Dots from '../../../components/app-dots/app-dots';
import {
  PieChart,
} from "react-native-chart-kit";
import ProjectGanttChart from './project-tables/project-gantt-chart';
import { responsiveSize } from '../../../config/Metrix';
import { MyFonts } from '../../../config/MyFonts';
import GlobalIcon from '../../../config/GlobalIcons';
import CategoryAndItems from '../../../components/app-items/app-item';
 
type progressBar={
    color1: string,
    color2: string,
    color3: string,
    color4: string,
    title: string,
    range:[];
  }
const ProjectPortfolio = () => {
  const navigation:any = useNavigation();
  const categories:any = [
    { id: 1, name: 'Dashboard' },
    { id: 2, name: 'Portfolio Details' }, 
  ];
 
  const ProgressBar = ({title,color1,range}:progressBar)=>{
    return(
      <View style={styles.chartContainer}> 
      {range.map((v,i)=> <View key={i} style={[styles.chartBox,{  backgroundColor: color1,}]}><Text></Text></View> ) } 
        <View><Text style={styles.progressText}>{title}</Text></View>
      </View>
    )
   }
   const BarLine =({num})=>{
    return(
      <View style={{marginTop:hp(3),height:hp(2)}}><Text>{num}</Text><View style={styles.barline} /></View>
    )
   }
  
  return (
    <PageLayout showBackIcon={true}  headerTitle={'PORTFOLIO'} footerTitle='Add New Score' title1='cancel'  onPressbtn1={()=>navigation.navigate('project_view')}
      containerStyles={{width:'100%',backgroundColor: '#F8FAFF'}}> 
              <View style={styles.tabBox}>
              <CategoryAndItems categories={categories} itemsData={categories} />
              </View>
              <View style={styles.container}> 
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <ProjectGanttChart />
                </ScrollView>
                </View>

          <View style={styles.progressBox}> 
          <View style={{marginLeft:hp(4)}}><Text style={styles.progressHeading}>Cost</Text></View>
              <Pressable style={styles.progressContainer}>
                  <View style={{ position: 'absolute', height: hp(27), left: hp(5) }}>
                      <ProgressBar title={'Actual Budget'} color1={MyColors.blue} color2={MyColors.grayText} color3={MyColors.mainYellow} color4={MyColors.greenPrimary} range={[1,1,1]}/>
                  </View>
                  <View style={{ position: 'absolute', height: hp(27), left: hp(18) }}>
                      <ProgressBar title={'Spent Budget'} color1={MyColors.headerTitle} color2={MyColors.grayText} color3={MyColors.mainYellow} color4={MyColors.greenPrimary} range={[1,]}/>
                  </View>
                  <View style={{ position: 'absolute', height: hp(27), left: hp(33) }}>
                      <ProgressBar title={'Budget Health'} color1={MyColors.green} color2={MyColors.greenPrimary} color3={MyColors.mainYellow} color4={MyColors.greenPrimary} range={[1,1,]}/>
                  </View>
                  <BarLine num={'40K'} />
                  <BarLine num={'30K'} />
                  <BarLine num={'10K'} />
                  <BarLine num={'5K'} />
                  <BarLine num={'0'} />
              </Pressable>
          </View>
    </PageLayout>
  );
};

export default ProjectPortfolio;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: hp(.1), 
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    margin:hp(3),
    marginBottom: 20,
    marginTop: hp(2),
    width:'100%',
  }, 
  tabBox:{
    alignSelf:'flex-start',
    flex:1,
    marginTop:hp(2),
    paddingLeft:wp(5)
    },
    barline:{ 
        borderColor: MyColors.lightgrey, 
        borderBottomWidth: 1, 
        bottom: 2, 
        left: hp(2), 
        width: '90%', 
        zIndex:-1
      },
      statusContainer:{
        flexDirection:'row',
        justifyContent:'space-around',
      },
      progressBox:{
        marginBottom: hp(15),
        backgroundColor:MyColors.white,
        marginHorizontal:hp(2),
      },
      progressHeading:{
        fontFamily: MyFonts.OpenSansBold,
        fontSize:hp(2),
        color:MyColors.black, 
      },
      progressContainer:{
        width:'100%',
        marginTop:hp(1), 
        marginHorizontal:hp(2),
        paddingBottom:hp(2), 
        paddingHorizontal:hp(2),
        backgroundColor:MyColors.white,
        },
      progressText:{
        fontFamily:MyFonts.OpenSansSemiBold,
        color:MyColors.black,
        fontSize:10, 
        textAlign:'center',
        // marginTop:hp(2)
      },
      chartContainer:{
        alignItems:'center',
        width: wp(30),
        position:'absolute',
        bottom:hp(.2), 
      },
      chartBox:{ 
        height: hp(6),
        width: wp(15),
        alignItems: 'center',
        justifyContent:'center',
      }
});
