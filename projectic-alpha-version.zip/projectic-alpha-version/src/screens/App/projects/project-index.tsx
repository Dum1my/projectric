import {
  ScrollView,
  StyleSheet,
  View,
} from 'react-native';
import React from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout';
import {hp} from '../../../utils/constants';
import Table from './project-tables/table';
import AppButton from '../../../components/app-button/app-button';
import {MyColors} from '../../../config/MyColors';
import { useNavigation } from '@react-navigation/native';
const ProjectIntake = () => {
  const navigation:any = useNavigation();
  const headings = ['#', 'PROJECT NAME', 'REWARD', 'RISK', 'SCORE'];
  const headings2 = ['REWARD', 'RISK', 'SCORE', 'VISIT'];

  const data = [
    {id: 1, name: 'Mobile App', reward: 30, risk: 9, score: 2},
    {id: 2, name: 'Web', reward: 25, risk: 9, score: 2},
    {id: 3, name: 'Logo', reward: 35, risk: 9, score: 2},
    {id: 4, name: 'Marketing', reward: 40, risk: 9, score: 2},
    {id: 5, name: 'Mobile App', reward: 40, risk: 9, score: 2},
    {id: 6, name: 'Web', reward: 40, risk: 9, score: 2},
    {id: 7, name: 'Logo', reward: 40, risk: 9, score: 2},
    {id: 8, name: 'Marketing', reward: 40, risk: 9, score: 2},
  ];

  const data2 = [
    {reward: 30, risk: 9, score: 8,},
    {reward: 25, risk: 9, score: 8,},
    {reward: 35, risk: 9, score: 8,},
    {reward: 40, risk: 9, score: 8,},
    {reward: 40, risk: 9, score: 8,},
    {reward: 40, risk: 9, score: 8,},
    {reward: 40, risk: 9, score: 8,},
    {reward: 40, risk: 9, score: 8,},
  ];

  return (
    <PageLayout headerTitle="PROJECT INTAKE" footerTitle="Add New Score">
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.tableContainer}>
        <Table title="FORECAST" headingItems={headings} items={data} />
        <Table title="ACTUAL" headingItems={headings2} items={data2} />
      </ScrollView>
      <View style={styles.buttonContainer}>
        <AppButton
          title="Add New Score"
          style={styles.buttonStyle}
          textStyle={styles.textStyle}
          onPress={()=>{navigation.navigate('project_score')}}
        />
      </View>
    </PageLayout>
  );
};

export default ProjectIntake;

const styles = StyleSheet.create({
  tableContainer: {
    paddingVertical: hp(3),
    paddingHorizontal: hp(3),
    marginRight: hp(2),
  },
  buttonContainer: {
    paddingVertical: hp(3),
    paddingHorizontal: hp(3),
  },
  buttonStyle: {
    borderRadius: hp(5),
    marginVertical: hp(3),
  },
  textStyle:{
    color: MyColors.headerTitle,
  }
  // container: {
  //   flex: 1,
  //   borderWidth: 1,
  //   borderColor: '#ccc',
  //   borderRadius: 5,
  //   padding: 10,
  //   marginBottom: 20,
  //   marginTop: hp(2),
  // },
  // header: {
  //   // flex: 1,
  //   fontWeight: 'bold',
  //   textAlign: 'left',
  // },
  // headerRow: {
  //   flexDirection: 'row',
  //   borderBottomWidth: 1,
  //   borderBottomColor: '#ccc',
  //   paddingBottom: 5,
  //   marginBottom: 5,
  // },
  // headerCell: {
  //   flex: 1,
  //   fontWeight: 'bold',
  //   textAlign: 'center',
  // },
  // dataRow: {
  //   flexDirection: 'row',
  //   marginBottom: 5,
  // },
  // dataCell: {
  //   flex: 1,
  //   textAlign: 'center',
  // },
});
