import { Dimensions, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useState } from 'react';
import PageLayout from '../../../layouts/page-layout/page-layout'; 
import { hp, wp } from '../../../utils/constants';
import PorjectTable from './project-tables/data-table';
import AppInput from '../../../components/app-input/app-input';
import { MyColors } from '../../../config/MyColors';
import GlobalIcon from '../../../config/GlobalIcons';

const ProjectTemplate = () => {
  const [val, setValue] = useState<string>('');
    const data1 =['LABEL', 'DESCRIPTION', 'ACTION'];
    const data = [
      { id: 1, name: 'Table Top Conference', description: 'Basic Event Planning Steps', },
      { id: 2, name: 'Alice', description: 'Conference Ancillary Event Logistics',},
      { id: 3, name: 'Bob', description: 'A new invention',}, 
    ];
  const screenWidth = Dimensions.get('window').width;
  const cellWidth = screenWidth / 2;
  const inputRightElement = <Pressable style={styles.icon}><GlobalIcon name="search" library="FontAwesome" size={hp(2)} color={MyColors.grayText} /></Pressable>;
  return (
    <PageLayout headerTitle='PROJECT TEMPLATES' footerTitle='Add New Score' footerbtnSty={styles.footerBtn} containerStyles={{}}>
      <AppInput label='Search Template' placeholder='Enter Template Title' value={val} onChangeText={(text) => setValue(text)} style={{ width: '90%', marginTop: hp(5), marginHorizontal: 20, marginBottom: 0 }} inputRightElement={inputRightElement} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginHorizontal: hp(3)}}>
        <PorjectTable serial={true} data={data} data1={data1} cellWidth={wp(50)} />
      </ScrollView>
    </PageLayout>
  );
};

export default ProjectTemplate;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
    marginTop: hp(2),
  },
  header: {
    // flex: 1,
    fontWeight: 'bold',
    textAlign: 'left', 
  },
  headerRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    paddingBottom: 5,
    marginBottom: 5,
  },
  headerCell: {
    flex: 1,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  dataRow: {
    flexDirection: 'row',
    marginBottom: 5,
  },
  dataCell: {
    flex: 1,
    textAlign: 'center',
  },
  footerBtn:{
    width:'20%'
  },
  icon:{
    right: hp(4)
  },
});
