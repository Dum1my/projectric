import { Platform, StyleSheet, Text, View } from 'react-native'
import React, { useState } from 'react'
import AuthHeader from '../../components/AuthHeader'
import { useNavigation } from '@react-navigation/native'
import { StatusBarHeight, hp, screen_height } from '../../utils/constants'
import CustomInput from '../../components/app-input/app-input'
import { MyColors } from '../../config/MyColors'
import {  MyStylesMain } from '../../styles/GlobalStyles'
import CustomButton from '../../components/Buttons/CustomButton'
import { MyFonts } from '../../config/MyFonts'
import { Dimensions } from 'react-native'
import { TouchableOpacity } from 'react-native'
import NameIconSvg from '../../assets/svgs/NameIconSvg'
import { ScrollView } from 'react-native-gesture-handler'
import {useForm, Controller} from 'react-hook-form';

const RegisterName = () => {
  const navigation = useNavigation()
  const globalStyle = MyStylesMain()

  const {
    control,
    handleSubmit,
    formState: {errors},
    watch
  } = useForm({
    defaultValues: {
      firstName: '',
      lastName: ''
    },
  });
  const watchedFields = watch();

  const onSubmit = (data: any) => {
    if (data) {
      navigation.navigate('RegisterCompany')
    }
  };

  return (
    <ScrollView showsVerticalScrollIndicator={false} style={globalStyle.container}>
      <View style={{height: screen_height}}>
      <AuthHeader
        topIcon={<NameIconSvg />}
        onBackPress={() => navigation.goBack()}
        heading="Enter your name"
        subHeading="Please enter your full name."
        imagePath="yourImageURL"
      />
      <View style={styles.main}>
      <Controller
          name="firstName"
          control={control}
          rules={{
            required: {value: true, message: 'First Name is required'},
          }}
          render={({field}) => (            
        <CustomInput
          optional={true}
          label="First Name"
          placeholder="Enter your First Name"
          value={field.value}
              onChangeText={(text: any) => {
                field.onChange(text);
              }}
              error={errors.firstName?.message}
        />
          )}
        />
        <Controller
          name="lastName"
          control={control}
          rules={{
            required: {value: true, message: 'Last Name is required'},
          }}
          render={({field}) => (
        <CustomInput
          optional={true}
          label="Last Name"
          placeholder="Enter your Last Name"
          value={field.value}
              onChangeText={(text: any) => {
                field.onChange(text);
              }}
              error={errors.lastName?.message}
           />
           )}
          />
        
        <View style={styles.inner}>
          <CustomButton
            size='large'
            title="Continue"
            onPress={handleSubmit(onSubmit)}
            // onPress={() => navigation.navigate('RegisterCompany')}
            loading={false}
            disabled={watchedFields.firstName && watchedFields.lastName ? false : true}
            textStyle={{ color: MyColors.black }}
            style={[
              globalStyle.gButton,
              {
                backgroundColor: MyColors.mainYellow,
                width: '100%'
              },
            ]}
          />
          <View style={styles.welcomeContainer}>
            <Text style={styles.welcomeText}>Already have an account? </Text>
            <TouchableOpacity style={styles.register} onPress={() => navigation.navigate('LogInScreen')}>
              <Text style={styles.welcomeText2}>Login</Text>
            </TouchableOpacity>
          </View>
        </View>

      </View>
      </View>
    </ScrollView>
  )
}

export default RegisterName

const styles = StyleSheet.create({
  welcomeContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingBottom: hp(5),
    // paddingTop: hp(3),
  },
  welcomeText: {
    fontSize: hp(2),
    fontFamily: MyFonts.OpenSansRegular,
    alignSelf: 'flex-end',
    color: MyColors.black
  },
  main: {
    flex: 1,
    paddingTop: hp(6),
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  inner: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-end'
  },
  welcomeText2: {
    fontSize: hp(2),
    fontFamily: MyFonts.OpenSansRegular,
    alignSelf: 'flex-end',
    color: MyColors.orangeText,
    textDecorationLine: 'underline'
  },
  register: {
    justifyContent: 'flex-end'
  }
})