// LogInScreen.tsx
import React, {useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import CustomInput from '../../components/app-input/app-input';
import CustomButton from '../../components/Buttons/CustomButton';
import {MyColors} from '../../config/MyColors';
import {MyStylesMain} from '../../styles/GlobalStyles';
import BuldSvg from '../../assets/svgs/BuldSvg';
import {MyFonts} from '../../config/MyFonts';
import {ScrollView} from 'react-native';
import {Platform} from 'react-native';
import {StatusBarHeight, hp} from '../../utils/constants';
import {useNavigation} from '@react-navigation/native';
import {useAppDispatch} from '../../store/hooks';
import {saveInitalRoute, saveToken} from '../../store/user/userSlice';
import {useForm, Controller} from 'react-hook-form';

const LogInScreen: React.FC = () => {
  const navigation = useNavigation();
  const dispatch = useAppDispatch();
  const globalStyle = MyStylesMain();

  useEffect(() => {
    dispatch(saveInitalRoute('Splash'));
  }, []);

  const handleSignIn = () => {
    dispatch(saveToken(1));
  };

  const {
    control,
    handleSubmit,
    formState: {errors},
    watch,
  } = useForm({
    defaultValues: {
      email: '',
      password: '',
    },
  });

  const watchedFields = watch();

  const onSubmit = (data: any) => {
    if (data) {
      dispatch(saveToken(1));
    }
  };

  return (
    <View style={globalStyle.container}>
      <ScrollView
        bounces={false}
        showsVerticalScrollIndicator={false}
        style={{
          flex: 1,
        }}>
        <View style={styles.header}>
          <BuldSvg />
          <Text style={styles.headerText}>Login</Text>
          <Text style={styles.headerText1}>
            Welcome back, you've been missed!
          </Text>
        </View>
        <View style={styles.signInForm}>
          <Controller
            name="email"
            control={control}
            rules={{
              required: {value: true, message: 'Email is required'},
              minLength: {
                value: 2,
                message: 'Email should be at least 2 characters',
              },
              maxLength: {
                value: 50,
                message: 'Email should not exceed 50 characters',
              },
              pattern: {
                value: /^\S+@\S+$/i,
                message: 'Invalid email address',
              },
            }}
            render={({field}) => (
              <CustomInput
                label="Email"
                placeholder="Enter your email"
                value={field.value}
                onChangeText={(text: any) => {
                  field.onChange(text);
                }}
                error={errors.email?.message}
              />
            )}
          />
          <Controller
            name="password"
            control={control}
            rules={{
              required: {value: true, message: 'Password is required'},
              minLength: {
                value: 9,
                message: 'Password should be at least 9 characters',
              },
            }}
            render={({field: {value, onChange}}) => (
              <CustomInput
                label="Password"
                secureTextEntry={true}
                placeholder="Enter your password"
                value={value}
                onChangeText={(text: any) => onChange(text)}
                error={errors.password?.message}
                type="password"
                showPasswordIcon={true}
              />
            )}
          />
          <TouchableOpacity
            onPress={() => navigation.navigate('PasswordRecovery')}
            style={styles.forgotPassword}>
            <Text style={styles.forgot}>Forgot Password?</Text>
          </TouchableOpacity>
          <CustomButton
            size="large"
            title="Login"
            onPress={handleSubmit(onSubmit)}
            // onPress={handleSignIn}
            loading={false}
            disabled={
              watchedFields.email && watchedFields.password.length > 0
                ? false
                : true
            }
            textStyle={{color: MyColors.black}}
            style={[
              globalStyle.gButton,
              {
                backgroundColor: MyColors.mainYellow,
                width: '100%',
              },
            ]}
          />
        </View>
        <View style={styles.welcomeContainer}>
          <Text style={styles.welcomeText}>Don't have an account? </Text>
          <TouchableOpacity
            style={styles.register}
            onPress={() => navigation.navigate('RegisterEmail')}>
            <Text style={styles.welcomeText2}>Register now!</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: MyColors.white,
    paddingTop: Platform.OS == 'android' ? StatusBarHeight() : 0,
    justifyContent: 'center',
  },
  header: {
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: hp(2),
  },
  headerText: {
    color: MyColors.black,
    fontFamily: MyFonts.OpenSansBold,
    fontSize: hp(3.5),
  },
  headerText1: {
    color: MyColors.grayText,
    paddingTop: hp(1),
    fontFamily: MyFonts.OpenSansRegular,
    fontSize: hp(1.8),
  },
  signInForm: {
    paddingTop: hp(14),
    justifyContent: 'center',
    alignItems: 'center',
  },
  forgotPassword: {
    top: hp(-4),
    alignSelf: 'flex-end',
    padding: 5,
  },
  forgot: {
    color: MyColors.black,
    fontFamily: MyFonts.OpenSansRegular,
    fontSize: hp(1.5),
    alignSelf: 'flex-end',
    // top: hp(-4),
    // paddingRight: hp(2),
    textDecorationLine: 'underline',
    textAlign: 'right',
  },
  welcomeContainer: {
    flex: 1,
    flexDirection: 'row',
    height: Dimensions.get('window').height / hp(0.4),
    justifyContent: 'center',
    // backgroundColor:'red',
    paddingBottom: 10, // Adjust paddingBottom as needed
  },
  welcomeText: {
    fontSize: hp(2),
    fontFamily: MyFonts.OpenSansRegular,
    alignSelf: 'flex-end',
    color: MyColors.black,
  },
  welcomeText2: {
    fontSize: hp(2),
    fontFamily: MyFonts.OpenSansRegular,
    alignSelf: 'flex-end',
    color: MyColors.orangeText,
    textDecorationLine: 'underline',
  },
  register: {
    justifyContent: 'flex-end',
  },
});

export default LogInScreen;
