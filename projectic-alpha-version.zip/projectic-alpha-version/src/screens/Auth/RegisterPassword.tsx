import { Platform, StyleSheet, Text, View,TouchableOpacity,ScrollView } from 'react-native'
import React, { useState } from 'react'
import AuthHeader from '../../components/AuthHeader'
import { useNavigation } from '@react-navigation/native'
import { StatusBarHeight, hp, screen_height } from '../../utils/constants'
import CustomInput from '../../components/app-input/app-input'
import { MyColors } from '../../config/MyColors'
import {  MyStylesMain } from '../../styles/GlobalStyles'
import CustomButton from '../../components/Buttons/CustomButton'
import { MyFonts } from '../../config/MyFonts'
import { Dimensions } from 'react-native'
import NameIconSvg from '../../assets/svgs/NameIconSvg'
import { responsiveSize } from '../../config/Metrix'
import CheckBox from 'react-native-check-box'
import AboutModal from '../../components/AboutModal/AboutModal'
import LockIcon from '../../assets/svgs/LockIcon'
import {useForm, Controller} from 'react-hook-form';

const RegisterPassword = () => {
  const navigation = useNavigation()
  const globalStyle = MyStylesMain()
  const [isChecked, setIsChecked] = useState<boolean>(false)
  const [modalOpen, setModalOpen] = useState<boolean>(false)
  const password = React.useRef({});

  const {
    control,
    handleSubmit,
    formState: {errors},
    watch
  } = useForm({
    defaultValues: {
      password: '',
      confirmPassword: ''
    },
  });
  password.current = watch("password", "");
  const watchedFields = watch();
  const onSubmit = (data: any) => {
    if (data) {
      navigation.navigate('RegistrationInProcess')
    }
  };

  return (
    <ScrollView showsVerticalScrollIndicator={false} style={globalStyle.container}>
      <View style={{height: screen_height}}>
      <AuthHeader
        topIcon={<LockIcon />}
        onBackPress={() => navigation.goBack()}
        heading="Password"
        subHeading="Please enter your password."
        imagePath="yourImageURL"
      />
      <View style={styles.main}>
      <Controller
          name="password"
          control={control}
          rules={{
            required: {value: true, message: 'Password is required'},
            minLength: {
              value: 9,
              message: 'Password should be at least 9 characters',
            },
          }}
          render={({field}) => (            
          <CustomInput
          optional={true}
          label="Password"
          placeholder="Enter Password"
          type='password'
          showPasswordIcon={true}
          value={field.value}
          onChangeText={(text: any) => {
            field.onChange(text);
          }}
          error={errors.password?.message}
          />
           )}
         />
         <Controller
          name="confirmPassword"
          control={control}
          rules={{
            required: {value: true, message: 'Confirm Password is required'},
            minLength: {
              value: 9,
              message: 'Confirm Password should be at least 9 characters',
            },
            validate: (value) => value === password.current || "The passwords do not match"
          }}
          render={({field}) => (            
            <CustomInput
            optional={true}
            label="Confirm Password"
            placeholder="Enter Confirm Password"
            style={{marginBottom: hp(1)}}
            type='password'
            showPasswordIcon={true}
            value={field.value}
            onChangeText={(text: any) => {
            field.onChange(text);
            }}
            error={errors.confirmPassword?.message}
          />
           )}
         />
         <View style={{width: '100%'}}>
         <Text style={{color: MyColors.headerTitle, fontSize: responsiveSize(12), fontFamily: MyFonts.OpenSansRegular, marginBottom: hp(3)}}><Text style={{color: '#F92525'}}>Must include: </Text>One Uppercase, One Lowercase, One Number and one special case Character</Text>
          <CheckBox isChecked={isChecked} onClick={() => setIsChecked(!isChecked)} checkedCheckBoxColor={MyColors.greenPrimary} rightTextView={<View style={{flexDirection: 'row', alignItems: 'center', marginLeft: hp(.5)}}><Text style={{color: MyColors.headerTitle, fontSize: responsiveSize(12), fontFamily: MyFonts.OpenSansRegular}}>I have read the </Text><TouchableOpacity onPress={() => setModalOpen(true)}><Text style={{color: MyColors.mainYellow, fontSize: responsiveSize(12), fontFamily: MyFonts.OpenSansRegular, textDecorationLine: 'underline'}}>Terms and condition</Text></TouchableOpacity></View>} />
         </View>
        <View style={styles.inner}>
          <CustomButton
            size='large'
            title="Register"
            onPress={handleSubmit(onSubmit)}
            // onPress={() => navigation.navigate('RegistrationInProcess')}
            loading={false}
            disabled={watchedFields.password && watchedFields.confirmPassword ? false : true}
            textStyle={{ color: MyColors.black }}
            style={[
              globalStyle.gButton,
              {
                backgroundColor: MyColors.mainYellow,
                width: '100%'
              },
            ]}
          />
          <View style={styles.welcomeContainer}>
            <Text style={styles.welcomeText}>Already have an account? </Text>
            <TouchableOpacity style={styles.register} onPress={() => navigation.navigate('LogInScreen')}>
              <Text style={styles.welcomeText2}>Login</Text>
            </TouchableOpacity>
          </View>
        </View>

      </View>
      </View>
      <AboutModal isOpen={modalOpen} setIsOpen={setModalOpen} />
    </ScrollView>
  )
}

export default RegisterPassword

const styles = StyleSheet.create({
  welcomeContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingBottom: hp(5),
    // paddingTop: hp(3),
  },
  welcomeText: {
    fontSize: hp(2),
    fontFamily: MyFonts.OpenSansRegular,
    alignSelf: 'flex-end',
    color: MyColors.black
  },
  main: {
    flex: 1,
    paddingTop: hp(6),
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  inner: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-end'
  },
  welcomeText2: {
    fontSize: hp(2),
    fontFamily: MyFonts.OpenSansRegular,
    alignSelf: 'flex-end',
    color: MyColors.orangeText,
    textDecorationLine: 'underline'
  },
  register: {
    justifyContent: 'flex-end'
  }
})