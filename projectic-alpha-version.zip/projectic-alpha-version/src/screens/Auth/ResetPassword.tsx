import {StyleSheet, View} from 'react-native';
import React, {useState} from 'react';
import AuthHeader from '../../components/AuthHeader';
import {useNavigation} from '@react-navigation/native';
import {hp, screen_height} from '../../utils/constants';
import {MyStylesMain} from '../../styles/GlobalStyles';
import CustomInput from '../../components/app-input/app-input';
import {ScrollView} from 'react-native';
import CustomButton from '../../components/Buttons/CustomButton';
import {MyColors} from '../../config/MyColors';
import {useForm, Controller} from 'react-hook-form';

const ResetPassword = () => {
  const navigation = useNavigation();
  const globalStyle = MyStylesMain();
  const password = React.useRef({});

  const {
    control,
    handleSubmit,
    formState: {errors},
    watch
  } = useForm({
    defaultValues: {
      password: '',
      confirmPassword: '',
    },
  });
  password.current = watch("password", "");

  const onSubmit = (data: any) => {
    if (data) {
      navigation.navigate('LogInScreen')
    }
  };

  return (
    <View style={globalStyle.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <AuthHeader
          onBackPress={() => navigation.goBack()}
          heading="Reset Your Password"
          subHeading="At least 9 characters, with uppercase and lowercase letters"
        />
        <View style={styles.main}>
          <Controller
            name="password"
            control={control}
            rules={{
              required: {value: true, message: 'Password is required'},
              minLength: {
                value: 9,
                message: 'Password should be at least 9 characters',
              },
            }}
            render={({field: {value, onChange}}) => (
              <CustomInput
                label="Password"
                placeholder="Enter Password"
                secureTextEntry={true}
                value={value}
                onChangeText={(text: any) => onChange(text)}
                error={errors.password?.message}
                type="password"
                showPasswordIcon={true}
              />
            )}
          />
          <Controller
            name="confirmPassword"
            control={control}
            rules={{
              required: {value: true, message: 'Confirm Password is required'},
              minLength: {
                value: 9,
                message: 'Confirm Password should be at least 9 characters',
              },
              validate: (value) => value === password.current || "The passwords do not match"
            }}
            render={({field: {value, onChange}}) => (
              <CustomInput
                label="Confirm Password"
                placeholder="Enter Confirm Password"
                secureTextEntry={true}
                value={value}
                onChangeText={(text: any) => onChange(text)}
                error={errors.confirmPassword?.message}
                type="password"
                showPasswordIcon={true}
              />
            )}
          />
          <View
            style={{
              height: screen_height / 2.5,
              justifyContent: 'flex-end',
            }}>
            <CustomButton
              size="large"
              title="Reset Password"
              onPress={handleSubmit(onSubmit)}
              // onPress={() => navigation.navigate('LogInScreen')}
              loading={false}
              textStyle={{color: MyColors.black}}
              style={[
                globalStyle.gButton,
                {
                  backgroundColor: MyColors.mainYellow,
                  width: '100%',
                  marginTop: hp(2),
                },
              ]}
            />
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default ResetPassword;

const styles = StyleSheet.create({
  main: {
    flex: 1,
    paddingTop: hp(10),
    alignItems: 'center',
  },
});
