import { ScrollView, StyleSheet, Text, View, Dimensions, TouchableOpacity } from 'react-native';
import React, { useState } from 'react';
import Carousel, { Pagination } from 'react-native-snap-carousel';
import CarouselCardItem, { ITEM_WIDTH, SLIDER_WIDTH } from '../../components/carosel/CarouselCardItem';
import { SnapData } from '../../config/MyData';
import { MyColors } from '../../config/MyColors';
import CustomButton from '../../components/Buttons/CustomButton';
import { MyStylesMain } from '../../styles/GlobalStyles';
import { MyFonts } from '../../config/MyFonts';
import { responsiveSize } from '../../config/Metrix';
import { RFValue } from 'react-native-responsive-fontsize';
import GlobalIcon from '../../config/GlobalIcons';
import { useNavigation } from '@react-navigation/native';
import { hp, useCustomSafeAreaInsets } from '../../utils/constants';

const WelcomeScreen = () => {
  const isCarousel = React.useRef(null);
  const globalStyle = MyStylesMain()

  const insets = useCustomSafeAreaInsets();
  const navigation = useNavigation()
  const [index, setIndex] = React.useState(0);

  return (
    <View style={styles.container}>
      <ScrollView>
        <Carousel
          layout="tinder"
          onSnapToItem={(index) => setIndex(index)}
          layoutCardOffset={-2}
          activeSlideOffset={1}
          apparitionDelay={1}
          ref={isCarousel}
          data={SnapData}
          renderItem={({ item, index }: any) => <CarouselCardItem item={item} index={index} />}
          sliderWidth={SLIDER_WIDTH}
          itemWidth={ITEM_WIDTH}
          inactiveSlideShift={0}
          useScrollView={true}
        />
        <View style={styles.dotsstyle}>
          <Pagination
            dotsLength={SnapData.length}
            activeDotIndex={index}
            carouselRef={isCarousel}
            dotStyle={{
              width: hp(2.2),
              height: hp(1),
              borderRadius: 5,
              marginHorizontal: hp(-10),
              backgroundColor: MyColors.mainYellow,
            }}
            inactiveDotStyle={{
              width: hp(1),
              height: hp(1),
              backgroundColor: '#929393',
            }}
            inactiveDotColor="#929393"
            tappableDots={true}
          />
        </View>
        <View style={{ alignItems: 'center', marginTop: hp(3) }}>
          <CustomButton
            title="Login With Email"
            onPress={() => navigation.navigate('LogInScreen')}
            loading={false}
            // disabled={true}
            textStyle={{ color: MyColors.black }}
            style={[
              globalStyle.gButton,
              {
                backgroundColor: MyColors.mainYellow,
              },
            ]}
            leftIcon={
              <View style={styles.globalIcon}>
                <GlobalIcon name="mail" library="Entypo" size={hp(3)} color={MyColors.mainYellow} />
              </View>
            }

          />
          <View style={styles.signupContainer}>
            <Text style={styles.signUpText2}>Haven’t created an account yet? </Text>
            <TouchableOpacity onPress={()=> navigation.navigate('RegisterEmail')} style={{ flexDirection: 'row' }}>
              <Text style={styles.signUp2}>Register now!</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default WelcomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  signupContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: hp(1),
    paddingBottom: hp(2),
  },

  signUpText2: {
    fontSize: hp(1.7),
    fontFamily: MyFonts.OpenSansRegular,
    color: MyColors.black,
  },
  dotsstyle: {
    paddingBottom: hp(4),
  },
  globalIcon: {
    height: hp(4),
    width: hp(4),
    borderRadius: 50,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  signUp2: {
    fontSize: hp(1.7),
    fontFamily: MyFonts.OpenSansRegular,
    textDecorationLine: 'underline',
    color: MyColors.orangeText,
  },
});
