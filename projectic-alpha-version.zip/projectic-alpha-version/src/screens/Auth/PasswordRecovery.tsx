import {StyleSheet, View} from 'react-native';
import React, {useState} from 'react';
import AuthHeader from '../../components/AuthHeader';
import {useNavigation} from '@react-navigation/native';
import {hp} from '../../utils/constants';
import CustomInput from '../../components/app-input/app-input';
import {MyColors} from '../../config/MyColors';
import {MyStylesMain} from '../../styles/GlobalStyles';
import CustomButton from '../../components/Buttons/CustomButton';
import {useForm, Controller} from 'react-hook-form';

const PasswordRecovery = () => {
  const navigation = useNavigation();
  const globalStyle = MyStylesMain();

  const {
    control,
    handleSubmit,
    formState: {errors},
  } = useForm({
    defaultValues: {
      email: '',
    },
  });

  const onSubmit = (data: any) => {
    if (data) {
      navigation.navigate('RecoveryCode');
    }
  };

  return (
    <View style={globalStyle.container}>
      <AuthHeader
        onBackPress={() => navigation.goBack()}
        heading="Password Recovery"
        subHeading="Please enter your email address to recover your password"
      />
      <View style={styles.main}>
        <Controller
          name="email"
          control={control}
          rules={{
            required: {value: true, message: 'Email is required'},
            minLength: {
              value: 2,
              message: 'Email should be at least 2 characters',
            },
            maxLength: {
              value: 50,
              message: 'Email should not exceed 50 characters',
            },
            pattern: {
              value: /^\S+@\S+$/i,
              message: 'Invalid email address',
            },
          }}
          render={({field}) => (
            <CustomInput
              label="Registered Email"
              placeholder="michealscott@gmail.com"
              value={field.value}
              onChangeText={(text: any) => {
                field.onChange(text);
              }}
              error={errors.email?.message}
            />
          )}
        />
        <CustomButton
          size="large"
          title="Submit"
          onPress={handleSubmit(onSubmit)}
          // onPress={() => navigation.navigate('RecoveryCode')}
          loading={false}
          textStyle={{color: MyColors.black}}
          style={[
            globalStyle.gButton,
            {
              backgroundColor: MyColors.mainYellow,
              width: '100%',
              marginTop: hp(2),
            },
          ]}
        />
      </View>
    </View>
  );
};

export default PasswordRecovery;

const styles = StyleSheet.create({
  main: {
    flex: 1,
    paddingTop: hp(10),
    alignItems: 'center',
  },
});
