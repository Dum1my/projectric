import {StyleSheet, TouchableOpacity, View} from 'react-native';
import React, {useEffect, useState} from 'react';
import AuthHeader from '../../components/AuthHeader';
import {useNavigation} from '@react-navigation/native';
import {hp} from '../../utils/constants';
import {MyColors} from '../../config/MyColors';
import {MyStylesMain} from '../../styles/GlobalStyles';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import {Text} from 'react-native';
import {responsiveSize} from '../../config/Metrix';
import {MyFonts} from '../../config/MyFonts';

const RecoveryCode = () => {
  const navigation = useNavigation();
  const globalStyle = MyStylesMain();
  const [isTimer, setIsTimer] = useState<boolean>(true);
  const [timeCounter, setTimerCount] = useState(60);
  const verifyCode = () => {
    navigation.navigate('ResetPassword');
  };

  useEffect(() => {
    _timer();
  }, []);

  const _timer = () => {
    let timerInterval = setInterval(() => {
      setTimerCount(val => val - 1);
    }, 1000);

    setTimeout(() => {
      setIsTimer(false);
      setTimerCount(60);
      clearInterval(timerInterval);
    }, 60000);
  };

  return (
    <View style={globalStyle.container}>
      <AuthHeader
        onBackPress={() => navigation.goBack()}
        heading="Enter Recovery Code"
        subHeading="Recovery code has been sent to michaelscott@gmail.com"
      />
      <View style={styles.main}>
        <OTPInputView
          style={{width: '85%', height: hp(8)}}
          pinCount={4}
          keyboardType="number-pad"
          autoFocusOnLoad={false}
          codeInputFieldStyle={styles.underlineStyleBase}
          codeInputHighlightStyle={styles.underlineStyleHighLighted}
          onCodeFilled={verifyCode}
        />
        <View style={{flexDirection: 'row', marginTop: hp(2)}}>
          <Text style={styles.title}>Didn't receive code </Text>
          <TouchableOpacity
            onPress={() => {
              setIsTimer(true);
              _timer();
            }}
            disabled={isTimer}
            activeOpacity={isTimer ? 1 : 0.6}>
            <Text
              style={[
                styles.title,
                {
                  color: isTimer ? MyColors.greenPrimary : MyColors.redPrimary,
                  textDecorationLine: 'underline',
                },
              ]}>
              {isTimer ? `Resend Again in (${timeCounter}s)` : 'Resend'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default RecoveryCode;

const styles = StyleSheet.create({
  main: {
    flex: 1,
    paddingTop: hp(10),
    alignItems: 'center',
  },
  underlineStyleHighLighted: {
    // borderColor: appColors.primary,
    // color: appColors.mat_black,
  },
  underlineStyleBase: {
    width: 60,
    height: 60,
    backgroundColor: '#F8FAFF',
    color: MyColors.black,
    borderWidth: 1,
    borderBottomWidth: 1,
    borderRadius: 5,
    fontSize: responsiveSize(15),
    fontFamily: MyFonts.OpenSansRegular,
  },
  title: {
    fontSize: responsiveSize(15),
    fontFamily: MyFonts.OpenSansRegular,
    color: MyColors.headerTitle,
  },
});
