import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import GlobalIcon from '../../config/GlobalIcons';
import {hp} from '../../utils/constants';
import {MyColors} from '../../config/MyColors';
import {responsiveSize} from '../../config/Metrix';
import {MyFonts} from '../../config/MyFonts';
import {MyStylesMain} from '../../styles/GlobalStyles';
import CustomButton from '../../components/Buttons/CustomButton';
import {useNavigation} from '@react-navigation/native';

const RegistrationInProcess = () => {
  const navigation = useNavigation();
  const mainStyles = MyStylesMain();
  return (
    <View style={mainStyles.container}>
      <View style={styles.subContainer}>
        <GlobalIcon
          library="Entypo"
          name="dots-three-horizontal"
          size={hp(12)}
          color={'#FFDC99'}
        />
        <Text style={styles.title}>Registration in process!</Text>
        <Text style={styles.subTitle}>
          We have received your registration form and it's under process.
        </Text>
        <Text style={[styles.subTitle, {fontFamily: MyFonts.OpenSansRegular}]}>
          Once you registration is complete, you will receive an email
          confirming your registration and you will be able to login to the
          system.
        </Text>
        <Text style={[styles.subTitle, {fontFamily: MyFonts.OpenSansRegular}]}>
          Thank you for your patience. Cheers!
        </Text>
      </View>
      <CustomButton
        onPress={() => navigation.navigate('LogInScreen')}
        title="Go Back To Login"
        style={styles.button}
        textStyle={styles.buttonText}
      />
    </View>
  );
};

export default RegistrationInProcess;

const styles = StyleSheet.create({
  subContainer: {flex: 1, justifyContent: 'center', alignItems: 'center'},
  title: {
    color: MyColors.black,
    fontSize: responsiveSize(20),
    fontFamily: MyFonts.OpenSansBold,
    textAlign: 'center',
    marginBottom: hp(2),
  },
  subTitle: {
    color: MyColors.headerTitle,
    fontSize: responsiveSize(12),
    fontFamily: MyFonts.OpenSansSemiBold,
    textAlign: 'center',
    marginBottom: hp(2),
  },
  button: {borderRadius: hp(3)},
  buttonText: {
    color: MyColors.headerTitle,
    fontFamily: MyFonts.OpenSansSemiBold,
    fontSize: responsiveSize(15),
  },
});
