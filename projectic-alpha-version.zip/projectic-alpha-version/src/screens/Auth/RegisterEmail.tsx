import {StyleSheet, Text, View} from 'react-native';
import React, {useState} from 'react';
import AuthHeader from '../../components/AuthHeader';
import {useNavigation} from '@react-navigation/native';
import {hp} from '../../utils/constants';
import CustomInput from '../../components/app-input/app-input';
import {MyColors} from '../../config/MyColors';
import {MyStylesMain} from '../../styles/GlobalStyles';
import CustomButton from '../../components/Buttons/CustomButton';
import {MyFonts} from '../../config/MyFonts';
import {TouchableOpacity} from 'react-native';
import EmailIconSvg from '../../assets/svgs/EmailIconSvg';
import {useForm, Controller} from 'react-hook-form';

const RegisterEmail = () => {
  const navigation = useNavigation();
  const globalStyle = MyStylesMain();

  const {
    control,
    handleSubmit,
    formState: {errors},
    watch,
  } = useForm({
    defaultValues: {
      email: '',
    },
  });
  const watchedFields = watch();

  const onSubmit = (data: any) => {
    if (data) {
      navigation.navigate('RegisterName');
    }
  };

  return (
    <View style={globalStyle.container}>
      <AuthHeader
        topIcon={<EmailIconSvg />}
        onBackPress={() => navigation.goBack()}
        heading="What's your email?"
        subHeading="We'll check if you have any account."
        imagePath="yourImageURL"
      />
      <View style={styles.main}>
        <Controller
          name="email"
          control={control}
          rules={{
            required: {value: true, message: 'Email is required'},
            minLength: {
              value: 2,
              message: 'Email should be at least 2 characters',
            },
            pattern: {
              value: /^\S+@\S+$/i,
              message: 'Invalid email address',
            },
          }}
          render={({field}) => (
            <CustomInput
              optional={true}
              label="Email"
              placeholder="Enter your email"
              value={field.value}
              onChangeText={(text: any) => {
                field.onChange(text);
              }}
              error={errors.email?.message}
            />
          )}
        />
        <View style={styles.inner}>
          <CustomButton
            size="large"
            title="Continue"
            onPress={handleSubmit(onSubmit)}
            // onPress={() => navigation.navigate('RegisterName')}
            loading={false}
            disabled={watchedFields.email ? false : true}
            textStyle={{color: MyColors.black}}
            style={[
              globalStyle.gButton,
              {
                backgroundColor: MyColors.mainYellow,
                width: '100%',
              },
            ]}
          />
          <View style={styles.welcomeContainer}>
            <Text style={styles.welcomeText}>Already have an account? </Text>
            <TouchableOpacity
              style={styles.register}
              onPress={() => navigation.navigate('LogInScreen')}>
              <Text style={styles.welcomeText2}>Login</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );
};

export default RegisterEmail;

const styles = StyleSheet.create({
  welcomeContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingBottom: hp(3),
    // paddingTop: hp(3),
  },
  main: {
    flex: 1,
    paddingTop: hp(6),
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  inner: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-end',
  },
  welcomeText: {
    fontSize: hp(2),
    fontFamily: MyFonts.OpenSansRegular,
    alignSelf: 'flex-end',
    color: MyColors.black,
  },
  welcomeText2: {
    fontSize: hp(2),
    fontFamily: MyFonts.OpenSansRegular,
    alignSelf: 'flex-end',
    color: MyColors.orangeText,
    textDecorationLine: 'underline',
  },
  register: {
    justifyContent: 'flex-end',
  },
});
